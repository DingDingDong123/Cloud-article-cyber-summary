Cloud Security Project Planner — Setup
========================================

This bundle ships all files with .txt extensions to pass through file-
extension filters in transit. Once you receive it, do this ONE step:

  1. Rename `index.txt` → `index.html`

That's it. Leave the other .txt files alone — `index.html` references
them by their .txt names and the browser executes them correctly
based on the <script> and <link> tags, regardless of extension.

Then double-click `index.html` to open the tool in your browser.

Folder contents:
  index.html   — main page (rename from index.txt)
  styles.txt   — CSS (do not rename)
  data.txt     — embedded dataset (do not rename)
  app.txt      — application logic (do not rename)

Editing the dataset:
  Open data.txt in any text editor. The data lives as a JavaScript
  assignment: window.PLANNER_DATA = { ... };
  Modify values, save, refresh the browser.
