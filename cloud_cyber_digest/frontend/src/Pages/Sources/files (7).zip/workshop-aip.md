# Workshop, AIP, and Cross-Cutting (Branching, CI/CD, Security)

Last researched: 2026-06-08. Sources are Palantir public docs; dates inline. Re-verify dated claims before production use.

## Contents
- Workshop capabilities
- AIP capabilities and the rename
- Decision framework (full)
- Workshop composition patterns
- Best practices
- Pitfalls
- Workshop/AIP recent changes
- Cross-cutting: Global Branching
- Cross-cutting: release management and CI/CD
- Cross-cutting: security and governance
- Cross-cutting recent changes

## Workshop capabilities

(workshop/concepts-layouts; workshop/concepts-widgets) Header, pages, sections (column/row/tabs/toolbar/loop), overlays, widgets, variables.
- Widget categories: core display, visualization, filtering, event/navigational, embed Foundry apps (Quiver dashboard, Map template, Notepad, Vertex graph, Embedded Workshop module, Slate iframe), and custom widgets (frontend code under a restrictive CSP, no external requests).
- Variables: object set, object set filter, primitive, struct; bound to widget inputs/outputs and events; persistable via saved states.
- Loop layouts: render an embedded module per element of an object set or array.

## AIP capabilities and the rename

- AIP Logic: no-code LLM functions composed of blocks (logic/overview).
- AIP Chatbot Studio (formerly AIP Agent Studio): build AIP Chatbots (formerly AIP Agents) with application state, tools (Action, Object query, Function, Update application variable, Command), and native or prompted tool calling (chatbot-studio/overview). The rename happened between 2026-04-09 and 2026-05: the 2026-04-09 announcement still says "AIP Agent Studio"; the May 2026 page says "AIP Chatbot Studio (formerly known as AIP Agent Studio)".
- AIP Chatbot widget (formerly AIP Agent widget) in Workshop: build the chatbot in AIP Chatbot Studio and embed via the widget. The legacy mode of the AIP Agent widget was deprecated and deleted from Foundry on 2026-05-01 (announcements/2026-04).
- AIP Document Intelligence: GA 2026-02-04, enabled by default for AIP enrollments; generates Python transforms that convert PDFs/images into structured Markdown with preserved tables (announcements/2026-02).
- language-model-service governs LLM access (aip/supported-llms). On 2026-04-07 Palantir added xAI Grok 4.20 (Reasoning and Non-Reasoning) and Nvidia Nemotron 3 Super 120B / Nano 30B.
- AIP Evals: evaluation suites against any function; beta "Generate evals" autogenerates test cases (Sept 2025).

## Decision framework (full)

| Need | Choose |
|---|---|
| Multi-step LLM reasoning with Ontology tools, evaluation, human-in-the-loop | AIP Logic |
| Deterministic typed Ontology computation/transformation | Function (TS v2 / Python) |
| Conditional UX, simple aggregations, filter composition inside the app | Workshop variables and events (no function) |
| Conversational UI with sessions, application state, multi-turn memory | AIP Chatbot (AIP Chatbot Studio) |
| Single-shot LLM call inside a Workshop event | Inline AIP Logic function consumed as a function |
| External-network call from app logic | TS v1 webhook, Python function via `functions.sources`, AIP Logic tool, or Compute Module |

## Workshop composition patterns

- Object set pipeline: Filter list → filtered object set variable → Object table + Object view + chart, all reading the same variable.
- Action-backed write-back: Button Group → Action (function-backed if complex) → object updated → variables refresh via subscription.
- Stepper / Status Tracker for guided multi-step workflows; combine with overlays for contextual modals.
- Loop layouts to render per-object embedded modules without copy-pasting widgets.
- Drag-and-drop: configure sections as drop zones; trigger events from drops.
- AIP Chatbot widget bound to Workshop variables so the chatbot can read filtered object sets and call Commands across the module.
- Custom widgets for bespoke React/TS UI; wrap external calls via Functions or webhooks because of the restrictive CSP.

## Best practices

- One object set variable per logical scope; chain transformations via additional filter variables rather than duplicating object sets.
- Use Flex sizing for resilient layouts; reserve Absolute for pixel-perfect needs.
- Push computation off the client: derived values → Pipeline; per-object real-time → Function; LLM orchestration → AIP Logic.
- Publish AIP Logic and AIP Chatbots as Functions when you need them in Automate, AIP Evals, Code Repositories, or OSDK.
- Use native tool calling in AIP Chatbots when supported — better speed and token efficiency, and parallel tool calls.
- Use Commands to drive cross-application orchestration from one chatbot.
- Run Evals before promoting any LLM-backed function across environments.

## Pitfalls

- Building a display-only dashboard in Workshop — that is usually a Quiver dashboard. Workshop's value is decision-making + writeback.
- Overloading a single AIP Logic block with many tools, causing token blow-up. Prefer specific Query Objects tools with selected properties.
- Forgetting that AIP Logic edits the Ontology only when called from an Action.
- Using AIP Agent widget legacy mode in new modules (deleted from Foundry 2026-05-01) — migrate to AIP Chatbot Studio.
- Embedding a Quiver dashboard in a branched Workshop module — Quiver elements load from main and are not modifiable on a branch.

## Workshop/AIP recent changes

- AIP Agent Studio → AIP Chatbot Studio rename (between 2026-04-09 and 2026-05).
- AIP Agent widget legacy mode deleted from Foundry 2026-05-01.
- AIP Document Intelligence GA 2026-02-04.
- Model Studio GA week of 2026-02-09.
- Slate is legacy; prefer Workshop / custom widgets / OSDK apps. Object Monitors sunset; Map series panel planned deprecation.

## Cross-cutting: Global Branching

(announcements/2026-05; global-branching/overview; global-branching/integrations)
- GA the week of 2026-05-18 (formerly Foundry Branching; beta from week of 2025-05-12).
- Lets you make changes across multiple applications on one branch, test end-to-end without disrupting production, and merge back into Main.
- Coverage at GA: transforms code repositories, TypeScript v1 functions repositories, Pipeline Builder, the Ontology, Workshop, AIP Logic, and Object Views.
- Key limitation: TypeScript v2 and Python functions CANNOT be modified on a branch. You may reference a specific version of such a function on a branch and test it before merging.
- TS v1 function branching requires `functions-typescript` template version 0.903.0+. It publishes pre-release versions on the branch; on merge, publishes the version target as stable on main and downstream consumers auto-switch.
- Proposals are the PR-equivalent: a branch taskbar shows modified resources; create a proposal, assign reviewers, run checks (rebasing, required approvals).
- Rebase auto-resolves non-conflicting changes; true conflicts (same property of same resource changed on main and branch) require a manual choice.
- Cost: each branch has compute and storage cost; modifying large object types on a branch can be expensive. Keep branches short-lived; use retention policies.

## Cross-cutting: release management and CI/CD

- Global Branching and release management are complementary. Use branching for in-development feature work merged to Main; use release management to deploy across distinct environments (dev → test → prod). Combine for multi-week features with schema changes.
- Branch protection in Pipeline Builder and Code Repositories; require proposals/reviewers on protected branches.
- Fallback branches in Pipeline Builder and Trained Model nodes resolve versions when branch-specific resources are absent.
- Function versioning: bind consumers to explicit version targets; pre-release on branches, stable on merge.
- Marketplace distributes pipelines, ontology types, functions (TS v2 + Python with OSDK), Workshop modules, Map templates, action types, and schedules across stacks.
- Apollo is the underlying autonomous deployment layer (out of scope here, referenced for completeness).

## Cross-cutting: security and governance

- Markings are mandatory controls: to access a resource, a user must be a member of all markings applied to it. Access is binary; markings propagate along file hierarchy and data dependencies. Do NOT use markings to provision access — they restrict eligibility (security/markings).
- Restricted Views apply row-level (and via mandatory control properties, property-level) permissions. They are downstream of a backing dataset and cannot be used as inputs to data transformations. They power object types whose row-level access depends on user attributes (security/restricted-views).
- Mandatory control properties on object types must map to a marking column on a restricted view, are required, and cannot be null (empty array allowed). For MDOs, each datasource can have its own mandatory control property, so users may see a subset of properties.
- Classification-Based Access Controls (CBAC): hierarchical + disjunctive (RELEASE TO) categories; configured with Palantir.
- Projects are the primary unit of role-based permissions (Owner/Editor/Viewer). Prefer project-scoped schedules and project-based ontology permissions over user-scoped.
- Organizations are top-level scoping. AIP is only considered enabled when AIP is enabled for all organization markings on the resource's project.
- Severing stops marking propagation downstream when content is sufficiently obfuscated (requires marking-removal permissions).
- Use Data Lineage simulation mode to preview a marking's downstream effect before applying.

## Cross-cutting recent changes

- 2026-05 — Global Branching GA.
- 2026-01 — Configurable markings on media reference properties GA.
- 2025-04 — Foundry Branching beta.
- 2024-10 — "Propagate view requirements" entered planned deprecation; migrate to markings.
- 2025-09 — Agent worker → agent proxy egress policies for on-prem connectivity.
- TS v2 / Python functions are not yet branch-modifiable in Global Branching as of May 2026.
