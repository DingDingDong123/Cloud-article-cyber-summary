# GCP Security Hardening Reference Guide Suite
## חבילת מדריכי הקשחה ל-Google Cloud Platform

מסמך אינדקס לחבילת ההקשחה. החבילה כוללת 17 מדריכי הקשחה (אחד לכל רכיב GCP), חוצים שמונה דומיינים, וכן חוברת Excel מרכזת של מצאי הבקרות. כל המדריכים בעברית עם מונחים טכניים באנגלית, ומיועדים לשימוש מקצועי על ידי צוותי תשתית ואבטחה.

תאריך: June 2026 — Confidential

---

## מבנה החבילה

כל מדריך בנוי מאותם חמישה חלקים: (1) פתיחה עם תרשים ארכיטקטורה, (2) למה ההקשחות — הסיכונים (MITRE ATT&CK ו-CIS GCP), (3) בקרות הקשחה (לכל בקרה: הסבר, בלוק Terraform ובלוק gcloud), (4) שלבי אימות (פקודות read-only בלבד), (5) מלכודות נפוצות.

| # | רכיב | דומיין | קובץ | בקרות |
|---|------|--------|------|-------|
| 1 | IAM Service Accounts | Identity & Access | hardening-iam-service-accounts.docx | 6 |
| 2 | IAM Policies | Identity & Access | hardening-iam-policies.docx | 7 |
| 3 | VPC Firewall | Networking | hardening-vpc-firewall.docx | 6 |
| 4 | VPC Network | Networking | hardening-vpc-network.docx | 7 |
| 5 | Load Balancer | Networking | hardening-load-balancer.docx | 6 |
| 6 | Compute Engine | Compute | hardening-gce.docx | 7 |
| 7 | Kubernetes Engine | Compute | hardening-gke.docx | 7 |
| 8 | Cloud Storage | Data | hardening-gcs.docx | 6 |
| 9 | Cloud SQL | Data | hardening-cloudsql.docx | 7 |
| 10 | BigQuery | Data | hardening-bigquery.docx | 6 |
| 11 | Cloud Logging | Detection & Response | hardening-cloud-logging.docx | 5 |
| 12 | Security Command Center | Detection & Response | hardening-scc.docx | 6 |
| 13 | Artifact Registry | Supply Chain | hardening-artifact-registry.docx | 5 |
| 14 | Cloud Build | Supply Chain | hardening-cloud-build.docx | 6 |
| 15 | OS Patch Management | Vulnerability Mgmt | hardening-os-patch.docx | 5 |
| 16 | Container Scanning | Vulnerability Mgmt | hardening-container-scanning.docx | 5 |
| 17 | Incident Response & Org Policy | IR & Compliance | hardening-incident-response.docx | 9 |

סך הכול: 106 בקרות הקשחה.

---

## חוברת מצאי הבקרות (Excel)

`gcp-hardening-control-inventory.xlsx` — ארבעה גליונות (כולם RTL):

1. **Index** — 17 הרכיבים, הדומיין, שם הקובץ, תיאור ומספר הבקרות.
2. **Control Inventory** — שורה לכל בקרה: רכיב, כותרת, סיכון ממותן, טכניקת MITRE ATT&CK, מזהה CIS GCP, משאב Terraform, וחומרה (קוד צבע: אדום=קריטי, כתום=גבוה, ירוק=בינוני).
3. **Validation Commands** — פקודות אימות read-only ופלט צפוי.
4. **Pitfalls Register** — מלכודות נפוצות, השלכה ותיקון מומלץ.

### עמודת Security Advisor Component ID

גליונות ה-Index וה-Control Inventory כוללים עמודה ריקה בשם `Security Advisor Component ID` (מסומנת ברקע צהוב). יש למלא בה את מזהה הרכיב המתאים ממאגר ה-Cloud Security Advisor (156 הרכיבים), כדי לקשר כל בקרה לרכיב שלה. העמודה סופקה כשלד מובנה למילוי.

---

## הנחות והנחיות תפעוליות

- כל בלוקי ה-Terraform וה-gcloud אומתו מול גרסת ספק `hashicorp/google` עדכנית (v7.x, יוני 2026).
- מצייני מקום בסוגריים מרובעים (למשל `[PROJECT_ID]`, `[ORG_ID]`, `[VPC_NAME]`) יש להחליף בערכים בפועל.
- בלוקי ה-Terraform מניחים הגדרת `provider "google"` ברמת ה-root.
- פקודות האימות בחלק 4 הן read-only בלבד ואינן משנות תצורה.
- פריסה היא תמיד ידנית — אין להטמיע אוטומציית deploy.
- מסגרת ההתייחסות היא ישראל בלבד (אין התייחסות ל-EU AI Act). מסגרות שנשען עליהן: MITRE ATT&CK, CIS GCP Benchmark, CIS GKE Benchmark.

---

## סדר יישום מומלץ

מומלץ ליישם לפי סדר הדומיינים: תחילה Identity & Access (בסיס הזהויות), אחר כך Networking (בידוד), Compute ו-Data (העומסים והנתונים), ולבסוף Detection, Supply Chain, Vulnerability Management ו-Incident Response. שכבת ה-Org Policy guardrails (במדריך IR) נאכפת ברמת ה-organization ומונעת רגרסיה.
