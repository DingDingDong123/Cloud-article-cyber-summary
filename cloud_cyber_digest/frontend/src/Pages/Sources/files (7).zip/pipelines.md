# Data Pipelines

Last researched: 2026-06-08. Sources are Palantir public docs (palantir.com/docs/foundry) and announcements; dates are given inline. Re-verify dated claims against announcements before production use.

## Contents
- Pipeline shapes
- Tool selection (full)
- Scheduling best practices
- Cost and performance patterns
- Incremental discipline
- Media sets
- Streaming
- External pipelines and transforms
- Canonical examples
- Pitfalls
- Recent changes and deprecations

## Pipeline shapes

Three core shapes plus a faster engine option (building-pipelines/pipeline-types, accessed 2026-06-08):
- Batch — full recompute each run.
- Incremental — process only new transactions; build on top of prior output.
- Streaming — continuous Flink compute.
- Faster pipelines — DataFusion/Rust single-node engine (formerly "lightweight"); supports batch and incremental shapes for small/medium data.

## Tool selection (full)

Default: Pipeline Builder. It is the path of least resistance — visual graph, broad Expressions/Transforms catalog, branching, preview, data expectations, and schedules built in, and it lets mixed-skill teams collaborate on the same pipeline.

Choose Faster (DataFusion) when data is small/medium and latency matters and you do NOT need LLM, geospatial, or media-set operations. General guideline from the older lightweight-pipelines doc: up to ~200M rows / ~50 GB uncompressed; the current "faster" doc (building-pipelines/create-faster-pipeline-pb) notes that for the right transform shapes the engine can handle terabyte-scale on a single node. Treat 200M/50 GB as guidance, not a hard limit. Conversion to/from Spark batch is one click.

Choose Code Repositories when you need pro-code control:
- Python (`transforms-python`): explicit `@incremental()` semantics (`allow_retention`, `strict_append`, `require_incremental`, `snapshot_inputs`, `semantic_version`), custom PyPI libraries, complex unit tests, `transforms-media` programmatic media handling, external transforms with Foundry-input access.
- Java (`transforms-java`): strong typing, JVM libraries, explicit per-transform incremental control via `DataFrameModificationType`/`FilesModificationType`.
- SQL: simple declarative batch for SQL-only contributors.

Choose Compute Modules for any-language containerized workloads, long-running stateful processes, custom/OSS model hosting, legacy code integration, or dynamic horizontal scaling under variable QPS. Two execution modes: functions mode (interactive, queryable from Workshop/Slate/OSDK) and pipeline mode (provenance-controlled inputs/outputs). Anti-pattern (compute-modules/overview): do not use Compute Modules to replace native Foundry features — generality comes at the cost of complexity.

Choose external pipelines (Databricks) when data already lives in Databricks/Unity Catalog. GA June 2025; extended to Pipeline Builder boards November 2025. Incremental Spark pushdown needs Unity Catalog external access.

## Scheduling best practices

(building-pipelines/scheduling-best-practices; optimizing-pipelines/usage-optimization)
- One schedule per dataset / one schedule per pipeline. A dataset built by two schedules causes queuing. Combine pipelines via connecting builds instead.
- Prefer event-based triggers over time-based for both freshness and cost. Compound triggers support AND/OR logic.
- Trim unnecessary runs: dropping weekend runs from a daily schedule that does not need them can save roughly 30% of batch compute for that pipeline.
- Add ~3 retries at 1–3 minute intervals.
- Use project-scoped schedules over user-scoped to avoid permission drift.
- Reserve force-build for Data Connection syncs only.

## Cost and performance patterns

- Maintain incremental performance with occasional SNAPSHOTs driven by a dummy input that builds on the intended snapshot schedule — do not hardcode snapshot timing into business logic.
- Use dataset projections to compact long incremental tails and to support different read patterns.
- Apply Spark profiles intentionally; profile with the Spark UI; use native acceleration where supported.
- Bound keyed state in streaming (windows/aggregations) to avoid hot-storage explosion.

## Incremental discipline

- Begin batch, extend to incremental (pipeline-types page). If you anticipate incrementality, write the batch pipeline in Python or Java, not SQL.
- Always design for the SNAPSHOT fallback: branch on `ctx.is_incremental` and unit-test the full-recompute path. Logic that silently assumes append-only inputs breaks when an upstream issues a SNAPSHOT.
- For joins, avoid reading both sides incrementally without special handling. Treat one side as a reference and read it fully where feasible.

## Media sets

(media-sets-advanced-formats/media-overview) Schema-typed collections of unstructured items. Transactional vs transactionless. Retention policies. Media references make items usable in the Ontology. Limits: 50 GB per file, 256-char path. Incremental media set inputs arrived in Pipeline Builder 2026-04-07, but mixing incremental dataset and incremental media set inputs in one pipeline is not yet supported.

## Streaming

(building-pipelines/streaming-overview) Flink-based. On average, streaming data is accessible in the Ontology and available in time-series apps (Quiver, Foundry Rules) in under 15 seconds. 1 MB per-row constraint. Object-Storage-V2 streaming uses most-recent-update-wins; weigh at-least-once vs exactly-once delivery for your use case.

## External pipelines and transforms

- External transforms (code) are now source-based; this supersedes the legacy egress-policy/credential-reference approach (data-connection/external-transforms).
- Agent proxy egress policies (2025-09) supersede the agent worker for on-prem connectivity; the agent proxy runtime is planned for sunset, so check current guidance.

## Canonical example — Python incremental transform

```python
from transforms.api import transform, incremental, Input, Output
from pyspark.sql import functions as F

@incremental(snapshot_inputs=['ref'], allow_retention=True, semantic_version=1)
@transform(
    out=Output('/clean/orders'),
    raw=Input('/raw/orders'),
    ref=Input('/ref/customer'),
)
def compute(ctx, out, raw, ref):
    new = raw.dataframe(mode='added')  # only new rows when incremental
    enriched = new.join(ref.dataframe(), 'customer_id', 'left')
    out.write_dataframe(
        enriched,
        output_mode='added' if ctx.is_incremental else 'replace',
    )
```

## Pitfalls

- Append-only assumptions that break on upstream SNAPSHOT. Always handle `is_incremental` both ways.
- Reading both join sides incrementally without a reference-side strategy.
- Unbounded streaming keyspace causing hot-storage growth.
- Using Pipeline Builder for per-object real-time logic that should be a Function or Automation.
- Mixing incremental dataset + media set inputs in one Pipeline Builder pipeline (unsupported as of 2026-04).
- Two schedules writing one dataset (queuing).

## Recent changes and deprecations

- 2026-04-07 — Incremental media set inputs in Pipeline Builder (mixing with incremental dataset inputs unsupported). (announcements/2026-04)
- 2026-04-02 — Trained model node in Pipeline Builder; Spark batch only; sidecar inference with branch-aware version resolution falling back to configured fallback branches, then master.
- 2025-11 — Pipeline Builder external pipelines push down to Databricks.
- 2025-06 — Virtual tables / Databricks pushdown / external models GA.
- 2025-09 — Agent proxy egress policies supersede agent worker.
- Lightweight pipelines → Faster pipelines (rename).
- Logic Flows and HyperAuto V1 marked sunset; migrate to current equivalents.
