---
name: foundry-build-guide
description: 'How to build well in Palantir Foundry — decision frameworks and best practices for data pipelines, the Ontology, Functions/Compute Modules, and Workshop/AIP. Use this skill whenever the user is designing, building, reviewing, or debugging anything in Palantir Foundry: pipelines (Pipeline Builder, Code Repositories, Compute Modules, incremental/streaming), ontology modeling (object/link/action types, OSDK, hydration), Functions or AIP Logic, Workshop apps, AIP Chatbots, branching/CI-CD, or markings/security. Trigger it even when the user names a specific feature ("should this be an action or a function?", "design a pipeline to hydrate my object", "AIP Logic vs a Function") rather than saying "Foundry". This skill carries the general HOW of building; for the users own object names, property names, and stack architecture, defer to their separate architecture skill (see "Composing with the architecture skill" below).'
---

# Building Well in Palantir Foundry

This skill captures the HOW of building in Foundry: which tool to reach for, the design patterns that hold up, and the pitfalls that bite. It does NOT hold the user's specific architecture (their object types, property names, ontology layout). For that, read their architecture skill — see the composition note at the end.

Last researched: 2026-06-08. To refresh: re-read https://www.palantir.com/docs/foundry/announcements/ plus the relevant section pages, and update the dated claims in the reference files. Foundry changes monthly; treat any undated claim as needing re-verification before it goes into production.

## How to use this skill

1. Identify which of the four build surfaces the task touches: pipelines, ontology, functions/compute, or workshop/AIP. Many tasks span two or more.
2. Apply the matching decision framework below to pick the right tool. The single most common Foundry mistake is the "Golden Hammer" — forcing one familiar tool onto every job.
3. For depth (canonical code, full pattern lists, full anti-pattern catalog, dated change logs), read the matching reference file:
   - Data pipelines → `references/pipelines.md`
   - Ontology → `references/ontology.md`
   - Functions and Compute Modules → `references/functions-compute.md`
   - Workshop and AIP → `references/workshop-aip.md`
4. For anything CI/CD, branching, or security-related, read the cross-cutting section in `references/workshop-aip.md` (Global Branching, markings, restricted views, projects).

## The five rules

1. Default to Pipeline Builder. Reach for Code Repositories or Compute Modules only when the docs explicitly call for pro-code or any-language workloads, and leave a one-line note on why.
2. Model the Ontology around business decisions, not source tables. Collapse system silos at ingest, not in the object layer.
3. Match the tool to the job: actions for human decisions, automations for event reactions, functions for real-time typed logic, AIP Logic for LLM workflows, Compute Modules for any-language/long-running, pipelines for anything pre-computable.
4. Every change goes through a Global Branch with a proposal and checks; bind consumers to explicit function versions.
5. Apply markings at ingest, enforce row-level access via restricted-view-backed object types, manage permissions through Projects, and never use markings to provision access.

## Decision framework 1 — Pipeline tooling

| Choose | When |
|---|---|
| Pipeline Builder (Spark/Flink) | Default for new pipelines. Visual graph, broad expression library, built-in branching/preview/expectations/schedules, mixed-skill collaboration. |
| Pipeline Builder — Faster (DataFusion) | Small/medium data, low-latency batch or incremental, when LLM/geospatial/media-set ops are NOT needed. One-click convert to/from Spark batch. |
| Code Repositories — Python | Need explicit `@incremental()` control, custom PyPI libraries, complex tests, programmatic media handling, or external transforms with Foundry-input access. |
| Code Repositories — Java | Strong typing, JVM libraries, explicit per-transform incremental control. |
| Code Repositories — SQL | Simple declarative batch for SQL-only contributors. |
| Compute Modules | Any-language containerized work, long-running stateful processes, custom/OSS model hosting, legacy code, variable-QPS autoscaling. |
| External pipelines (Databricks) | Data already lives in Databricks/Unity Catalog and re-ingestion is undesirable; push compute down via virtual tables. |

Rule of thumb: begin batch, extend to incremental. If you anticipate incrementality, write the batch pipeline in Python or Java rather than SQL so the path forward is open. Full detail, scheduling best practices, and the incremental example: `references/pipelines.md`.

## Decision framework 2 — Object vs link vs action vs function vs pipeline

| Need | Use |
|---|---|
| A real-world entity with persistent properties | Object type (one per entity, not per source system) |
| A semantic relationship between two entities | Link type — prefer one-to-many/foreign-key; reserve many-to-many for when you truly need it (it builds a separate link index with real volume/cost) |
| A human or agent decision that changes state | Action type (function-backed if logic is non-trivial) |
| A value derived purely from source columns | Pipeline — compute it upstream, not in a function |
| A reaction to an Ontology change | Automation, not a polling pipeline |
| A shape shared across multiple object types | Interface, not a wide sparse "God Object" |
| Real-time computation across objects | Function on Objects |

Full design principles, the eight canonical anti-patterns (System Silos, Kitchen Sink, God Object, Golden Hammer, Action Sprawl, Time Machine, Misnomer, Department Silos), and OSDK guidance: `references/ontology.md`.

## Decision framework 3 — AIP Logic vs Function vs Compute Module

| Need | Choose |
|---|---|
| LLM orchestration with prompt + tools, no-code, evaluable | AIP Logic |
| Sub-second typed Ontology read/write, low overhead | Function — TypeScript v2 (default; needed for Ontology interfaces) or Python (needed for Pipeline Builder UDFs / Pandas) |
| Webhook call from a function | TypeScript v1 function (webhooks are TS v1 only) |
| Compute-intensive, long-running, stateful, non-TS/non-Python, or model hosting | Compute Module (functions mode for interactive, pipeline mode for provenance) |

Default new Functions repos to TypeScript v2. Prefer serverless over deployed functions for most cases. Full matrix, the AIP Logic block-splitting rule, and canonical code: `references/functions-compute.md`.

## Decision framework 4 — Application layer

| Need | Choose |
|---|---|
| Multi-step LLM reasoning with Ontology tools, evaluation, human-in-the-loop | AIP Logic |
| Deterministic typed computation/transformation | Function (TS v2 / Python) |
| Conditional UX, simple aggregations, filter composition inside the app | Workshop variables and events (no function needed) |
| Conversational UI with sessions, multi-turn memory, application state | AIP Chatbot (built in AIP Chatbot Studio) |
| External-network call from app logic | TS v1 webhook, Python function via `functions.sources`, AIP Logic tool, or Compute Module |

Workshop's value is decision-making plus writeback. If a module only displays data, it probably should be a Quiver dashboard. Composition patterns, the AIP Chatbot Studio rename, and deprecations: `references/workshop-aip.md`.

## Critical currency flags (verify before relying)

- Global Branching (formerly Foundry Branching) went GA the week of 2026-05-18. It covers transforms repos, TS v1 functions repos, Pipeline Builder, the Ontology, Workshop, AIP Logic, and Object Views. TypeScript v2 and Python functions CANNOT yet be modified on a branch — you may only reference and test a specific version before merging. (announcements/2026-05; global-branching/integrations)
- AIP Agent Studio was renamed AIP Chatbot Studio (and AIP Agents → AIP Chatbots) between 2026-04-09 and 2026-05. The legacy mode of the AIP Agent widget was deprecated and deleted from Foundry on 2026-05-01. (announcements/2026-04)
- TypeScript v2 and Python functions went GA the week of 2025-07-28. (announcements/2025-07)
- AIP Document Intelligence went GA 2026-02-04. (announcements/2026-02)
- "Lightweight pipelines" were renamed "Faster pipelines" (DataFusion engine). Object Storage V1 (Phonograph) is in planned deprecation; use OSv2. Slate is legacy; prefer Workshop / custom widgets / OSDK apps.

## Composing with the architecture skill

This skill is the general "how to build in Foundry". The user maintains a SEPARATE architecture skill that holds their specific stack: their object types, link types, property names, and ontology layout. When a task needs concrete names ("hydrate my Project object", "AIP Logic over my findings"), pull those names from the architecture skill and apply the patterns here. If you cannot find the architecture skill, ask the user for the specific object/property names rather than inventing them.

Architecture skill reference (placeholder — the user wires this up internally): `<ARCHITECTURE_SKILL_NAME>`.
