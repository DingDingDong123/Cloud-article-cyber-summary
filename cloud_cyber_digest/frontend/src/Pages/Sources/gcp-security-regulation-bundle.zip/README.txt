GCP Security Regulation — Document Bundle
==========================================
Date: 06 May 2026
Status: Draft 0.1 — COMPLETE (10 of 10 documents)
Language: Hebrew (RTL) + English service names
Standards: CIS GCP Foundation v4.0.0 · CIS GKE v1.6 · NIST CSF 2.0 · NIST 800-53 R5
           SLSA v1.0 · NIST SSDF (SP 800-218) · NIST 800-61r2 · ISO 27035

Contents
--------
01-strategy-and-components.docx     (40 pages)  Strategic doc — defense in depth, shared
                                                responsibility, 9 regulated domains.

02-foundation-implementation.docx   (27 pages)  Org structure, Folders, Projects, Org Policies
                                                (25-row baseline), Tagging, Billing, Quotas.

03-iam-implementation.docx          (38 pages)  Workspace + Entra dual-IdP via WIF,
                                                Passkeys/FIDO2, JIT, GitHub Actions OIDC.

04-network-implementation.docx      (27 pages)  Shared VPC, Hierarchical Firewall, VPC-SC,
                                                Cloud Armor, Cloud NAT, PSC, DNS.

05-data-implementation.docx         (34 pages)  Classification framework, KMS/HSM/EKM,
                                                CMEK, Cloud Storage, BigQuery CLS/RLS,
                                                Cloud SQL, Secret Manager, DLP, Backup.

06-compute-implementation.docx      (33 pages)  Shielded VM, OS Login, Confidential VMs,
                                                GKE Autopilot, Pod Security Standards,
                                                Network Policy, Cloud Run, Cloud Functions,
                                                Binary Authorization with break-glass.

07-detection-implementation.docx    (27 pages)  Aggregated Sinks, SCC Enterprise, SecOps
                                                integration, 30-rule consolidated MITRE
                                                detection table, alert routing, auto-remediation.

08-supply-chain-implementation.docx (31 pages)  GitHub branch protection + signed commits,
                                                ephemeral runners, Artifact Registry hardening,
                                                Cosign keyless via Sigstore, SBOM + SLSA
                                                Provenance v1, SLSA Build L1-L3 roadmap.

09-vuln-mgmt-implementation.docx    (28 pages)  Risk-based prioritization (EPSS+KEV+CVSS),
                                                differentiated SLA matrix, Container Analysis,
                                                OS Config Patch with rollout strategy,
                                                Renovate automation, MTTP metrics.

10-ir-compliance-implementation.docx (33 pages) IR lifecycle, RACI, severity decision tree,
                                                5 detailed playbooks (SA Key, Public Bucket,
                                                GKE Crypto-mining, Account Takeover, Ransomware),
                                                forensic snapshot script, postmortem template,
                                                continuous compliance dashboard, regulatory
                                                notifications (GDPR 72h / CCPA / PCI / SEC 4-day).

Total: 318 pages of operator-grade content.

Each implementation doc follows the same template (sections 0-N + appendix):
  0. Scope, assumptions [ASM-XXX-NN], conventions
  1. Reference architecture (diagram)
  2-N. Per-control implementation (gcloud + Terraform + YAML where relevant)
  N+1. Audit, monitoring, detection rules (MITRE-mapped table)
  Verification commands
  Pitfalls & troubleshooting (callouts)
  Compliance mapping (CIS + NIST CSF + NIST 800-53 + framework-specific)
  A. Quick reference (top commands + references)

Conventions
-----------
- Green-bordered code blocks: gcloud / kubectl / bash / cosign commands
- Purple-bordered code blocks: Terraform (source of truth, IaC)
- Red-bordered code blocks: YAML (Org Policies, K8s manifests, GitHub Actions, Cloud Logging filters)
- Cyan-bordered code blocks: SQL (BigQuery RLS, Data Masking, scheduled queries)
- Callouts: ⚠️ אזהרה (warning), 🪤 מלכודת נפוצה (pitfall), 💡 טיפ (tip), ℹ️ הערה (note)

Reading order
-------------
For first-time readers: 01 Strategy → 02 Foundation → then any implementation doc by domain need.
For incident responders: 10 IR & Compliance first, then 07 Detection.
For platform engineers building from scratch: 02 → 03 → 04 in order, then domain-specific.
For auditors: any compliance mapping section (last section before appendix in each doc).
