/* === planner.js === */
// ═══════════════════════════════════════════════════════════════════════
// Cloud Security Project Planner — Round 1
// Phase navigation, Phase 1 form handling, minimal state persistence
// ═══════════════════════════════════════════════════════════════════════

const STORAGE_KEY = 'cspp_state_v1';

// ─── State ─────────────────────────────────────────────────────────────
let state = {
  currentPhase: 1,
  phasesCompleted: [],
  brief: {
    projectName: '',
    companyName: '',
    cloudProviders: [],
    projectDescription: '',
    projectType: '',
    projectTypeOther: '',
    environmentScale: '',
    compliance: [],
    date: new Date().toISOString().slice(0, 10),
  },
  // Phase 2-4 state lives here in future rounds:
  // selectedComponents: [],
  // selectedTools: [],
  // ...
};

// Load any saved state
try {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    const parsed = JSON.parse(saved);
    // Defensive merge — keep shape if keys go missing
    state = { ...state, ...parsed, brief: { ...state.brief, ...(parsed.brief || {}) } };
  }
} catch (e) {
  console.warn('Failed to load saved state:', e);
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn('Failed to save state:', e);
  }
}

// ─── Phase navigation ──────────────────────────────────────────────────
function showPhase(n) {
  state.currentPhase = n;
  saveState();
  document.querySelectorAll('.phase').forEach(el => el.classList.remove('active'));
  const phaseEl = document.getElementById(`phase-${n}`);
  if (phaseEl) phaseEl.classList.add('active');

  // Update progress indicators
  document.querySelectorAll('.progress-step').forEach((el, i) => {
    const phaseNum = i + 1;
    el.classList.remove('active', 'completed');
    if (phaseNum === n) el.classList.add('active');
    else if (state.phasesCompleted.includes(phaseNum)) el.classList.add('completed');
  });

  // Scroll to top so the user sees the new phase header
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Allow clicking completed phases to go back (only those already completed)
function wireProgressClicks() {
  document.querySelectorAll('.progress-step').forEach((el, i) => {
    el.addEventListener('click', () => {
      const phaseNum = i + 1;
      if (state.phasesCompleted.includes(phaseNum) || phaseNum === state.currentPhase) {
        showPhase(phaseNum);
      }
    });
  });
}

// ─── Phase 1 form handling ─────────────────────────────────────────────
function hydratePhase1Form() {
  // Populate fields from saved state
  const form = document.getElementById('brief-form');
  if (!form) return;
  form.projectName.value = state.brief.projectName || '';
  form.companyName.value = state.brief.companyName || '';
  form.projectDescription.value = state.brief.projectDescription || '';
  form.projectType.value = state.brief.projectType || '';
  form.projectTypeOther.value = state.brief.projectTypeOther || '';
  form.environmentScale.value = state.brief.environmentScale || '';
  form.date.value = state.brief.date || new Date().toISOString().slice(0, 10);

  // Cloud checkboxes
  document.querySelectorAll('input[name="cloudProviders"]').forEach(cb => {
    cb.checked = state.brief.cloudProviders.includes(cb.value);
    var pill = cb.closest('.check-pill'); if (pill) pill.classList.toggle('selected', cb.checked);
  });
  // Compliance checkboxes
  document.querySelectorAll('input[name="compliance"]').forEach(cb => {
    cb.checked = state.brief.compliance.includes(cb.value);
    var pill2 = cb.closest('.check-pill'); if (pill2) pill2.classList.toggle('selected', cb.checked);
  });

  // Show/hide "Other" project type field
  toggleProjectTypeOther();
}

function toggleProjectTypeOther() {
  const typeSelect = document.getElementById('projectType');
  const otherWrap = document.getElementById('projectTypeOther-wrap');
  if (typeSelect && otherWrap) {
    otherWrap.style.display = typeSelect.value === 'Other' ? 'block' : 'none';
  }
}

function readPhase1Form() {
  const form = document.getElementById('brief-form');
  return {
    projectName: form.projectName.value.trim(),
    companyName: form.companyName.value.trim(),
    cloudProviders: Array.from(document.querySelectorAll('input[name="cloudProviders"]:checked')).map(cb => cb.value),
    projectDescription: form.projectDescription.value.trim(),
    projectType: form.projectType.value,
    projectTypeOther: form.projectTypeOther.value.trim(),
    environmentScale: form.environmentScale.value,
    compliance: Array.from(document.querySelectorAll('input[name="compliance"]:checked')).map(cb => cb.value),
    date: form.date.value,
  };
}

function validatePhase1(brief) {
  const errors = {};
  if (!brief.projectName) errors.projectName = 'Project name is required';
  if (!brief.companyName) errors.companyName = 'Company / team name is required';
  if (brief.cloudProviders.length === 0) errors.cloudProviders = 'Select at least one cloud provider';
  if (!brief.projectDescription) errors.projectDescription = 'A brief description helps tailor the output';
  if (!brief.projectType) errors.projectType = 'Pick a project type';
  if (brief.projectType === 'Other' && !brief.projectTypeOther) errors.projectTypeOther = 'Describe the project type';
  if (!brief.environmentScale) errors.environmentScale = 'Pick an environment scale';
  return errors;
}

function showFieldErrors(errors) {
  // Clear previous
  document.querySelectorAll('.field.has-error').forEach(el => el.classList.remove('has-error'));
  document.querySelectorAll('.field-error').forEach(el => el.textContent = '');

  Object.entries(errors).forEach(([field, msg]) => {
    const el = document.querySelector(`[data-field="${field}"]`);
    if (el) {
      el.classList.add('has-error');
      const errorEl = el.querySelector('.field-error');
      if (errorEl) errorEl.textContent = msg;
    }
  });

  // Scroll to first error
  const firstError = document.querySelector('.field.has-error');
  if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function submitPhase1() {
  const brief = readPhase1Form();
  const errors = validatePhase1(brief);
  if (Object.keys(errors).length > 0) {
    showFieldErrors(errors);
    return;
  }
  // Save and advance
  state.brief = brief;
  if (!state.phasesCompleted.includes(1)) state.phasesCompleted.push(1);
  // Reset phase 2 step to 1 if entering wizard for first time
  if (!state.phase2 || state.phase2.currentStep == null) {
    state.phase2 = { currentStep: 1, selectedComponentIds: [], skippedSteps: [] };
  }
  saveState();

  if (typeof renderPhase2 === 'function') renderPhase2();
  showPhase(2);
}

function wireCheckPills() {
  document.querySelectorAll('.check-pill input[type="checkbox"]').forEach(cb => {
    // Click on pill toggles checkbox
    cb.closest('.check-pill').addEventListener('click', (e) => {
      // Avoid double-toggle when the user clicks the checkbox itself
      if (e.target !== cb) {
        cb.checked = !cb.checked;
      }
      cb.closest('.check-pill').classList.toggle('selected', cb.checked);
    });
    cb.addEventListener('change', () => {
      cb.closest('.check-pill').classList.toggle('selected', cb.checked);
    });
  });
}

// ─── Phase 2 entry — actual wizard logic lives in phase2.js ───────────
// (renderPhase2() is defined there; called from submitPhase1 and on boot)

// ─── Helpers ──────────────────────────────────────────────────────────
function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

// Reset / clear data — only triggered manually
function resetPlanner() {
  if (!confirm('Clear all entered data and start over?')) return;
  localStorage.removeItem(STORAGE_KEY);
  location.reload();
}

// ─── Boot ─────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  hydratePhase1Form();
  wireCheckPills();
  wireProgressClicks();

  var ptEl = document.getElementById('projectType'); if (ptEl) ptEl.addEventListener('change', toggleProjectTypeOther);
  var sbEl = document.getElementById('submit-brief'); if (sbEl) sbEl.addEventListener('click', submitPhase1);
  var rbEl = document.getElementById('reset-btn'); if (rbEl) rbEl.addEventListener('click', resetPlanner);

  // If user previously made it past Phase 1, restore Phase 2 wizard state
  if (state.phasesCompleted.includes(1) && state.currentPhase >= 2) {
    if (typeof renderPhase2 === 'function') renderPhase2();
  }
  // If user was in Phase 3, restore Phase 3 wizard state too
  if (state.currentPhase >= 3 && typeof renderPhase3 === 'function') {
    renderPhase3();
  }
  // If user was in Phase 4, regenerate the document
  if (state.currentPhase >= 4 && typeof renderPhase4 === 'function') {
    renderPhase4();
  }
  showPhase(state.currentPhase || 1);
});

// Expose for inline onclick
window.showPhase = showPhase;


/* ═══════════════════════════════════════════════════════ */

/* === phase2.js === */
// ═══════════════════════════════════════════════════════════════════════
// Round 2 — Component Selection Wizard
//
// 6-step wizard guiding the user through each Defense Layer:
//   1. Identity   2. Network   3. OS / Compute
//   4. Application 5. Data     6. Detection
// Then a final summary screen before advancing to Phase 3.
//
// State lives at state.phase2 = { currentStep, selectedComponentIds, skippedSteps }
// ═══════════════════════════════════════════════════════════════════════

const LAYERS = [
  {
    key: 'Identity',
    title: 'Identity & Access',
    help: 'Who can access what. IAM users, roles, identity federation, MFA, conditional access policies, privileged identity management.',
  },
  {
    key: 'Network',
    title: 'Network',
    help: 'Network topology and edge defense. VPCs/VNets, subnets, security groups, NSGs, firewalls, load balancers, CDN, DNS.',
  },
  {
    key: 'OS / Compute',
    title: 'OS / Compute',
    help: 'Where workloads run. VMs, containers, serverless functions, Kubernetes clusters.',
  },
  {
    key: 'Application',
    title: 'Application',
    help: 'Application-level surfaces. API gateways, app platforms, container registries, CI/CD pipelines, ML/AI services.',
  },
  {
    key: 'Data',
    title: 'Data & Storage',
    help: 'Where data lives. Object storage, relational and NoSQL databases, data warehouses, secrets/key management.',
  },
  {
    key: 'Detection',
    title: 'Detection & Monitoring',
    help: 'Visibility and threat detection. Audit logs, threat detection services, SIEMs, posture management.',
  },
];

// "Common" foundational components (curated names — avoids "all 17 selected"
// from a pure risk-score heuristic). Matched by component name.
const COMMON_COMPONENT_NAMES = new Set([
  // Identity
  'IAM', 'AWS IAM Identity Center', 'Microsoft Entra ID', 'Cloud IAM',
  'Conditional Access', 'Entra PIM (Privileged Identity Management)',
  // Network
  'VPC', 'Virtual Network (VNet)', 'AWS WAF', 'Azure Firewall', 'Cloud Armor',
  // OS / Compute
  'EC2', 'Virtual Machines', 'Compute Engine', 'Lambda', 'Azure Functions', 'Cloud Functions',
  // Application
  'API Gateway', 'ECR (Elastic Container Registry)', 'Container Registry', 'Artifact Registry',
  // Data
  'S3', 'Blob Storage', 'Cloud Storage',
  'RDS', 'Azure SQL Database', 'Cloud SQL',
  'Secrets Manager', 'Azure Key Vault', 'Secret Manager',
  // Detection
  'CloudTrail', 'Activity Log', 'Cloud Audit Logs',
  'GuardDuty', 'Defender for Cloud', 'Security Command Center',
]);

// Initialize phase 2 state
if (!state.phase2) {
  state.phase2 = {
    currentStep: 1, // 1-6 = layer steps, 7 = summary
    selectedComponentIds: [],
    skippedSteps: [],
  };
}

function riskAsInt(r) {
  if (typeof r === 'number') return r;
  var n = parseInt(r, 10);
  return isNaN(n) ? 0 : n;
}

function getComponentsForStep(stepNum) {
  if (stepNum < 1 || stepNum > 6) return [];
  var layer = LAYERS[stepNum - 1].key;
  var clouds = state.brief.cloudProviders || [];
  var all = (window.PLANNER_DATA && window.PLANNER_DATA.components) || [];
  return all.filter(function (c) {
    if (clouds.length > 0 && clouds.indexOf(c.cloud) === -1) return false;
    // Primary layer is the first one listed
    var primary = c.layers && c.layers[0];
    return primary === layer;
  });
}

function renderPhase2() {
  // Entry point — figure out what to render based on currentStep
  if (state.phase2.currentStep >= 7) {
    renderPhase2Summary();
  } else {
    renderWizardStep(state.phase2.currentStep);
  }
}

// ─── Step indicator ──────────────────────────────────────────────────
function renderStepBar() {
  var html = '<div class="wizard-step-bar">';
  for (var i = 1; i <= 6; i++) {
    var cls = 'step-dot';
    var hasSelection = false;
    var skipped = state.phase2.skippedSteps.indexOf(i) !== -1;
    // A step is "completed" if user has at least one component selected from that layer
    if (skipped) {
      cls += ' skipped';
    } else if (i < state.phase2.currentStep) {
      cls += ' completed';
    } else if (i === state.phase2.currentStep) {
      cls += ' active';
    }
    html += '<div class="' + cls + '" data-step="' + i + '">' +
            '<span class="circle">' + i + '</span>' +
            '<span>' + escapeHtml(LAYERS[i - 1].title) + '</span>' +
            '</div>';
  }
  html += '</div>';
  return html;
}

// ─── Render a single wizard step ─────────────────────────────────────
function renderWizardStep(stepNum) {
  var container = document.getElementById('phase-2-content');
  if (!container) return;

  var layer = LAYERS[stepNum - 1];
  var components = getComponentsForStep(stepNum);
  var selected = new Set(state.phase2.selectedComponentIds);
  var totalSelected = state.phase2.selectedComponentIds.length;

  // Apply local search & cloud filter (client-side; not persisted)
  var search = (window._wizardSearch || '').toLowerCase();
  var cloudFilter = window._wizardCloudFilter || null; // null = all

  var visible = components.filter(function (c) {
    if (cloudFilter && c.cloud !== cloudFilter) return false;
    if (search) {
      var hay = (c.name + ' ' + (c.category || '') + ' ' + (c.purpose || '')).toLowerCase();
      if (hay.indexOf(search) === -1) return false;
    }
    return true;
  });

  // Cloud filter row — only shows clouds the user picked in Phase 1 with components in this layer
  var availableCloudsInStep = {};
  components.forEach(function (c) { availableCloudsInStep[c.cloud] = true; });
  var availableClouds = Object.keys(availableCloudsInStep);

  var cloudFilterHtml = '';
  if (availableClouds.length > 1) {
    cloudFilterHtml = '<div class="cloud-filter-row">';
    cloudFilterHtml += '<div class="cloud-filter ' + (cloudFilter == null ? 'active' : '') + '" data-cloud="">All</div>';
    availableClouds.forEach(function (cl) {
      cloudFilterHtml += '<div class="cloud-filter ' + (cloudFilter === cl ? 'active' : '') + '" data-cloud="' + cl + '">' +
                         '<span class="badge ' + cl.toLowerCase() + '"></span>' + cl +
                         '</div>';
    });
    cloudFilterHtml += '</div>';
  }

  // Component grid
  var gridHtml;
  if (visible.length === 0) {
    if (components.length === 0) {
      gridHtml = '<div class="empty-grid">No components in this layer for your selected clouds. You can skip this step.</div>';
    } else {
      gridHtml = '<div class="empty-grid">No components match your search/filter.</div>';
    }
  } else {
    gridHtml = '<div class="component-grid">';
    visible.forEach(function (c) {
      var isSel = selected.has(c.id);
      var risk = riskAsInt(c.risk);
      var riskCls = risk >= 9 ? 'crit' : (risk >= 7 ? 'high' : '');
      gridHtml +=
        '<div class="component-card ' + (isSel ? 'selected' : '') + '" data-id="' + c.id + '">' +
          '<div class="card-top">' +
            (c.iconUri
              ? '<span class="comp-icon"><img src="' + c.iconUri + '" alt=""></span>'
              : '<span class="comp-icon no-icon">' + (c.cloud[0] || '?') + '</span>') +
            '<div class="name">' + escapeHtml(c.name) + '</div>' +
          '</div>' +
          '<div class="meta-row">' +
            '<span class="cloud-tag ' + c.cloud.toLowerCase() + '">' + c.cloud + '</span>' +
            '<span class="risk-tag ' + riskCls + '">Risk ' + risk + '/10</span>' +
            (c.category ? '<span class="category">' + escapeHtml(c.category) + '</span>' : '') +
          '</div>' +
          (c.purpose ? '<div class="purpose">' + escapeHtml(c.purpose) + '</div>' : '') +
        '</div>';
    });
    gridHtml += '</div>';
  }

  // Selected-in-this-step counter (just for this layer)
  var thisStepSelectedCount = components.filter(function (c) { return selected.has(c.id); }).length;

  container.innerHTML =
    renderStepBar() +
    '<div class="wizard-step-header">' +
      '<div>' +
        '<div class="step-meta">STEP ' + stepNum + ' OF 6</div>' +
        '<h3>' + escapeHtml(layer.title) + '</h3>' +
        '<div class="step-help">' + escapeHtml(layer.help) + '</div>' +
      '</div>' +
      '<div class="right">' +
        '<div class="total-selected">' + totalSelected + ' selected total</div>' +
        '<div style="margin-top:6px; font-size:11px;">' + thisStepSelectedCount + ' in this layer</div>' +
      '</div>' +
    '</div>' +
    '<div class="wizard-toolbar">' +
      '<div class="search-wrap"><input class="search" type="text" placeholder="Search components..." value="' + escapeHtml(search) + '" id="wizard-search"></div>' +
      '<button class="btn-mini" data-action="select-common" title="Select foundational components (IAM, VPC, etc.)">+ Common</button>' +
      '<button class="btn-mini" data-action="select-all" title="Select all components in this layer">+ All</button>' +
      '<button class="btn-mini danger" data-action="clear-layer" title="Clear selections in this layer only">Clear layer</button>' +
    '</div>' +
    cloudFilterHtml +
    gridHtml +
    '<div class="wizard-nav">' +
      '<div class="left-group">' +
        (stepNum > 1
          ? '<button class="btn-secondary" data-action="back">← Back</button>'
          : '<button class="btn-secondary" data-action="back-to-brief">← Edit brief</button>') +
        '<button class="btn-mini" data-action="skip">Skip this layer</button>' +
      '</div>' +
      '<button class="btn-primary" data-action="next">' +
        (stepNum < 6 ? 'Next: ' + escapeHtml(LAYERS[stepNum].title) + ' →' : 'Review selections →') +
      '</button>' +
    '</div>';

  wireWizardEvents();
}

function wireWizardEvents() {
  // Component cards toggle
  document.querySelectorAll('.component-card').forEach(function (card) {
    card.addEventListener('click', function () {
      var id = parseInt(card.dataset.id, 10);
      toggleComponent(id);
    });
  });

  // Search input
  var searchEl = document.getElementById('wizard-search');
  if (searchEl) {
    searchEl.addEventListener('input', function () {
      window._wizardSearch = searchEl.value;
      // Re-render only the grid + toolbar (cheap full re-render)
      renderWizardStep(state.phase2.currentStep);
      // Restore focus
      var newSearch = document.getElementById('wizard-search');
      if (newSearch) {
        newSearch.focus();
        newSearch.setSelectionRange(searchEl.value.length, searchEl.value.length);
      }
    });
  }

  // Cloud filters
  document.querySelectorAll('.cloud-filter').forEach(function (el) {
    el.addEventListener('click', function () {
      window._wizardCloudFilter = el.dataset.cloud || null;
      renderWizardStep(state.phase2.currentStep);
    });
  });

  // Toolbar buttons
  document.querySelectorAll('[data-action]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var action = btn.dataset.action;
      switch (action) {
        case 'select-common': selectCommonInStep(state.phase2.currentStep); break;
        case 'select-all': selectAllInStep(state.phase2.currentStep); break;
        case 'clear-layer': clearLayerSelection(state.phase2.currentStep); break;
        case 'back': goPrev(); break;
        case 'back-to-brief': showPhase(1); break;
        case 'skip': skipStep(); break;
        case 'next': goNext(); break;
        case 'back-to-wizard': state.phase2.currentStep = 6; saveState(); renderPhase2(); break;
        case 'continue-to-phase3':
          // Initialize phase 3 state if first entry
          if (!state.phase3 || state.phase3.currentStep == null) {
            state.phase3 = {
              currentStep: 1,
              selectedToolKeys: [],
              detectionStatus: {},
              selectedDashboardIds: [],
              logTierStrategy: { must: 'ingest-all', should: 'sample', nice: 'defer' },
              expandedGroups: {},
            };
            saveState();
          }
          showPhase(3);
          if (typeof renderPhase3 === 'function') renderPhase3();
          break;
      }
    });
  });

  // Step bar — clicking back to a previous step
  document.querySelectorAll('.wizard-step-bar .step-dot').forEach(function (dot) {
    var stepNum = parseInt(dot.dataset.step, 10);
    if (stepNum < state.phase2.currentStep || state.phase2.skippedSteps.indexOf(stepNum) !== -1) {
      dot.style.cursor = 'pointer';
      dot.addEventListener('click', function () {
        // Remove from skipped if user clicks a skipped step
        var skipIdx = state.phase2.skippedSteps.indexOf(stepNum);
        if (skipIdx !== -1) state.phase2.skippedSteps.splice(skipIdx, 1);
        state.phase2.currentStep = stepNum;
        saveState();
        renderPhase2();
      });
    }
  });
}

// ─── Selection actions ───────────────────────────────────────────────
function toggleComponent(id) {
  var idx = state.phase2.selectedComponentIds.indexOf(id);
  if (idx === -1) {
    state.phase2.selectedComponentIds.push(id);
  } else {
    state.phase2.selectedComponentIds.splice(idx, 1);
  }
  saveState();
  renderWizardStep(state.phase2.currentStep);
}

function selectCommonInStep(stepNum) {
  var components = getComponentsForStep(stepNum);
  components.forEach(function (c) {
    if (COMMON_COMPONENT_NAMES.has(c.name) &&
        state.phase2.selectedComponentIds.indexOf(c.id) === -1) {
      state.phase2.selectedComponentIds.push(c.id);
    }
  });
  saveState();
  renderWizardStep(stepNum);
}

function selectAllInStep(stepNum) {
  var components = getComponentsForStep(stepNum);
  // Apply current filters when "select all" — only what's visible, to avoid surprise
  var search = (window._wizardSearch || '').toLowerCase();
  var cloudFilter = window._wizardCloudFilter || null;
  components.forEach(function (c) {
    if (cloudFilter && c.cloud !== cloudFilter) return;
    if (search) {
      var hay = (c.name + ' ' + (c.category || '') + ' ' + (c.purpose || '')).toLowerCase();
      if (hay.indexOf(search) === -1) return;
    }
    if (state.phase2.selectedComponentIds.indexOf(c.id) === -1) {
      state.phase2.selectedComponentIds.push(c.id);
    }
  });
  saveState();
  renderWizardStep(stepNum);
}

function clearLayerSelection(stepNum) {
  var components = getComponentsForStep(stepNum);
  var ids = components.map(function (c) { return c.id; });
  state.phase2.selectedComponentIds = state.phase2.selectedComponentIds.filter(function (id) {
    return ids.indexOf(id) === -1;
  });
  saveState();
  renderWizardStep(stepNum);
}

// ─── Step navigation ─────────────────────────────────────────────────
function goNext() {
  // Reset local search/filter when moving steps
  window._wizardSearch = '';
  window._wizardCloudFilter = null;

  // If user had this step in skipped list and now they're advancing, remove it
  // (in case they came back, made selections, and are moving on)
  var thisStep = state.phase2.currentStep;
  var components = getComponentsForStep(thisStep);
  var hasSelection = components.some(function (c) {
    return state.phase2.selectedComponentIds.indexOf(c.id) !== -1;
  });
  if (hasSelection) {
    var idx = state.phase2.skippedSteps.indexOf(thisStep);
    if (idx !== -1) state.phase2.skippedSteps.splice(idx, 1);
  }

  if (state.phase2.currentStep < 6) {
    state.phase2.currentStep += 1;
    saveState();
    renderPhase2();
  } else {
    state.phase2.currentStep = 7;
    saveState();
    renderPhase2();
  }
}

function goPrev() {
  window._wizardSearch = '';
  window._wizardCloudFilter = null;
  if (state.phase2.currentStep > 1) {
    state.phase2.currentStep -= 1;
    saveState();
    renderPhase2();
  }
}

function skipStep() {
  var stepNum = state.phase2.currentStep;
  if (state.phase2.skippedSteps.indexOf(stepNum) === -1) {
    state.phase2.skippedSteps.push(stepNum);
  }
  // Don't deselect components if user already picked some — they may have
  // chosen a few then decided to skip the rest of this layer.
  goNext();
}

// ─── Final summary screen (step 7) ───────────────────────────────────
function renderPhase2Summary() {
  var container = document.getElementById('phase-2-content');
  if (!container) return;

  var allComponents = (window.PLANNER_DATA && window.PLANNER_DATA.components) || [];
  var byId = {};
  allComponents.forEach(function (c) { byId[c.id] = c; });

  var selectedIds = state.phase2.selectedComponentIds;
  var totalSelected = selectedIds.length;

  // Group selections by layer
  var byLayer = {};
  LAYERS.forEach(function (l) { byLayer[l.key] = []; });
  selectedIds.forEach(function (id) {
    var c = byId[id];
    if (!c) return;
    var primary = c.layers && c.layers[0];
    if (byLayer[primary]) byLayer[primary].push(c);
  });

  // Count layers with at least one selection
  var layersUsed = LAYERS.filter(function (l) { return byLayer[l.key].length > 0; }).length;

  // Build per-layer summary blocks
  var blocksHtml = '<div class="summary-by-layer">';
  LAYERS.forEach(function (l, i) {
    var stepNum = i + 1;
    var items = byLayer[l.key];
    var skipped = state.phase2.skippedSteps.indexOf(stepNum) !== -1;
    var isEmpty = items.length === 0 && !skipped;
    var blockCls = 'summary-layer-block';
    if (skipped) blockCls += ' skipped';
    else if (isEmpty) blockCls += ' empty';

    blocksHtml += '<div class="' + blockCls + '">';
    blocksHtml += '<h4>' + escapeHtml(l.title) + '</h4>';
    if (skipped) {
      blocksHtml += '<div class="layer-count">Skipped</div>';
      blocksHtml += '<div class="empty-text">No components selected — will be excluded from the document.</div>';
    } else if (items.length === 0) {
      blocksHtml += '<div class="layer-count">0 components</div>';
      blocksHtml += '<div class="empty-text">No selections in this layer.</div>';
    } else {
      blocksHtml += '<div class="layer-count">' + items.length + ' component' + (items.length === 1 ? '' : 's') + '</div>';
      items.forEach(function (c) {
        blocksHtml += '<div class="item">' +
                      '<span class="badge ' + c.cloud.toLowerCase() + '"></span>' +
                      escapeHtml(c.name) +
                      '</div>';
      });
    }
    blocksHtml += '</div>';
  });
  blocksHtml += '</div>';

  // Banner with the headline number
  var summaryLine = totalSelected === 0
    ? 'You haven\'t selected any components yet. Go back and add at least a few before continuing.'
    : 'You\'ve selected ' + totalSelected + ' component' + (totalSelected === 1 ? '' : 's') +
      ' across ' + layersUsed + ' defense layer' + (layersUsed === 1 ? '' : 's') + '.';

  container.innerHTML =
    renderStepBar() +
    '<div class="wizard-step-header">' +
      '<div>' +
        '<div class="step-meta">REVIEW</div>' +
        '<h3>Your component selections</h3>' +
        '<div class="step-help">Verify what you\'ve picked. Click any layer to go back and edit.</div>' +
      '</div>' +
    '</div>' +
    '<div class="summary-banner">' +
      '<div class="lead">' + escapeHtml(summaryLine) + '</div>' +
      '<div class="stat"><div class="num">' + totalSelected + '</div><div class="label">components</div></div>' +
      '<div class="stat"><div class="num">' + layersUsed + '/6</div><div class="label">layers</div></div>' +
    '</div>' +
    blocksHtml +
    '<div class="wizard-nav">' +
      '<button class="btn-secondary" data-action="back-to-wizard">← Back to wizard</button>' +
      '<button class="btn-primary" data-action="continue-to-phase3"' +
        (totalSelected === 0 ? ' disabled title="Select at least one component"' : '') +
        '>Continue to Security Stack →</button>' +
    '</div>';

  // Re-wire after innerHTML change
  wireWizardEvents();

  // Mark phase 2 as completed when user reaches summary with selections
  if (totalSelected > 0 && state.phasesCompleted.indexOf(2) === -1) {
    state.phasesCompleted.push(2);
    saveState();
    // Refresh the top progress bar
    document.querySelectorAll('.progress-step').forEach(function (el, i) {
      if ((i + 1) === 2) el.classList.add('completed');
    });
  }
}

// Hook so the existing showPhase() calls Phase 2 rendering
window.renderPhase2 = renderPhase2;


/* ═══════════════════════════════════════════════════════ */

/* === phase3.js === */
// ═══════════════════════════════════════════════════════════════════════
// Round 3 — Security Stack Builder
//
// 4-step sub-wizard:
//   3.1 Defense Tools Selection — per-component, grouped Native/3rd-party/OSS
//   3.2 Detection Coverage — table with severity filter + status toggles
//   3.3 SecOps Dashboards — relevance-scored cards, auto-recommend top 5
//   3.4 Log Strategy — MUST/Should/Nice tier picker + per-component event view
//   3.5 Summary — review before Phase 4
//
// State: state.phase3 = { currentStep, selectedToolKeys, detectionStatus,
//                         selectedDashboardIds, logTierStrategy, expandedGroups }
// ═══════════════════════════════════════════════════════════════════════

const PHASE3_STEPS = [
  { key: 'tools',      title: 'Defense Tools' },
  { key: 'detections', title: 'Detection Coverage' },
  { key: 'dashboards', title: 'SecOps Dashboards' },
  { key: 'logs',       title: 'Log Strategy' },
];

// Initialize phase 3 state
if (!state.phase3) {
  state.phase3 = {
    currentStep: 1,         // 1-4 = sub-steps, 5 = summary
    selectedToolKeys: [],   // composite keys: "componentId:toolName"
    detectionStatus: {},    // detectionId → "will" | "notnow" | "have"
    selectedDashboardIds: [],
    logTierStrategy: {
      must: 'ingest-all',
      should: 'sample',
      nice: 'defer',
    },
    expandedGroups: {},     // componentId → bool (for collapsible sections)
  };
}

// ─── Helpers ─────────────────────────────────────────────────────────
function getSelectedComponents() {
  // Returns full component objects for the user's Phase 2 selections
  var selectedIds = (state.phase2 && state.phase2.selectedComponentIds) || [];
  var allComponents = (window.PLANNER_DATA && window.PLANNER_DATA.components) || [];
  var byId = {};
  allComponents.forEach(function (c) { byId[c.id] = c; });
  return selectedIds.map(function (id) { return byId[id]; }).filter(Boolean);
}

function getToolKey(componentId, toolName) {
  return componentId + ':' + toolName;
}

// ─── Phase 3 entry point ─────────────────────────────────────────────
function renderPhase3() {
  if (state.phase3.currentStep >= 5) {
    renderPhase3Summary();
  } else {
    renderPhase3Step(state.phase3.currentStep);
  }
}

function renderP3StepBar() {
  var html = '<div class="p3-substep-bar">';
  for (var i = 1; i <= 4; i++) {
    var cls = 'p3-substep';
    if (i === state.phase3.currentStep) cls += ' active';
    else if (i < state.phase3.currentStep) cls += ' completed';
    html += '<div class="' + cls + '" data-p3step="' + i + '">' +
            '<span class="num">' + i + '</span>' +
            '<span>' + escapeHtml(PHASE3_STEPS[i - 1].title) + '</span>' +
            '</div>';
  }
  html += '</div>';
  return html;
}

function renderPhase3Step(stepNum) {
  var container = document.getElementById('phase-3-content');
  if (!container) return;

  var stepKey = PHASE3_STEPS[stepNum - 1].key;
  var bodyHtml = '';
  switch (stepKey) {
    case 'tools':      bodyHtml = renderStep31Tools(); break;
    case 'detections': bodyHtml = renderStep32Detections(); break;
    case 'dashboards': bodyHtml = renderStep33Dashboards(); break;
    case 'logs':       bodyHtml = renderStep34Logs(); break;
  }

  container.innerHTML = renderP3StepBar() + bodyHtml + renderP3Nav(stepNum);
  wireP3Events();
}

function renderP3Nav(stepNum) {
  return '<div class="wizard-nav">' +
    '<div class="left-group">' +
      (stepNum > 1
        ? '<button class="btn-secondary" data-p3action="prev">← Back</button>'
        : '<button class="btn-secondary" data-p3action="back-to-phase2">← Back to components</button>') +
    '</div>' +
    '<button class="btn-primary" data-p3action="next">' +
      (stepNum < 4 ? 'Next: ' + escapeHtml(PHASE3_STEPS[stepNum].title) + ' →' : 'Review security stack →') +
    '</button>' +
  '</div>';
}

// ─── Step 3.1 — Defense Tools ────────────────────────────────────────
function renderStep31Tools() {
  var components = getSelectedComponents();
  var allTools = (window.PLANNER_DATA && window.PLANNER_DATA.tools) || [];
  var selected = new Set(state.phase3.selectedToolKeys);

  if (components.length === 0) {
    return '<div class="p3-empty-state">No components selected. Go back to Phase 2 to pick components first.</div>';
  }

  // Group tools by ComponentID — only for components the user selected
  var componentIds = new Set(components.map(function (c) { return c.id; }));
  var toolsByComponent = {};
  allTools.forEach(function (t) {
    if (!componentIds.has(t.componentId)) return;
    if (!toolsByComponent[t.componentId]) toolsByComponent[t.componentId] = [];
    toolsByComponent[t.componentId].push(t);
  });

  var totalTools = 0, totalSelected = 0;
  components.forEach(function (c) {
    var ts = toolsByComponent[c.id] || [];
    totalTools += ts.length;
    ts.forEach(function (t) {
      if (selected.has(getToolKey(c.id, t.name))) totalSelected++;
    });
  });

  // Component sections
  var groupsHtml = components.map(function (c) {
    var tools = toolsByComponent[c.id] || [];
    var native = tools.filter(function (t) { return t.type === 'Native'; });
    var thirdparty = tools.filter(function (t) { return t.type === 'Third-Party'; });
    var oss = tools.filter(function (t) { return t.type === 'OSS'; });
    var recommended = tools.filter(function (t) { return t.type === 'Recommended'; });
    var selectedInGroup = tools.filter(function (t) {
      return selected.has(getToolKey(c.id, t.name));
    }).length;
    var isExpanded = state.phase3.expandedGroups[c.id] !== false; // default expanded

    function renderToolList(list, subgroupClass, subgroupLabel) {
      if (list.length === 0) return '';
      var pillsHtml = list.map(function (t) {
        var key = getToolKey(c.id, t.name);
        var isSelected = selected.has(key);
        return '<div class="tool-pill ' + (isSelected ? 'selected' : '') +
               '" data-tool-key="' + escapeHtml(key) + '">' +
               '<span class="check"></span>' +
               '<span class="name">' + escapeHtml(t.name) + '</span>' +
               (t.vendor ? '<span class="vendor">' + escapeHtml(t.vendor) + '</span>' : '') +
               '</div>';
      }).join('');
      return '<div class="tool-subgroup">' +
        '<div class="tool-subgroup-label ' + subgroupClass + '">' +
          '<span class="marker"></span>' + subgroupLabel + ' (' + list.length + ')' +
        '</div>' +
        '<div class="tool-list">' + pillsHtml + '</div>' +
      '</div>';
    }

    return '<div class="p3-group ' + (isExpanded ? 'expanded' : '') + '" data-component-id="' + c.id + '">' +
      '<div class="p3-group-header" data-toggle-group="' + c.id + '">' +
        '<div class="left">' +
          '<span class="chev">▶</span>' +
          '<span class="cloud-tag ' + c.cloud.toLowerCase() + '">' + c.cloud + '</span>' +
          (c.iconUri
            ? '<span class="comp-icon sm"><img src="' + c.iconUri + '" alt=""></span>'
            : '') +
          '<span class="title">' + escapeHtml(c.name) + '</span>' +
        '</div>' +
        '<div class="right">' +
          '<span class="count-pill ' + (selectedInGroup > 0 ? 'has-selection' : '') + '">' +
            selectedInGroup + ' / ' + tools.length + ' selected' +
          '</span>' +
        '</div>' +
      '</div>' +
      '<div class="p3-group-body">' +
        (tools.length === 0
          ? '<div style="color:var(--text-muted); font-style:italic; padding:8px 0;">No tools cataloged for this component.</div>'
          : (renderToolList(native, 'native', 'Native') +
             renderToolList(thirdparty, 'thirdparty', 'Third-Party') +
             renderToolList(recommended, 'recommended', 'Recommended') +
             renderToolList(oss, 'oss', 'OSS'))) +
      '</div>' +
    '</div>';
  }).join('');

  return '<div class="phase-header">' +
      '<h2>Pick your security tooling</h2>' +
      '<p>For each component, select the defense tools you have or plan to use. Native = built-in cloud tools; Third-Party = commercial; OSS = open source.</p>' +
    '</div>' +
    '<div class="p3-stat-strip">' +
      '<div class="p3-stat"><div class="num success">' + totalSelected + '</div><div class="label">Tools selected</div></div>' +
      '<div class="p3-stat"><div class="num muted">' + totalTools + '</div><div class="label">Total available</div></div>' +
      '<div class="p3-stat"><div class="num">' + components.length + '</div><div class="label">Components covered</div></div>' +
    '</div>' +
    '<div class="p3-toolbar">' +
      '<button class="btn-mini" data-p3action="expand-all">Expand all</button>' +
      '<button class="btn-mini" data-p3action="collapse-all">Collapse all</button>' +
      '<button class="btn-mini" data-p3action="select-all-native">+ All Native</button>' +
      '<button class="btn-mini danger" data-p3action="clear-tools">Clear all</button>' +
    '</div>' +
    groupsHtml;
}

// ─── Step 3.2 — Detection Coverage ───────────────────────────────────
function renderStep32Detections() {
  var components = getSelectedComponents();
  var allDetections = (window.PLANNER_DATA && window.PLANNER_DATA.detections) || [];
  var componentIds = new Set(components.map(function (c) { return c.id; }));
  var byId = {};
  components.forEach(function (c) { byId[c.id] = c; });

  // Filter to detections for selected components
  var relevantDetections = allDetections.filter(function (d) {
    return componentIds.has(d.componentId);
  });

  // Apply filters from local state
  var sevFilter = window._p3SevFilter || 'all';
  var statusFilter = window._p3StatusFilter || 'all';

  var filtered = relevantDetections.filter(function (d) {
    if (sevFilter !== 'all') {
      var sev = (d.severity || '').toLowerCase();
      if (sevFilter === 'crit' && sev !== 'critical') return false;
      if (sevFilter === 'high+' && sev !== 'critical' && sev !== 'high') return false;
    }
    if (statusFilter !== 'all') {
      var st = state.phase3.detectionStatus[d.id] || 'pending';
      if (statusFilter !== st) return false;
    }
    return true;
  });

  // Stats
  var statusCounts = { will: 0, notnow: 0, have: 0, pending: 0 };
  relevantDetections.forEach(function (d) {
    var st = state.phase3.detectionStatus[d.id] || 'pending';
    statusCounts[st] = (statusCounts[st] || 0) + 1;
  });

  function sevClass(s) {
    s = (s || '').toLowerCase();
    if (s === 'critical') return 'crit';
    if (s === 'high') return 'high';
    if (s === 'medium') return 'med';
    return 'low';
  }

  var rowsHtml = filtered.length === 0
    ? '<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted); font-style:italic;">No detections match your filters.</td></tr>'
    : filtered.map(function (d) {
        var c = byId[d.componentId];
        var status = state.phase3.detectionStatus[d.id] || 'pending';
        return '<tr data-detection-id="' + d.id + '">' +
          '<td><div class="det-name">' + escapeHtml(d.name || '') + '</div>' +
              '<div class="det-component">' + escapeHtml(c ? c.name : '') + '</div></td>' +
          '<td><span class="severity-badge ' + sevClass(d.severity) + '">' +
              escapeHtml(d.severity || 'Medium') + '</span></td>' +
          '<td class="det-platform">' + escapeHtml((d.platform || '').slice(0, 40)) + '</td>' +
          '<td class="det-mitre">' + escapeHtml(d.mitre || '') + '</td>' +
          '<td><div class="det-status-group">' +
            '<button class="det-status-btn will ' + (status === 'will' ? 'active' : '') +
              '" data-det-id="' + d.id + '" data-status="will">Will</button>' +
            '<button class="det-status-btn have ' + (status === 'have' ? 'active' : '') +
              '" data-det-id="' + d.id + '" data-status="have">Have</button>' +
            '<button class="det-status-btn notnow ' + (status === 'notnow' ? 'active' : '') +
              '" data-det-id="' + d.id + '" data-status="notnow">Skip</button>' +
          '</div></td>' +
        '</tr>';
      }).join('');

  return '<div class="phase-header">' +
      '<h2>Detection coverage plan</h2>' +
      '<p>For each detection available for your components, mark whether you will implement it, already have it, or are skipping for now.</p>' +
    '</div>' +
    '<div class="p3-stat-strip">' +
      '<div class="p3-stat"><div class="num success">' + statusCounts.will + '</div><div class="label">Will implement</div></div>' +
      '<div class="p3-stat"><div class="num">' + statusCounts.have + '</div><div class="label">Already have</div></div>' +
      '<div class="p3-stat"><div class="num muted">' + statusCounts.notnow + '</div><div class="label">Not now</div></div>' +
      '<div class="p3-stat"><div class="num warning">' + statusCounts.pending + '</div><div class="label">Pending review</div></div>' +
      '<div class="p3-stat"><div class="num muted">' + relevantDetections.length + '</div><div class="label">Total available</div></div>' +
    '</div>' +
    '<div class="p3-toolbar">' +
      '<span style="font-size:11px; color:var(--text-muted);">Severity:</span>' +
      '<button class="btn-mini ' + (sevFilter === 'all' ? '' : '') + '" data-p3-sev="all">All</button>' +
      '<button class="btn-mini ' + (sevFilter === 'crit' ? '' : '') + '" data-p3-sev="crit">Critical only</button>' +
      '<button class="btn-mini ' + (sevFilter === 'high+' ? '' : '') + '" data-p3-sev="high+">High+</button>' +
      '<span style="font-size:11px; color:var(--text-muted); margin-left:12px;">Status:</span>' +
      '<button class="btn-mini" data-p3-status="all">All</button>' +
      '<button class="btn-mini" data-p3-status="pending">Pending</button>' +
      '<button class="btn-mini" data-p3-status="will">Will</button>' +
      '<button class="btn-mini" data-p3-status="have">Have</button>' +
    '</div>' +
    '<div class="detection-table-wrap">' +
      '<table class="detection-table">' +
        '<thead><tr>' +
          '<th>Detection / Component</th>' +
          '<th>Severity</th>' +
          '<th>Platform</th>' +
          '<th>MITRE</th>' +
          '<th>Status</th>' +
        '</tr></thead>' +
        '<tbody>' + rowsHtml + '</tbody>' +
      '</table>' +
    '</div>';
}

// ─── Step 3.3 — SecOps Dashboards ────────────────────────────────────
function renderStep33Dashboards() {
  var components = getSelectedComponents();
  var componentIds = new Set(components.map(function (c) { return c.id; }));
  var dashboards = (window.PLANNER_DATA && window.PLANNER_DATA.dashboards) || [];
  var visualizations = (window.PLANNER_DATA && window.PLANNER_DATA.visualizations) || [];
  var selectedSet = new Set(state.phase3.selectedDashboardIds);

  // Calculate relevance per dashboard:
  //   relevanceScore = (# of dashboard's componentIds that are in user selection) / (total of dashboard's componentIds)
  // Where dashboard's componentIds = union of all viz componentIds in that dashboard
  var dashRelevance = {};
  dashboards.forEach(function (d) {
    var dashCompIds = new Set();
    visualizations.forEach(function (v) {
      if (v.dashId === d.id) {
        (v.componentIds || []).forEach(function (cid) { dashCompIds.add(cid); });
      }
    });
    var matched = 0;
    dashCompIds.forEach(function (cid) {
      if (componentIds.has(cid)) matched++;
    });
    var total = dashCompIds.size;
    dashRelevance[d.id] = {
      matched: matched,
      total: total,
      pct: total > 0 ? Math.round(matched / total * 100) : 0,
      vizCount: visualizations.filter(function (v) { return v.dashId === d.id; }).length,
    };
  });

  // Sort dashboards by relevance desc
  var sortedDashboards = dashboards.slice().sort(function (a, b) {
    return dashRelevance[b.id].pct - dashRelevance[a.id].pct;
  });

  // Auto-recommend top 5 (those with relevance > 0, capped at 5)
  var recommendedIds = new Set();
  sortedDashboards.forEach(function (d) {
    if (dashRelevance[d.id].matched > 0 && recommendedIds.size < 5) {
      recommendedIds.add(d.id);
    }
  });

  function relevanceClass(pct) {
    if (pct >= 60) return 'high';
    if (pct >= 25) return 'med';
    return 'low';
  }

  var cardsHtml = sortedDashboards.map(function (d) {
    var rel = dashRelevance[d.id];
    var isSelected = selectedSet.has(d.id);
    var isRecommended = recommendedIds.has(d.id);
    return '<div class="dashboard-card ' + (isSelected ? 'selected' : '') +
           '" data-dashboard-id="' + d.id + '">' +
      (isRecommended ? '<span class="recommended-tag">★ Recommended</span>' : '') +
      '<div class="name">' + escapeHtml(d.name) + '</div>' +
      '<div class="meta">' +
        '<span>' + rel.vizCount + ' visualizations</span>' +
        '<span>•</span>' +
        '<span>Covers ' + rel.matched + '/' + rel.total + ' components</span>' +
        '<span>•</span>' +
        '<span>' + escapeHtml(d.category || '') + '</span>' +
      '</div>' +
      '<div class="relevance-bar">' +
        '<div class="relevance-fill ' + relevanceClass(rel.pct) + '" style="width:' + rel.pct + '%;"></div>' +
      '</div>' +
      '<div style="font-size:10px; color:var(--text-muted); font-family:var(--mono);">' +
        rel.pct + '% relevant to your architecture' +
      '</div>' +
      '<div class="why">' + escapeHtml((d.whyItMatters || '').slice(0, 200)) + '</div>' +
    '</div>';
  }).join('');

  // Stats
  var totalSelected = state.phase3.selectedDashboardIds.length;
  var totalViz = state.phase3.selectedDashboardIds.reduce(function (sum, did) {
    return sum + (dashRelevance[did] ? dashRelevance[did].vizCount : 0);
  }, 0);

  return '<div class="phase-header">' +
      '<h2>SecOps dashboards</h2>' +
      '<p>13 dashboards available. We&apos;ve calculated relevance based on how many of your components each dashboard covers, and recommended the top 5.</p>' +
    '</div>' +
    '<div class="p3-stat-strip">' +
      '<div class="p3-stat"><div class="num success">' + totalSelected + '</div><div class="label">Dashboards selected</div></div>' +
      '<div class="p3-stat"><div class="num">' + totalViz + '</div><div class="label">Total visualizations</div></div>' +
      '<div class="p3-stat"><div class="num muted">' + dashboards.length + '</div><div class="label">Available</div></div>' +
    '</div>' +
    '<div class="p3-toolbar">' +
      '<button class="btn-mini" data-p3action="select-recommended">★ Select recommended (top 5)</button>' +
      '<button class="btn-mini" data-p3action="select-all-relevant">+ All relevant (any coverage)</button>' +
      '<button class="btn-mini danger" data-p3action="clear-dashboards">Clear all</button>' +
    '</div>' +
    '<div class="dashboard-grid">' + cardsHtml + '</div>';
}

// ─── Step 3.4 — Log Strategy ─────────────────────────────────────────
function renderStep34Logs() {
  var components = getSelectedComponents();
  var allLogEvents = (window.PLANNER_DATA && window.PLANNER_DATA.logEvents) || [];
  var componentIds = new Set(components.map(function (c) { return c.id; }));
  var byId = {};
  components.forEach(function (c) { byId[c.id] = c; });

  // Filter to log events for selected components
  var relevantEvents = allLogEvents.filter(function (e) {
    return componentIds.has(e.componentId);
  });

  // Group by tier
  var must = relevantEvents.filter(function (e) { return e.tier === 'MUST'; });
  var should = relevantEvents.filter(function (e) { return e.tier === 'Should'; });
  var nice = relevantEvents.filter(function (e) {
    return e.tier !== 'MUST' && e.tier !== 'Should';
  });

  // Volume estimate (rough heuristic based on event volume tags)
  function volumeWeight(vol) {
    var v = (vol || '').toLowerCase();
    if (v === 'high') return 3;
    if (v === 'medium') return 2;
    return 1;
  }
  var totalVolWeight = relevantEvents.reduce(function (s, e) {
    return s + volumeWeight(e.vol);
  }, 0);
  var avgVol = relevantEvents.length > 0 ? totalVolWeight / relevantEvents.length : 0;
  var volumeTier = avgVol >= 2.4 ? 'High' : (avgVol >= 1.6 ? 'Medium' : 'Low');

  function volClass(v) {
    var s = (v || '').toLowerCase();
    if (s === 'high') return 'high';
    if (s === 'medium') return 'medium';
    return 'low';
  }

  function renderEventRow(e) {
    var c = byId[e.componentId];
    return '<div class="log-event-row">' +
      '<div class="left">' +
        '<div class="name">' + escapeHtml(e.name) + '</div>' +
        (e.why ? '<div class="why">' + escapeHtml(e.why) + '</div>' : '') +
      '</div>' +
      '<div class="right">' +
        (c ? '<span class="component-tag">' + escapeHtml(c.name) + '</span>' : '') +
        '<span class="vol-tag ' + volClass(e.vol) + '">' + escapeHtml(e.vol || 'Med') + '</span>' +
      '</div>' +
    '</div>';
  }

  function renderTierSection(tierKey, tierClass, tierIcon, tierName, events) {
    if (events.length === 0) {
      return '<div class="log-tier-section">' +
        '<div class="log-tier-header">' +
          '<div class="tier-name ' + tierClass + '">' +
            '<span class="tier-icon">' + tierIcon + '</span>' + tierName +
          '</div>' +
          '<div class="tier-count">No events in this tier</div>' +
        '</div>' +
      '</div>';
    }
    return '<div class="log-tier-section">' +
      '<div class="log-tier-header">' +
        '<div class="tier-name ' + tierClass + '">' +
          '<span class="tier-icon">' + tierIcon + '</span>' + tierName +
        '</div>' +
        '<div class="tier-count">' + events.length + ' events</div>' +
      '</div>' +
      '<div class="log-tier-body">' +
        events.map(renderEventRow).join('') +
      '</div>' +
    '</div>';
  }

  // Strategy picker
  var strategy = state.phase3.logTierStrategy;

  return '<div class="phase-header">' +
      '<h2>Log ingestion strategy</h2>' +
      '<p>Pick your default ingestion strategy for each tier. MUST events should always be ingested; Should and Nice-to-have are budget-driven decisions.</p>' +
    '</div>' +
    '<div class="p3-stat-strip">' +
      '<div class="p3-stat"><div class="num danger">' + must.length + '</div><div class="label">MUST events</div></div>' +
      '<div class="p3-stat"><div class="num">' + should.length + '</div><div class="label">Should events</div></div>' +
      '<div class="p3-stat"><div class="num muted">' + nice.length + '</div><div class="label">Nice-to-have</div></div>' +
      '<div class="p3-stat"><div class="num ' + (volumeTier === 'High' ? 'danger' : (volumeTier === 'Medium' ? 'warning' : 'success')) + '">' + volumeTier + '</div><div class="label">Volume tier</div></div>' +
    '</div>' +
    '<div class="log-strategy-grid">' +
      '<div class="log-strategy-card must">' +
        '<div class="head"><span>⭐ MUST</span><span class="count">' + must.length + ' events</span></div>' +
        '<select data-strategy-tier="must">' +
          '<option value="ingest-all"' + (strategy.must === 'ingest-all' ? ' selected' : '') + '>Ingest all → SIEM</option>' +
          '<option value="ingest-archive"' + (strategy.must === 'ingest-archive' ? ' selected' : '') + '>Ingest + cold archive</option>' +
        '</select>' +
      '</div>' +
      '<div class="log-strategy-card should">' +
        '<div class="head"><span>✓ SHOULD</span><span class="count">' + should.length + ' events</span></div>' +
        '<select data-strategy-tier="should">' +
          '<option value="ingest-all"' + (strategy.should === 'ingest-all' ? ' selected' : '') + '>Ingest all</option>' +
          '<option value="sample"' + (strategy.should === 'sample' ? ' selected' : '') + '>Sample (e.g., 10%)</option>' +
          '<option value="archive-only"' + (strategy.should === 'archive-only' ? ' selected' : '') + '>Archive only (no SIEM)</option>' +
          '<option value="defer"' + (strategy.should === 'defer' ? ' selected' : '') + '>Defer until needed</option>' +
        '</select>' +
      '</div>' +
      '<div class="log-strategy-card nice">' +
        '<div class="head"><span>○ NICE</span><span class="count">' + nice.length + ' events</span></div>' +
        '<select data-strategy-tier="nice">' +
          '<option value="ingest-all"' + (strategy.nice === 'ingest-all' ? ' selected' : '') + '>Ingest all</option>' +
          '<option value="sample"' + (strategy.nice === 'sample' ? ' selected' : '') + '>Sample</option>' +
          '<option value="archive-only"' + (strategy.nice === 'archive-only' ? ' selected' : '') + '>Archive only</option>' +
          '<option value="defer"' + (strategy.nice === 'defer' ? ' selected' : '') + '>Defer until needed</option>' +
        '</select>' +
      '</div>' +
    '</div>' +
    renderTierSection('must', 'must', '⭐', 'MUST — Ingest these', must) +
    renderTierSection('should', 'should', '✓', 'Should — Recommended', should) +
    renderTierSection('nice', 'nice', '○', 'Nice-to-have', nice);
}

// ─── Event wiring ────────────────────────────────────────────────────
function wireP3Events() {
  // Sub-step navigation
  document.querySelectorAll('.p3-substep').forEach(function (el) {
    el.addEventListener('click', function () {
      var step = parseInt(el.dataset.p3step, 10);
      if (step <= state.phase3.currentStep || step === state.phase3.currentStep + 1) {
        state.phase3.currentStep = step;
        saveState();
        renderPhase3();
      }
    });
  });

  // Top-level action buttons (next/prev/back)
  document.querySelectorAll('[data-p3action]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var action = btn.dataset.p3action;
      switch (action) {
        case 'next': p3GoNext(); break;
        case 'prev': p3GoPrev(); break;
        case 'back-to-phase2':
          state.phase2.currentStep = 7; // jump to Phase 2 summary
          saveState();
          showPhase(2);
          if (typeof renderPhase2 === 'function') renderPhase2();
          break;
        case 'expand-all': p3ExpandAll(true); break;
        case 'collapse-all': p3ExpandAll(false); break;
        case 'select-all-native': p3SelectAllNativeTools(); break;
        case 'clear-tools': p3ClearTools(); break;
        case 'select-recommended': p3SelectRecommendedDashboards(); break;
        case 'select-all-relevant': p3SelectAllRelevantDashboards(); break;
        case 'clear-dashboards': p3ClearDashboards(); break;
        case 'back-to-step': state.phase3.currentStep = parseInt(btn.dataset.targetStep, 10); saveState(); renderPhase3(); break;
        case 'continue-to-phase4':
          showPhase(4);
          if (typeof renderPhase4 === 'function') renderPhase4();
          break;
      }
    });
  });

  // Tool pill clicks
  document.querySelectorAll('.tool-pill').forEach(function (pill) {
    pill.addEventListener('click', function () {
      var key = pill.dataset.toolKey;
      var idx = state.phase3.selectedToolKeys.indexOf(key);
      if (idx === -1) state.phase3.selectedToolKeys.push(key);
      else state.phase3.selectedToolKeys.splice(idx, 1);
      saveState();
      renderPhase3();
    });
  });

  // Component group toggle
  document.querySelectorAll('[data-toggle-group]').forEach(function (el) {
    el.addEventListener('click', function () {
      var cid = parseInt(el.dataset.toggleGroup, 10);
      var current = state.phase3.expandedGroups[cid];
      // default is true (expanded), so toggle
      state.phase3.expandedGroups[cid] = !(current !== false);
      saveState();
      renderPhase3();
    });
  });

  // Detection severity / status filters
  document.querySelectorAll('[data-p3-sev]').forEach(function (b) {
    b.addEventListener('click', function () {
      window._p3SevFilter = b.dataset.p3Sev;
      renderPhase3();
    });
  });
  document.querySelectorAll('[data-p3-status]').forEach(function (b) {
    b.addEventListener('click', function () {
      window._p3StatusFilter = b.dataset.p3Status;
      renderPhase3();
    });
  });

  // Detection status buttons
  document.querySelectorAll('.det-status-btn').forEach(function (b) {
    b.addEventListener('click', function (e) {
      e.stopPropagation();
      var detId = b.dataset.detId;
      var status = b.dataset.status;
      var current = state.phase3.detectionStatus[detId];
      // Click same status to clear it
      if (current === status) {
        delete state.phase3.detectionStatus[detId];
      } else {
        state.phase3.detectionStatus[detId] = status;
      }
      saveState();
      renderPhase3();
    });
  });

  // Dashboard card clicks
  document.querySelectorAll('.dashboard-card').forEach(function (card) {
    card.addEventListener('click', function () {
      var did = parseInt(card.dataset.dashboardId, 10);
      var idx = state.phase3.selectedDashboardIds.indexOf(did);
      if (idx === -1) state.phase3.selectedDashboardIds.push(did);
      else state.phase3.selectedDashboardIds.splice(idx, 1);
      saveState();
      renderPhase3();
    });
  });

  // Log strategy select
  document.querySelectorAll('[data-strategy-tier]').forEach(function (sel) {
    sel.addEventListener('change', function () {
      state.phase3.logTierStrategy[sel.dataset.strategyTier] = sel.value;
      saveState();
      // Don't re-render — keep selection focus
    });
  });
}

// ─── Bulk actions ────────────────────────────────────────────────────
function p3ExpandAll(expanded) {
  var components = getSelectedComponents();
  components.forEach(function (c) {
    state.phase3.expandedGroups[c.id] = expanded;
  });
  saveState();
  renderPhase3();
}

function p3SelectAllNativeTools() {
  var components = getSelectedComponents();
  var allTools = (window.PLANNER_DATA && window.PLANNER_DATA.tools) || [];
  var componentIds = new Set(components.map(function (c) { return c.id; }));
  var added = 0;
  allTools.forEach(function (t) {
    if (!componentIds.has(t.componentId)) return;
    if (t.type !== 'Native') return;
    var key = getToolKey(t.componentId, t.name);
    if (state.phase3.selectedToolKeys.indexOf(key) === -1) {
      state.phase3.selectedToolKeys.push(key);
      added++;
    }
  });
  saveState();
  renderPhase3();
}

function p3ClearTools() {
  state.phase3.selectedToolKeys = [];
  saveState();
  renderPhase3();
}

function p3SelectRecommendedDashboards() {
  // Reuses same logic as renderStep33Dashboards to find recommended
  var components = getSelectedComponents();
  var componentIds = new Set(components.map(function (c) { return c.id; }));
  var dashboards = (window.PLANNER_DATA && window.PLANNER_DATA.dashboards) || [];
  var visualizations = (window.PLANNER_DATA && window.PLANNER_DATA.visualizations) || [];

  var dashRelevance = {};
  dashboards.forEach(function (d) {
    var dashCompIds = new Set();
    visualizations.forEach(function (v) {
      if (v.dashId === d.id) (v.componentIds || []).forEach(function (cid) { dashCompIds.add(cid); });
    });
    var matched = 0;
    dashCompIds.forEach(function (cid) {
      if (componentIds.has(cid)) matched++;
    });
    dashRelevance[d.id] = { matched: matched, total: dashCompIds.size };
  });

  var sorted = dashboards.slice().sort(function (a, b) {
    var pa = dashRelevance[a.id].total ? dashRelevance[a.id].matched / dashRelevance[a.id].total : 0;
    var pb = dashRelevance[b.id].total ? dashRelevance[b.id].matched / dashRelevance[b.id].total : 0;
    return pb - pa;
  });

  state.phase3.selectedDashboardIds = [];
  for (var i = 0; i < sorted.length && state.phase3.selectedDashboardIds.length < 5; i++) {
    if (dashRelevance[sorted[i].id].matched > 0) {
      state.phase3.selectedDashboardIds.push(sorted[i].id);
    }
  }
  saveState();
  renderPhase3();
}

function p3SelectAllRelevantDashboards() {
  var components = getSelectedComponents();
  var componentIds = new Set(components.map(function (c) { return c.id; }));
  var dashboards = (window.PLANNER_DATA && window.PLANNER_DATA.dashboards) || [];
  var visualizations = (window.PLANNER_DATA && window.PLANNER_DATA.visualizations) || [];

  state.phase3.selectedDashboardIds = [];
  dashboards.forEach(function (d) {
    var hasMatch = visualizations.some(function (v) {
      if (v.dashId !== d.id) return false;
      return (v.componentIds || []).some(function (cid) { return componentIds.has(cid); });
    });
    if (hasMatch) state.phase3.selectedDashboardIds.push(d.id);
  });
  saveState();
  renderPhase3();
}

function p3ClearDashboards() {
  state.phase3.selectedDashboardIds = [];
  saveState();
  renderPhase3();
}

// ─── Step navigation ─────────────────────────────────────────────────
function p3GoNext() {
  // Reset filter state when moving steps
  window._p3SevFilter = 'all';
  window._p3StatusFilter = 'all';

  if (state.phase3.currentStep < 4) {
    state.phase3.currentStep += 1;
  } else {
    state.phase3.currentStep = 5; // summary
  }
  saveState();
  renderPhase3();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function p3GoPrev() {
  window._p3SevFilter = 'all';
  window._p3StatusFilter = 'all';
  if (state.phase3.currentStep > 1) {
    state.phase3.currentStep -= 1;
    saveState();
    renderPhase3();
  }
}

// ─── Phase 3 final summary screen ────────────────────────────────────
function renderPhase3Summary() {
  var container = document.getElementById('phase-3-content');
  if (!container) return;

  var components = getSelectedComponents();
  var allTools = (window.PLANNER_DATA && window.PLANNER_DATA.tools) || [];
  var allDetections = (window.PLANNER_DATA && window.PLANNER_DATA.detections) || [];
  var allDashboards = (window.PLANNER_DATA && window.PLANNER_DATA.dashboards) || [];
  var allLogEvents = (window.PLANNER_DATA && window.PLANNER_DATA.logEvents) || [];
  var componentIds = new Set(components.map(function (c) { return c.id; }));

  // Tools breakdown
  var selectedToolKeys = new Set(state.phase3.selectedToolKeys);
  var toolStats = { native: 0, thirdparty: 0, recommended: 0, oss: 0 };
  allTools.forEach(function (t) {
    if (!componentIds.has(t.componentId)) return;
    if (selectedToolKeys.has(getToolKey(t.componentId, t.name))) {
      var typeKey;
      if (t.type === 'Native') typeKey = 'native';
      else if (t.type === 'Third-Party') typeKey = 'thirdparty';
      else if (t.type === 'Recommended') typeKey = 'recommended';
      else typeKey = 'oss';
      toolStats[typeKey]++;
    }
  });
  var totalTools = toolStats.native + toolStats.thirdparty + toolStats.recommended + toolStats.oss;

  // Detection breakdown
  var detStats = { will: 0, have: 0, notnow: 0, pending: 0 };
  allDetections.forEach(function (d) {
    if (!componentIds.has(d.componentId)) return;
    var st = state.phase3.detectionStatus[d.id] || 'pending';
    detStats[st]++;
  });
  var totalDet = detStats.will + detStats.have + detStats.notnow + detStats.pending;

  // Dashboards
  var totalDashboards = state.phase3.selectedDashboardIds.length;

  // Log events
  var logStats = { must: 0, should: 0, nice: 0 };
  allLogEvents.forEach(function (e) {
    if (!componentIds.has(e.componentId)) return;
    if (e.tier === 'MUST') logStats.must++;
    else if (e.tier === 'Should') logStats.should++;
    else logStats.nice++;
  });
  var totalLogEvents = logStats.must + logStats.should + logStats.nice;

  var canContinue = totalTools > 0 || detStats.will > 0 || totalDashboards > 0;

  // Mark Phase 3 as completed if user has any selections
  if (canContinue && state.phasesCompleted.indexOf(3) === -1) {
    state.phasesCompleted.push(3);
    saveState();
  }

  container.innerHTML =
    renderP3StepBar() +
    '<div class="phase-header">' +
      '<h2>Your security stack</h2>' +
      '<p>Review your tools, detections, dashboards, and log strategy. Click any section to go back and edit.</p>' +
    '</div>' +
    '<div class="p3-summary-grid">' +
      // Tools block
      '<div class="p3-summary-block" style="cursor:pointer;" data-p3action="back-to-step" data-target-step="1">' +
        '<h4>Defense Tools</h4>' +
        '<div class="big-num">' + totalTools + '</div>' +
        '<div class="sublabel">tools selected</div>' +
        '<div class="breakdown">' +
          '<div class="row"><span>Native</span><span>' + toolStats.native + '</span></div>' +
          '<div class="row"><span>Third-Party</span><span>' + toolStats.thirdparty + '</span></div>' +
          '<div class="row"><span>Recommended</span><span>' + toolStats.recommended + '</span></div>' +
          '<div class="row"><span>OSS</span><span>' + toolStats.oss + '</span></div>' +
        '</div>' +
      '</div>' +
      // Detections block
      '<div class="p3-summary-block" style="cursor:pointer;" data-p3action="back-to-step" data-target-step="2">' +
        '<h4>Detection Coverage</h4>' +
        '<div class="big-num">' + (detStats.will + detStats.have) + '</div>' +
        '<div class="sublabel">covered (' + detStats.will + ' will + ' + detStats.have + ' have) / ' + totalDet + ' total</div>' +
        '<div class="breakdown">' +
          '<div class="row"><span>Will implement</span><span>' + detStats.will + '</span></div>' +
          '<div class="row"><span>Already have</span><span>' + detStats.have + '</span></div>' +
          '<div class="row"><span>Not now</span><span>' + detStats.notnow + '</span></div>' +
          '<div class="row"><span>Pending review</span><span>' + detStats.pending + '</span></div>' +
        '</div>' +
      '</div>' +
      // Dashboards block
      '<div class="p3-summary-block" style="cursor:pointer;" data-p3action="back-to-step" data-target-step="3">' +
        '<h4>SecOps Dashboards</h4>' +
        '<div class="big-num">' + totalDashboards + '</div>' +
        '<div class="sublabel">of ' + allDashboards.length + ' available</div>' +
        '<div class="breakdown">' +
          (state.phase3.selectedDashboardIds.length === 0
            ? '<div style="color:var(--text-muted); font-style:italic;">No dashboards selected.</div>'
            : state.phase3.selectedDashboardIds.map(function (did) {
                var d = allDashboards.find(function (x) { return x.id === did; });
                return d ? '<div class="row"><span>' + escapeHtml(d.name) + '</span></div>' : '';
              }).join('')) +
        '</div>' +
      '</div>' +
      // Log strategy block
      '<div class="p3-summary-block" style="cursor:pointer;" data-p3action="back-to-step" data-target-step="4">' +
        '<h4>Log Strategy</h4>' +
        '<div class="big-num">' + totalLogEvents + '</div>' +
        '<div class="sublabel">events available</div>' +
        '<div class="breakdown">' +
          '<div class="row"><span>MUST (' + logStats.must + ' events)</span><span>' + escapeHtml(state.phase3.logTierStrategy.must) + '</span></div>' +
          '<div class="row"><span>Should (' + logStats.should + ' events)</span><span>' + escapeHtml(state.phase3.logTierStrategy.should) + '</span></div>' +
          '<div class="row"><span>Nice-to-have (' + logStats.nice + ')</span><span>' + escapeHtml(state.phase3.logTierStrategy.nice) + '</span></div>' +
        '</div>' +
      '</div>' +
    '</div>' +
    '<div class="wizard-nav">' +
      '<button class="btn-secondary" data-p3action="back-to-step" data-target-step="4">← Back to log strategy</button>' +
      '<button class="btn-primary" data-p3action="continue-to-phase4"' +
        (!canContinue ? ' disabled title="Make at least some selections in tools, detections, or dashboards"' : '') +
        '>Generate architecture document →</button>' +
    '</div>';

  wireP3Events();
}

// Hook: expose so external (planner.js submitPhase2-equivalent) can call
window.renderPhase3 = renderPhase3;


/* ═══════════════════════════════════════════════════════ */

/* === phase4.js === */
// ═══════════════════════════════════════════════════════════════════════
// Round 4 — Architecture Document Generator
//
// Assembles all state from Phases 1-3 into a structured document with
// sections: Cover, TOC, Exec Summary, Architecture, Component Inventory,
// Tooling, Detection Coverage, Dashboards, Log Strategy, MITRE Coverage,
// Compliance, Risk Summary, Appendix.
//
// Doc renders into #phase-4-content. Print-to-PDF works via @media print.
// ═══════════════════════════════════════════════════════════════════════

// Defense layers ordered for display
var DOC_LAYERS = [
  { key: 'Identity', cls: 'layer-identity', desc: 'Authentication, authorization, identity governance' },
  { key: 'Network', cls: 'layer-network', desc: 'Network isolation, segmentation, traffic control' },
  { key: 'OS / Compute', cls: 'layer-os-compute', desc: 'Host hardening, runtime security, image management' },
  { key: 'Application', cls: 'layer-application', desc: 'Application-level controls, API security, secrets management' },
  { key: 'Data', cls: 'layer-data', desc: 'Encryption, access control, classification, retention' },
  { key: 'Detection', cls: 'layer-detection', desc: 'Logging, monitoring, threat detection, incident response' },
];

// Risk classification
function riskClass(score) {
  var n = parseInt(score, 10);
  if (isNaN(n)) return 'r-low';
  if (n >= 8) return 'r-high';
  if (n >= 5) return 'r-med';
  return 'r-low';
}

function riskLabel(score) {
  var n = parseInt(score, 10);
  if (isNaN(n)) return 'Unknown';
  if (n >= 8) return 'HIGH';
  if (n >= 5) return 'MEDIUM';
  return 'LOW';
}

// ─── Phase 4 entry point ─────────────────────────────────────────────
function renderPhase4() {
  var container = document.getElementById('phase-4-content');
  if (!container) return;

  var doc = assembleDocData();
  if (!doc.selectedComponents || doc.selectedComponents.length === 0) {
    container.innerHTML = '<div class="placeholder">' +
      '<h3>No components selected</h3>' +
      '<p>The architecture document is generated from the components, tools, detections, and dashboards you selected in Phases 2 and 3. Go back to Phase 2 to pick components first.</p>' +
      '<button class="btn-primary" data-p4action="back-to-phase2" style="margin-top:16px;">Back to Phase 2</button>' +
    '</div>';
    var backBtn = container.querySelector('[data-p4action="back-to-phase2"]');
    if (backBtn) backBtn.addEventListener('click', function () { showPhase(2); });
    return;
  }

  var html = '<div class="arch-doc">' +
    renderDocActions(doc) +
    '<div class="doc-inner">' +
      renderCoverPage(doc) +
      renderTOC(doc) +
      renderExecSummary(doc) +
      renderArchOverview(doc) +
      renderComponentInventory(doc) +
      renderToolingSection(doc) +
      renderDetectionCoverage(doc) +
      renderDashboardsSection(doc) +
      renderLogStrategy(doc) +
      renderMitreCoverage(doc) +
      renderComplianceMapping(doc) +
      renderRiskSummary(doc) +
      renderAppendix(doc) +
    '</div>' +
  '</div>';

  container.innerHTML = html;
  wireP4Events();

  // Mark phase 4 as completed
  if (state.phasesCompleted.indexOf(4) === -1) {
    state.phasesCompleted.push(4);
    saveState();
  }
}

// ─── Data assembly ───────────────────────────────────────────────────
function assembleDocData() {
  var pdata = window.PLANNER_DATA || {};
  var brief = state.brief || {};
  var phase2 = state.phase2 || { selectedComponentIds: [] };
  var phase3 = state.phase3 || {
    selectedToolKeys: [],
    detectionStatus: {},
    selectedDashboardIds: [],
    logTierStrategy: { must: 'ingest-all', should: 'sample', nice: 'defer' },
  };

  var allComponents = pdata.components || [];
  var byId = {};
  allComponents.forEach(function (c) { byId[c.id] = c; });

  var selectedComponents = (phase2.selectedComponentIds || [])
    .map(function (id) { return byId[id]; })
    .filter(Boolean);

  var componentIds = new Set(selectedComponents.map(function (c) { return c.id; }));

  // Selected tools — resolve from selectedToolKeys
  var selectedToolKeys = new Set(phase3.selectedToolKeys || []);
  var allTools = pdata.tools || [];
  var selectedTools = allTools.filter(function (t) {
    return componentIds.has(t.componentId) &&
           selectedToolKeys.has(t.componentId + ':' + t.name);
  });

  // Group tools by component
  var toolsByComponent = {};
  selectedTools.forEach(function (t) {
    if (!toolsByComponent[t.componentId]) toolsByComponent[t.componentId] = [];
    toolsByComponent[t.componentId].push(t);
  });

  // Detections grouped by status
  var allDetections = pdata.detections || [];
  var relevantDetections = allDetections.filter(function (d) {
    return componentIds.has(d.componentId);
  });
  var detectionsByStatus = { will: [], have: [], notnow: [], pending: [] };
  relevantDetections.forEach(function (d) {
    var st = phase3.detectionStatus[d.id] || 'pending';
    detectionsByStatus[st].push(d);
  });

  // Severity distribution among Will + Have
  var coveredDetections = detectionsByStatus.will.concat(detectionsByStatus.have);
  var sevDist = { critical: 0, high: 0, medium: 0, low: 0 };
  coveredDetections.forEach(function (d) {
    var s = (d.severity || '').toLowerCase();
    if (s === 'critical') sevDist.critical++;
    else if (s === 'high') sevDist.high++;
    else if (s === 'medium') sevDist.medium++;
    else sevDist.low++;
  });
  // Same for total available (for context)
  var sevDistTotal = { critical: 0, high: 0, medium: 0, low: 0 };
  relevantDetections.forEach(function (d) {
    var s = (d.severity || '').toLowerCase();
    if (s === 'critical') sevDistTotal.critical++;
    else if (s === 'high') sevDistTotal.high++;
    else if (s === 'medium') sevDistTotal.medium++;
    else sevDistTotal.low++;
  });

  // Selected dashboards
  var allDashboards = pdata.dashboards || [];
  var allViz = pdata.visualizations || [];
  var selectedDashboards = (phase3.selectedDashboardIds || [])
    .map(function (id) { return allDashboards.find(function (d) { return d.id === id; }); })
    .filter(Boolean);

  // Log events grouped by tier
  var allLogEvents = pdata.logEvents || [];
  var relevantLogEvents = allLogEvents.filter(function (e) {
    return componentIds.has(e.componentId);
  });
  var logEventsByTier = { must: [], should: [], nice: [] };
  relevantLogEvents.forEach(function (e) {
    if (e.tier === 'MUST') logEventsByTier.must.push(e);
    else if (e.tier === 'Should') logEventsByTier.should.push(e);
    else logEventsByTier.nice.push(e);
  });

  // MITRE coverage — for each technique, which selected components cover it
  var componentMitre = pdata.componentMitre || [];
  var mitreCatalog = pdata.mitreAttack || [];
  var mitreById = {};
  mitreCatalog.forEach(function (t) { mitreById[t.mitreId] = t; });

  var coverageByMitreId = {};
  componentMitre.forEach(function (link) {
    if (!componentIds.has(link.componentId)) return;
    if (!link.mitreId) return;
    if (!coverageByMitreId[link.mitreId]) {
      coverageByMitreId[link.mitreId] = { tech: mitreById[link.mitreId], components: [] };
    }
    if (coverageByMitreId[link.mitreId].components.indexOf(link.componentId) === -1) {
      coverageByMitreId[link.mitreId].components.push(link.componentId);
    }
  });

  // Group by tactic
  var mitreByTactic = {};
  Object.keys(coverageByMitreId).forEach(function (mid) {
    var entry = coverageByMitreId[mid];
    if (!entry.tech) return;
    var tactic = entry.tech.tactic || 'Other';
    if (!mitreByTactic[tactic]) mitreByTactic[tactic] = [];
    mitreByTactic[tactic].push({
      mitreId: mid,
      name: entry.tech.name || '',
      url: entry.tech.url || '',
      components: entry.components,
    });
  });

  // Compliance mapping — for each user-selected framework, find which selected components contribute
  var allCompliance = pdata.complianceMappings || [];
  var userFrameworks = (brief.compliance || []).filter(function (f) {
    return f && f !== 'None / Not Sure';
  });

  // Normalize framework names — "PCI-DSS" in brief vs "PCI DSS v4.0" in data
  function frameworkMatches(briefFw, dataFw) {
    if (!briefFw || !dataFw) return false;
    var b = briefFw.toLowerCase().replace(/[\s\-]/g, '');
    var d = dataFw.toLowerCase().replace(/[\s\-]/g, '');
    return d.indexOf(b) === 0 || b.indexOf(d.split('v')[0]) === 0;
  }

  var complianceCoverage = {};
  userFrameworks.forEach(function (briefFw) {
    var matches = allCompliance.filter(function (cm) {
      return componentIds.has(cm.componentId) && frameworkMatches(briefFw, cm.framework);
    });
    // Group by control
    var byControl = {};
    matches.forEach(function (m) {
      var key = m.controlId + '||' + m.controlName;
      if (!byControl[key]) {
        byControl[key] = {
          controlId: m.controlId,
          controlName: m.controlName,
          components: [],
        };
      }
      var compName = byId[m.componentId] ? byId[m.componentId].name : '';
      if (compName && byControl[key].components.indexOf(compName) === -1) {
        byControl[key].components.push(compName);
      }
    });
    complianceCoverage[briefFw] = {
      controls: Object.values(byControl).sort(function (a, b) {
        return a.controlId.localeCompare(b.controlId);
      }),
      componentCount: matches.length > 0 ? new Set(matches.map(function (m) { return m.componentId; })).size : 0,
    };
  });

  // Risk distribution + top 5
  var riskDist = { low: 0, medium: 0, high: 0 };
  selectedComponents.forEach(function (c) {
    var rc = riskClass(c.risk);
    if (rc === 'r-high') riskDist.high++;
    else if (rc === 'r-med') riskDist.medium++;
    else riskDist.low++;
  });

  var topRisks = selectedComponents.slice()
    .sort(function (a, b) { return (parseInt(b.risk, 10) || 0) - (parseInt(a.risk, 10) || 0); })
    .slice(0, 5);

  return {
    brief: brief,
    selectedComponents: selectedComponents,
    componentsById: byId,
    toolsByComponent: toolsByComponent,
    selectedTools: selectedTools,
    relevantDetections: relevantDetections,
    detectionsByStatus: detectionsByStatus,
    sevDist: sevDist,
    sevDistTotal: sevDistTotal,
    selectedDashboards: selectedDashboards,
    allViz: allViz,
    logEventsByTier: logEventsByTier,
    relevantLogEventsCount: relevantLogEvents.length,
    logStrategy: phase3.logTierStrategy,
    mitreByTactic: mitreByTactic,
    mitreCoverageCount: Object.keys(coverageByMitreId).length,
    complianceCoverage: complianceCoverage,
    userFrameworks: userFrameworks,
    riskDist: riskDist,
    topRisks: topRisks,
    generatedAt: new Date().toISOString(),
  };
}

// ─── Doc actions toolbar ─────────────────────────────────────────────
function renderDocActions(doc) {
  var stats = doc.brief.projectName + ' • ' +
              doc.selectedComponents.length + ' components • ' +
              doc.selectedTools.length + ' tools • ' +
              (doc.detectionsByStatus.will.length + doc.detectionsByStatus.have.length) + ' detections';
  return '<div class="doc-actions">' +
    '<div class="left-info"><strong>Architecture Document</strong> — ' + escapeHtml(stats) + '</div>' +
    '<div class="right-buttons">' +
      '<button class="btn-secondary btn-mini" data-p4action="back-to-phase3">← Edit security stack</button>' +
      '<button class="btn-secondary btn-mini" data-p4action="export-json">Export JSON</button>' +
      '<button class="btn-primary btn-mini" data-p4action="print">Print / Save as PDF</button>' +
    '</div>' +
  '</div>';
}

// ─── Cover page ──────────────────────────────────────────────────────
function renderCoverPage(doc) {
  var brief = doc.brief;
  var clouds = (brief.cloudProviders || []).map(function (c) {
    return '<span class="cloud-pill ' + c.toLowerCase() + '">' + escapeHtml(c) + '</span>';
  }).join('');
  var compliance = (brief.compliance || [])
    .filter(function (c) { return c && c !== 'None / Not Sure'; })
    .map(function (c) { return '<span class="comp-tag">' + escapeHtml(c) + '</span>'; })
    .join('');

  var formattedDate = brief.date ? new Date(brief.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : '';
  var projectType = brief.projectType === 'Other' ? brief.projectTypeOther : brief.projectType;

  return '<div class="doc-cover">' +
    '<div class="pre-title">Cloud Security Architecture</div>' +
    '<h1>' + escapeHtml(brief.projectName || 'Untitled Project') + '</h1>' +
    '<div class="subtitle">' + escapeHtml(brief.companyName || '') + '</div>' +
    '<div class="cloud-badges">' + clouds + '</div>' +
    '<div class="cover-meta">' +
      '<div class="cover-meta-row">' +
        '<span class="label">Project Type</span>' +
        '<span class="value">' + escapeHtml(projectType || 'Not specified') + '</span>' +
      '</div>' +
      '<div class="cover-meta-row">' +
        '<span class="label">Scale</span>' +
        '<span class="value">' + escapeHtml(brief.environmentScale || 'Not specified') + '</span>' +
      '</div>' +
      '<div class="cover-meta-row">' +
        '<span class="label">Date</span>' +
        '<span class="value">' + escapeHtml(formattedDate) + '</span>' +
      '</div>' +
      '<div class="cover-meta-row">' +
        '<span class="label">Components</span>' +
        '<span class="value">' + doc.selectedComponents.length + ' across ' + (brief.cloudProviders || []).length + ' cloud(s)</span>' +
      '</div>' +
    '</div>' +
    (compliance ? '<div class="compliance-tags">' + compliance + '</div>' : '') +
  '</div>';
}

// ─── Table of Contents ───────────────────────────────────────────────
function renderTOC(doc) {
  var items = [
    { name: 'Executive Summary', anchor: 'sec-exec', meta: 'Overview' },
    { name: 'Architecture Overview', anchor: 'sec-arch', meta: doc.selectedComponents.length + ' components' },
    { name: 'Component Inventory', anchor: 'sec-inventory', meta: doc.selectedComponents.length + ' entries' },
    { name: 'Security Tooling', anchor: 'sec-tools', meta: doc.selectedTools.length + ' tools' },
    { name: 'Detection Coverage', anchor: 'sec-detections', meta: (doc.detectionsByStatus.will.length + doc.detectionsByStatus.have.length) + ' covered' },
    { name: 'SecOps Dashboards', anchor: 'sec-dashboards', meta: doc.selectedDashboards.length + ' selected' },
    { name: 'Log Strategy', anchor: 'sec-logs', meta: doc.relevantLogEventsCount + ' events' },
    { name: 'MITRE ATT&CK Coverage', anchor: 'sec-mitre', meta: doc.mitreCoverageCount + ' techniques' },
    { name: 'Compliance Mapping', anchor: 'sec-compliance', meta: doc.userFrameworks.length + ' frameworks' },
    { name: 'Risk Summary', anchor: 'sec-risk', meta: 'Distribution + top 5' },
    { name: 'Appendix', anchor: 'sec-appendix', meta: 'Generation metadata' },
  ];

  return '<div class="doc-toc">' +
    '<h2>Contents</h2>' +
    '<ol>' +
      items.map(function (item) {
        return '<li><a href="#' + item.anchor + '">' + escapeHtml(item.name) + '</a>' +
               '<span class="item-meta">' + escapeHtml(item.meta) + '</span></li>';
      }).join('') +
    '</ol>' +
  '</div>';
}

// ─── Section 1: Executive Summary ────────────────────────────────────
function renderExecSummary(doc) {
  var brief = doc.brief;
  var willHave = doc.detectionsByStatus.will.length + doc.detectionsByStatus.have.length;
  var totalRelevant = doc.relevantDetections.length;
  var coveragePct = totalRelevant > 0 ? Math.round(willHave / totalRelevant * 100) : 0;

  var byCloud = { AWS: 0, Azure: 0, GCP: 0 };
  doc.selectedComponents.forEach(function (c) { byCloud[c.cloud] = (byCloud[c.cloud] || 0) + 1; });
  var cloudParts = Object.keys(byCloud).filter(function (k) { return byCloud[k] > 0; })
    .map(function (k) { return byCloud[k] + ' on ' + k; }).join(', ');

  // Generated narrative
  var topRiskList = doc.topRisks.slice(0, 3).map(function (c) { return c.name; }).join(', ');
  var fwList = doc.userFrameworks.length > 0 ? doc.userFrameworks.join(', ') : 'no specific frameworks selected';

  var narrative = '<p>This document describes the cloud security architecture for <strong>' +
    escapeHtml(brief.projectName) + '</strong>, a ' + escapeHtml((brief.environmentScale || '').toLowerCase()) +
    '-scale ' + escapeHtml((brief.projectType === 'Other' ? brief.projectTypeOther : brief.projectType) || 'project') +
    ' built on ' + escapeHtml(cloudParts) + '. The architecture spans <strong>' +
    doc.selectedComponents.length + ' cloud components</strong> across the standard defense layers, ' +
    'with ' + doc.selectedTools.length + ' security tools selected, ' + willHave + ' detection rules planned ' +
    'or already in place (' + coveragePct + '% of available coverage), and ' + doc.selectedDashboards.length +
    ' SecOps dashboards prioritized for monitoring.</p>';

  if (topRiskList) {
    narrative += '<p>The highest-risk components in this architecture are <strong>' + escapeHtml(topRiskList) +
      '</strong>. These warrant prioritized attention for security tooling, monitoring, and incident response readiness.</p>';
  }

  narrative += '<p>Compliance scope: ' + escapeHtml(fwList) + '. ' +
    (doc.userFrameworks.length > 0
      ? doc.mitreCoverageCount + ' MITRE ATT&CK techniques are addressed by the selected components, providing ' +
        'concrete adversary technique coverage that maps to common audit and risk-management frameworks.'
      : 'See Section 8 for MITRE ATT&CK technique coverage based on selected components.') +
    '</p>';

  return '<div class="doc-section" id="sec-exec">' +
    '<h2 class="sec-title"><span class="sec-num">1.</span> Executive Summary</h2>' +
    '<div class="doc-stat-strip">' +
      '<div class="doc-stat"><div class="num">' + doc.selectedComponents.length + '</div><div class="label">Components</div></div>' +
      '<div class="doc-stat"><div class="num">' + doc.selectedTools.length + '</div><div class="label">Tools</div></div>' +
      '<div class="doc-stat"><div class="num success">' + willHave + '</div><div class="label">Detections covered</div></div>' +
      '<div class="doc-stat"><div class="num">' + doc.selectedDashboards.length + '</div><div class="label">Dashboards</div></div>' +
      '<div class="doc-stat"><div class="num">' + doc.mitreCoverageCount + '</div><div class="label">MITRE techniques</div></div>' +
    '</div>' +
    narrative +
    (brief.projectDescription
      ? '<h3 class="sub-title">Project Description</h3>' +
        '<p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">' +
          escapeHtml(brief.projectDescription) +
        '</p>'
      : '') +
  '</div>';
}

// ─── Section 2: Architecture Overview ────────────────────────────────
function renderArchOverview(doc) {
  // Group components by their first defense layer
  var byLayer = {};
  doc.selectedComponents.forEach(function (c) {
    var primaryLayer = (c.layers && c.layers[0]) || 'Other';
    if (!byLayer[primaryLayer]) byLayer[primaryLayer] = [];
    byLayer[primaryLayer].push(c);
  });

  var layerHtml = DOC_LAYERS.map(function (layer) {
    var components = byLayer[layer.key] || [];
    // Sort within layer by cloud, then name
    components.sort(function (a, b) {
      if (a.cloud !== b.cloud) return a.cloud.localeCompare(b.cloud);
      return a.name.localeCompare(b.name);
    });
    return '<div class="arch-layer ' + layer.cls + '">' +
      '<div class="layer-head">' +
        '<span class="layer-name">' + escapeHtml(layer.key) + '</span>' +
        '<span class="layer-count">' + components.length + ' component' + (components.length !== 1 ? 's' : '') + '</span>' +
      '</div>' +
      (components.length === 0
        ? '<div class="arch-empty-layer">No components selected for this layer</div>'
        : '<div class="layer-components">' +
            components.map(function (c) {
              return '<span class="arch-component-chip ' + c.cloud.toLowerCase() + '">' +
                '<span class="risk-dot ' + riskClass(c.risk) + '"></span>' +
                (c.iconUri
                  ? '<span class="comp-icon sm"><img src="' + c.iconUri + '" alt=""></span>'
                  : '') +
                escapeHtml(c.name) +
              '</span>';
            }).join('') +
          '</div>') +
    '</div>';
  }).join('');

  return '<div class="doc-section" id="sec-arch">' +
    '<h2 class="sec-title"><span class="sec-num">2.</span> Architecture Overview</h2>' +
    '<p class="sec-intro">Components organized by defense layer. Each chip shows the component name with cloud color (left border) and risk indicator (dot). Multi-layer components are placed in their primary layer.</p>' +
    '<div class="arch-layered">' + layerHtml + '</div>' +
    '<p style="font-size:11px; color:var(--text-muted); font-style:italic; margin-top:10px;">' +
      '<strong>Legend:</strong> &nbsp;' +
      '<span class="risk-dot r-low" style="display:inline-block; width:6px; height:6px; background:var(--success); border-radius:50%; vertical-align:middle;"></span> Low risk &nbsp;|&nbsp; ' +
      '<span class="risk-dot r-med" style="display:inline-block; width:6px; height:6px; background:var(--warning); border-radius:50%; vertical-align:middle;"></span> Medium risk &nbsp;|&nbsp; ' +
      '<span class="risk-dot r-high" style="display:inline-block; width:6px; height:6px; background:var(--danger); border-radius:50%; vertical-align:middle;"></span> High risk' +
    '</p>' +
  '</div>';
}

// ─── Section 3: Component Inventory ──────────────────────────────────
function renderComponentInventory(doc) {
  // Sort by cloud then name
  var sorted = doc.selectedComponents.slice().sort(function (a, b) {
    if (a.cloud !== b.cloud) return a.cloud.localeCompare(b.cloud);
    return a.name.localeCompare(b.name);
  });

  var cardsHtml = sorted.map(function (c) {
    var layerTags = (c.layers || []).map(function (l) {
      return '<span class="layer-tag">' + escapeHtml(l) + '</span>';
    }).join('');
    return '<div class="comp-card">' +
      '<div class="comp-head">' +
        '<div class="left">' +
          (c.iconUri
            ? '<span class="comp-icon"><img src="' + c.iconUri + '" alt=""></span>'
            : '<span class="comp-icon no-icon">' + (c.cloud[0] || '?') + '</span>') +
          '<span class="cloud-tag ' + c.cloud.toLowerCase() + '">' + c.cloud + '</span>' +
          '<span class="name">' + escapeHtml(c.name) + '</span>' +
          '<span class="category-tag">' + escapeHtml(c.category || '') + '</span>' +
        '</div>' +
        '<span class="risk-pill ' + riskClass(c.risk) + '">Risk: ' + riskLabel(c.risk) + ' (' + (c.risk || '?') + '/10)</span>' +
      '</div>' +
      '<div class="purpose">' + escapeHtml(c.purpose || '') + '</div>' +
      (layerTags ? '<div class="layers-row">' + layerTags + '</div>' : '') +
    '</div>';
  }).join('');

  return '<div class="doc-section" id="sec-inventory">' +
    '<h2 class="sec-title"><span class="sec-num">3.</span> Component Inventory</h2>' +
    '<p class="sec-intro">Each cloud component selected for this architecture, with its purpose, risk classification, and the defense layer(s) it operates in. Risk scores are based on attack surface, blast radius, and typical exposure patterns.</p>' +
    cardsHtml +
  '</div>';
}

// ─── Section 4: Security Tooling ─────────────────────────────────────
function renderToolingSection(doc) {
  if (doc.selectedTools.length === 0) {
    return '<div class="doc-section" id="sec-tools">' +
      '<h2 class="sec-title"><span class="sec-num">4.</span> Security Tooling</h2>' +
      '<p class="sec-intro" style="color:var(--text-muted); font-style:italic;">No security tools selected. Return to Phase 3 Step 1 to choose your defense tooling.</p>' +
    '</div>';
  }

  // Tool type counts
  var typeCounts = { Native: 0, 'Third-Party': 0, Recommended: 0, OSS: 0 };
  doc.selectedTools.forEach(function (t) {
    if (typeCounts[t.type] != null) typeCounts[t.type]++;
  });

  // Group tools by component
  var componentsWithTools = doc.selectedComponents
    .filter(function (c) { return doc.toolsByComponent[c.id] && doc.toolsByComponent[c.id].length > 0; })
    .sort(function (a, b) {
      if (a.cloud !== b.cloud) return a.cloud.localeCompare(b.cloud);
      return a.name.localeCompare(b.name);
    });

  var groupsHtml = componentsWithTools.map(function (c) {
    var tools = doc.toolsByComponent[c.id] || [];
    // Sort tools by type (Native first, then Third-Party, then Recommended, OSS last)
    var typeOrder = { 'Native': 0, 'Third-Party': 1, 'Recommended': 2, 'OSS': 3 };
    tools.sort(function (a, b) {
      var ta = typeOrder[a.type] != null ? typeOrder[a.type] : 9;
      var tb = typeOrder[b.type] != null ? typeOrder[b.type] : 9;
      if (ta !== tb) return ta - tb;
      return a.name.localeCompare(b.name);
    });

    function typeMarker(type) {
      if (type === 'Native') return 'native';
      if (type === 'Third-Party') return 'thirdparty';
      if (type === 'Recommended') return 'recommended';
      return 'oss';
    }

    return '<div class="doc-tool-group">' +
      '<div class="tg-head">' +
        '<span class="cloud-tag ' + c.cloud.toLowerCase() + '">' + c.cloud + '</span>' +
        (c.iconUri
          ? '<span class="comp-icon sm"><img src="' + c.iconUri + '" alt=""></span>'
          : '') +
        '<span>' + escapeHtml(c.name) + '</span>' +
        '<span style="font-size:10px; font-family:var(--mono); color:var(--text-muted); margin-left:auto;">' +
          tools.length + ' tool' + (tools.length !== 1 ? 's' : '') + '</span>' +
      '</div>' +
      tools.map(function (t) {
        return '<div class="tool-line">' +
          '<span class="type-marker ' + typeMarker(t.type) + '"></span>' +
          '<span class="name">' + escapeHtml(t.name) + '</span>' +
          '<span class="meta">' + escapeHtml(t.type || '') +
            (t.vendor ? ' • ' + escapeHtml(t.vendor) : '') +
          '</span>' +
        '</div>';
      }).join('') +
    '</div>';
  }).join('');

  return '<div class="doc-section" id="sec-tools">' +
    '<h2 class="sec-title"><span class="sec-num">4.</span> Security Tooling</h2>' +
    '<p class="sec-intro">Security tools selected for each component, grouped by component. Type markers indicate Native (built-in cloud tools), Third-Party (commercial), Recommended (best-practice for the component), or OSS (open source).</p>' +
    '<div class="doc-stat-strip">' +
      '<div class="doc-stat"><div class="num success">' + typeCounts['Native'] + '</div><div class="label">Native</div></div>' +
      '<div class="doc-stat"><div class="num">' + typeCounts['Third-Party'] + '</div><div class="label">Third-Party</div></div>' +
      '<div class="doc-stat"><div class="num warning">' + typeCounts['Recommended'] + '</div><div class="label">Recommended</div></div>' +
      '<div class="doc-stat"><div class="num muted">' + typeCounts['OSS'] + '</div><div class="label">OSS</div></div>' +
    '</div>' +
    groupsHtml +
  '</div>';
}

// ─── Section 5: Detection Coverage ───────────────────────────────────
function renderDetectionCoverage(doc) {
  var willHave = doc.detectionsByStatus.will.concat(doc.detectionsByStatus.have);

  if (doc.relevantDetections.length === 0) {
    return '<div class="doc-section" id="sec-detections">' +
      '<h2 class="sec-title"><span class="sec-num">5.</span> Detection Coverage</h2>' +
      '<p class="sec-intro" style="color:var(--text-muted); font-style:italic;">No detections cataloged for the selected components.</p>' +
    '</div>';
  }

  // Sort: critical first, then high, then medium, then low; within severity by component name
  function sevRank(s) {
    var l = (s || '').toLowerCase();
    if (l === 'critical') return 0;
    if (l === 'high') return 1;
    if (l === 'medium') return 2;
    return 3;
  }
  willHave.sort(function (a, b) {
    var sa = sevRank(a.severity), sb = sevRank(b.severity);
    if (sa !== sb) return sa - sb;
    var na = doc.componentsById[a.componentId] ? doc.componentsById[a.componentId].name : '';
    var nb = doc.componentsById[b.componentId] ? doc.componentsById[b.componentId].name : '';
    return na.localeCompare(nb);
  });

  function sevClass(s) {
    var l = (s || '').toLowerCase();
    if (l === 'critical') return 'crit';
    if (l === 'high') return 'high';
    if (l === 'medium') return 'med';
    return 'low';
  }

  // Severity distribution chart
  var maxSev = Math.max(doc.sevDistTotal.critical, doc.sevDistTotal.high, doc.sevDistTotal.medium, doc.sevDistTotal.low, 1);

  function distRow(label, sevKey, fillClass) {
    var covered = doc.sevDist[sevKey] || 0;
    var total = doc.sevDistTotal[sevKey] || 0;
    var pct = total > 0 ? (covered / total * 100) : 0;
    var widthPct = maxSev > 0 ? (total / maxSev * 100) : 0;
    return '<div class="dist-chart-row">' +
      '<span class="dist-label">' + label + '</span>' +
      '<div class="dist-bar">' +
        '<div class="dist-fill ' + fillClass + '" style="width:' + widthPct + '%;">' +
          covered + '/' + total + ' (' + Math.round(pct) + '%)' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  var rowsHtml = willHave.length === 0
    ? '<tr><td colspan="5" style="text-align:center; padding:20px; color:var(--text-muted); font-style:italic;">No detections marked as Will or Have. Return to Phase 3 Step 2 to select detections.</td></tr>'
    : willHave.map(function (d) {
        var c = doc.componentsById[d.componentId];
        var status = doc.detectionsByStatus.will.indexOf(d) !== -1 ? 'will' : 'have';
        return '<tr>' +
          '<td><strong>' + escapeHtml(d.name || '') + '</strong><br>' +
              '<span style="font-size:11px; color:var(--text-muted);">' + escapeHtml(c ? c.name : '') + '</span></td>' +
          '<td><span class="severity-badge ' + sevClass(d.severity) + '">' + escapeHtml(d.severity || 'Medium') + '</span></td>' +
          '<td style="font-family:var(--mono); font-size:11px; color:var(--text-muted);">' + escapeHtml((d.platform || '').slice(0, 40)) + '</td>' +
          '<td style="font-family:var(--mono); font-size:11px;">' + escapeHtml(d.mitre || '') + '</td>' +
          '<td><span class="det-status ' + status + '">' + (status === 'will' ? 'Will implement' : 'Already have') + '</span></td>' +
        '</tr>';
      }).join('');

  return '<div class="doc-section" id="sec-detections">' +
    '<h2 class="sec-title"><span class="sec-num">5.</span> Detection Coverage</h2>' +
    '<p class="sec-intro">Detections planned (Will implement) and already in place (Have), of those available across the selected components. Bars show coverage by severity tier — narrower bars mean higher coverage rates.</p>' +
    '<h3 class="sub-title">Coverage by severity</h3>' +
    '<div class="dist-chart">' +
      distRow('Critical', 'critical', 'crit') +
      distRow('High', 'high', 'high') +
      distRow('Medium', 'medium', 'med') +
      distRow('Low', 'low', 'low') +
    '</div>' +
    '<h3 class="sub-title">Detection inventory (Will + Have)</h3>' +
    '<div class="doc-table-wrap">' +
      '<table class="doc-table">' +
        '<thead><tr>' +
          '<th>Detection / Component</th>' +
          '<th>Severity</th>' +
          '<th>Platform</th>' +
          '<th>MITRE</th>' +
          '<th>Status</th>' +
        '</tr></thead>' +
        '<tbody>' + rowsHtml + '</tbody>' +
      '</table>' +
    '</div>' +
  '</div>';
}

// ─── Section 6: SecOps Dashboards ────────────────────────────────────
function renderDashboardsSection(doc) {
  if (doc.selectedDashboards.length === 0) {
    return '<div class="doc-section" id="sec-dashboards">' +
      '<h2 class="sec-title"><span class="sec-num">6.</span> SecOps Dashboards</h2>' +
      '<p class="sec-intro" style="color:var(--text-muted); font-style:italic;">No dashboards selected. Return to Phase 3 Step 3 to choose dashboards relevant to your architecture.</p>' +
    '</div>';
  }

  // Count visualizations per dashboard
  var vizCountByDash = {};
  doc.allViz.forEach(function (v) {
    vizCountByDash[v.dashId] = (vizCountByDash[v.dashId] || 0) + 1;
  });

  var cardsHtml = doc.selectedDashboards.map(function (d) {
    var vizCount = vizCountByDash[d.id] || 0;
    return '<div class="doc-dash-card">' +
      '<div class="name">' + escapeHtml(d.name) + '</div>' +
      '<div class="meta">' + escapeHtml(d.category || '') + ' • ' + vizCount + ' visualizations' +
        (d.refresh ? ' • Refresh: ' + escapeHtml(d.refresh) : '') + '</div>' +
      '<div class="why">' + escapeHtml((d.whyItMatters || '').slice(0, 220)) + '</div>' +
    '</div>';
  }).join('');

  return '<div class="doc-section" id="sec-dashboards">' +
    '<h2 class="sec-title"><span class="sec-num">6.</span> SecOps Dashboards</h2>' +
    '<p class="sec-intro">SOC dashboards prioritized for monitoring this architecture. Each dashboard groups related visualizations targeting specific threat categories or operational concerns.</p>' +
    '<div class="doc-dash-grid">' + cardsHtml + '</div>' +
  '</div>';
}

// ─── Section 7: Log Strategy ─────────────────────────────────────────
function renderLogStrategy(doc) {
  function tierBlock(tierKey, tierClass, label, events, strategy) {
    var strategyLabels = {
      'ingest-all': 'Ingest all → SIEM',
      'ingest-archive': 'Ingest + cold archive',
      'sample': 'Sample (e.g., 10%)',
      'archive-only': 'Archive only (no SIEM)',
      'defer': 'Defer until needed',
    };
    return '<div class="log-tier-doc">' +
      '<div class="tier-header">' +
        '<span class="tier-name ' + tierClass + '">' + label + ' &nbsp;<span style="color:var(--text-muted); font-weight:normal; font-family:var(--mono);">(' + events.length + ' events)</span></span>' +
        '<span class="strategy-tag">' + escapeHtml(strategyLabels[strategy] || strategy) + '</span>' +
      '</div>' +
    '</div>';
  }

  return '<div class="doc-section" id="sec-logs">' +
    '<h2 class="sec-title"><span class="sec-num">7.</span> Log Strategy</h2>' +
    '<p class="sec-intro">Log ingestion strategy by event tier. MUST events are essential for security operations and should always be ingested. Should and Nice-to-have events are budget-driven decisions weighed against detection completeness.</p>' +
    '<div class="doc-stat-strip">' +
      '<div class="doc-stat"><div class="num danger">' + doc.logEventsByTier.must.length + '</div><div class="label">MUST events</div></div>' +
      '<div class="doc-stat"><div class="num">' + doc.logEventsByTier.should.length + '</div><div class="label">Should events</div></div>' +
      '<div class="doc-stat"><div class="num muted">' + doc.logEventsByTier.nice.length + '</div><div class="label">Nice-to-have</div></div>' +
      '<div class="doc-stat"><div class="num">' + doc.relevantLogEventsCount + '</div><div class="label">Total events</div></div>' +
    '</div>' +
    tierBlock('must', 'must', '⭐ MUST', doc.logEventsByTier.must, doc.logStrategy.must) +
    tierBlock('should', 'should', '✓ Should', doc.logEventsByTier.should, doc.logStrategy.should) +
    tierBlock('nice', 'nice', '○ Nice-to-have', doc.logEventsByTier.nice, doc.logStrategy.nice) +
    '<p style="font-size:11px; color:var(--text-muted); font-style:italic; margin-top:12px;">' +
      'See appendix for the complete event-by-event breakdown if needed.' +
    '</p>' +
  '</div>';
}

// ─── Section 8: MITRE ATT&CK Coverage ────────────────────────────────
function renderMitreCoverage(doc) {
  if (doc.mitreCoverageCount === 0) {
    return '<div class="doc-section" id="sec-mitre">' +
      '<h2 class="sec-title"><span class="sec-num">8.</span> MITRE ATT&amp;CK Coverage</h2>' +
      '<p class="sec-intro" style="color:var(--text-muted); font-style:italic;">No MITRE ATT&amp;CK technique mappings available for the selected components.</p>' +
    '</div>';
  }

  // Tactic display order matches MITRE ATT&CK kill chain
  var tacticOrder = [
    'Reconnaissance', 'Resource Development', 'Initial Access', 'Execution',
    'Persistence', 'Privilege Escalation', 'Defense Evasion', 'Credential Access',
    'Discovery', 'Lateral Movement', 'Collection', 'Command and Control',
    'Exfiltration', 'Impact',
  ];
  var sortedTactics = Object.keys(doc.mitreByTactic).sort(function (a, b) {
    var ia = tacticOrder.indexOf(a), ib = tacticOrder.indexOf(b);
    if (ia === -1) ia = 99; if (ib === -1) ib = 99;
    return ia - ib;
  });

  var blocksHtml = sortedTactics.map(function (tactic) {
    var techniques = doc.mitreByTactic[tactic];
    techniques.sort(function (a, b) { return a.mitreId.localeCompare(b.mitreId); });
    var chipsHtml = techniques.map(function (t) {
      return '<span class="mitre-tech-chip" title="' + escapeHtml(t.name) + ' — covered by ' + t.components.length + ' component(s)">' +
        '<span class="tech-id">' + escapeHtml(t.mitreId) + '</span>' +
        '<span class="tech-name">' + escapeHtml((t.name || '').slice(0, 30)) + '</span>' +
        '<span class="coverage-count">' + t.components.length + '</span>' +
      '</span>';
    }).join('');
    return '<div class="mitre-tactic-block">' +
      '<div class="tactic-head">' +
        '<span class="tactic-name">' + escapeHtml(tactic) + '</span>' +
        '<span class="tactic-count">' + techniques.length + ' technique' + (techniques.length !== 1 ? 's' : '') + '</span>' +
      '</div>' +
      '<div class="technique-list">' + chipsHtml + '</div>' +
    '</div>';
  }).join('');

  return '<div class="doc-section" id="sec-mitre">' +
    '<h2 class="sec-title"><span class="sec-num">8.</span> MITRE ATT&amp;CK Coverage</h2>' +
    '<p class="sec-intro">Adversary techniques addressed by the selected components, organized by MITRE ATT&amp;CK tactic. The number on each chip indicates how many of your components map to that technique. Coverage is based on per-component MITRE technique mappings in the underlying dataset — not synthesized.</p>' +
    '<div class="doc-stat-strip">' +
      '<div class="doc-stat"><div class="num">' + doc.mitreCoverageCount + '</div><div class="label">Techniques</div></div>' +
      '<div class="doc-stat"><div class="num">' + sortedTactics.length + '</div><div class="label">Tactics</div></div>' +
    '</div>' +
    '<div class="mitre-matrix">' +
      '<div class="mitre-tactic-list">' + blocksHtml + '</div>' +
    '</div>' +
  '</div>';
}

// ─── Section 9: Compliance Mapping ───────────────────────────────────
function renderComplianceMapping(doc) {
  if (doc.userFrameworks.length === 0) {
    return '<div class="doc-section" id="sec-compliance">' +
      '<h2 class="sec-title"><span class="sec-num">9.</span> Compliance Mapping</h2>' +
      '<p class="sec-intro" style="color:var(--text-muted); font-style:italic;">No compliance frameworks selected in Phase 1. Return to Phase 1 to select frameworks (SOC 2, ISO 27001, HIPAA, PCI-DSS, GDPR, etc.) for control mapping.</p>' +
    '</div>';
  }

  var frameworksHtml = doc.userFrameworks.map(function (fw) {
    var coverage = doc.complianceCoverage[fw];
    if (!coverage || coverage.controls.length === 0) {
      return '<div class="compl-framework">' +
        '<div class="fw-head">' +
          '<span class="fw-name">' + escapeHtml(fw) + '</span>' +
          '<span class="fw-meta">No controls mapped</span>' +
        '</div>' +
        '<p style="font-size:12px; color:var(--text-muted); font-style:italic;">No control mappings available in dataset for this framework × selected components combination.</p>' +
      '</div>';
    }
    var controlsHtml = coverage.controls.slice(0, 30).map(function (ctrl) {
      var compNames = ctrl.components.length > 5
        ? ctrl.components.slice(0, 5).join(', ') + ' +' + (ctrl.components.length - 5) + ' more'
        : ctrl.components.join(', ');
      return '<div class="compl-control-row">' +
        '<span class="control-id">' + escapeHtml(ctrl.controlId || '') + '</span>' +
        '<div class="control-detail">' +
          '<div class="control-name">' + escapeHtml(ctrl.controlName || '') + '</div>' +
          '<div class="control-comps">Covered by: ' + escapeHtml(compNames) + '</div>' +
        '</div>' +
      '</div>';
    }).join('');
    var moreNote = coverage.controls.length > 30
      ? '<p style="font-size:11px; color:var(--text-muted); font-style:italic; margin-top:8px;">' +
        '+ ' + (coverage.controls.length - 30) + ' more control(s) — see dataset XLSX for full list.</p>'
      : '';
    return '<div class="compl-framework">' +
      '<div class="fw-head">' +
        '<span class="fw-name">' + escapeHtml(fw) + '</span>' +
        '<span class="fw-meta">' + coverage.controls.length + ' controls • ' + coverage.componentCount + ' components</span>' +
      '</div>' +
      '<div class="fw-controls">' + controlsHtml + '</div>' +
      moreNote +
    '</div>';
  }).join('');

  return '<div class="doc-section" id="sec-compliance">' +
    '<h2 class="sec-title"><span class="sec-num">9.</span> Compliance Mapping</h2>' +
    '<p class="sec-intro">For each compliance framework in scope, the controls satisfied by your selected components. Mappings are sourced from the per-component compliance database — not interpreted or synthesized. Always validate with your auditor.</p>' +
    frameworksHtml +
  '</div>';
}

// ─── Section 10: Risk Summary ────────────────────────────────────────
function renderRiskSummary(doc) {
  var total = doc.riskDist.low + doc.riskDist.medium + doc.riskDist.high;
  if (total === 0) {
    return '<div class="doc-section" id="sec-risk">' +
      '<h2 class="sec-title"><span class="sec-num">10.</span> Risk Summary</h2>' +
      '<p class="sec-intro">No components selected.</p>' +
    '</div>';
  }

  function distRow(label, count, cls) {
    var pct = total > 0 ? (count / total * 100) : 0;
    return '<div class="dist-chart-row">' +
      '<span class="dist-label">' + label + '</span>' +
      '<div class="dist-bar">' +
        '<div class="dist-fill ' + cls + '" style="width:' + pct + '%;">' + count + ' (' + Math.round(pct) + '%)' + '</div>' +
      '</div>' +
    '</div>';
  }

  var topRisksHtml = doc.topRisks.map(function (c) {
    return '<div class="top-risk-row">' +
      '<span class="name">' + escapeHtml(c.name) + '</span>' +
      '<span class="cat">' + escapeHtml(c.cloud) + ' • ' + escapeHtml(c.category || '') + '</span>' +
      '<span class="score">' + (c.risk || '?') + '</span>' +
    '</div>';
  }).join('');

  return '<div class="doc-section" id="sec-risk">' +
    '<h2 class="sec-title"><span class="sec-num">10.</span> Risk Summary</h2>' +
    '<p class="sec-intro">Risk classification across selected components based on attack surface and blast radius. Higher-risk components warrant prioritized attention for tooling, monitoring, and incident response readiness.</p>' +
    '<div class="risk-summary-grid">' +
      '<div>' +
        '<h3 class="sub-title" style="margin-top:0;">Risk distribution</h3>' +
        '<div class="dist-chart">' +
          distRow('High', doc.riskDist.high, 'crit') +
          distRow('Medium', doc.riskDist.medium, 'high') +
          distRow('Low', doc.riskDist.low, 'low') +
        '</div>' +
      '</div>' +
      '<div class="top-risks-list">' +
        '<h3>Top 5 highest-risk components</h3>' +
        topRisksHtml +
      '</div>' +
    '</div>' +
  '</div>';
}

// ─── Section 11: Appendix ────────────────────────────────────────────
function renderAppendix(doc) {
  var brief = doc.brief;
  return '<div class="doc-section" id="sec-appendix">' +
    '<h2 class="sec-title"><span class="sec-num">11.</span> Appendix</h2>' +
    '<p class="sec-intro">Generation metadata and raw input echo for traceability.</p>' +
    '<div class="appendix-block">' +
      '<h3>Generation Metadata</h3>' +
      '<div class="kv-row"><span class="kv-key">Generated at</span><span class="kv-value">' + escapeHtml(doc.generatedAt) + '</span></div>' +
      '<div class="kv-row"><span class="kv-key">Tool version</span><span class="kv-value">Cloud Security Project Planner v1.0-round4</span></div>' +
      '<div class="kv-row"><span class="kv-key">Dataset version</span><span class="kv-value">144 components, 2032 tools, 412 detections</span></div>' +
    '</div>' +
    '<div class="appendix-block">' +
      '<h3>Project Brief (Raw)</h3>' +
      '<div class="kv-row"><span class="kv-key">Project Name</span><span class="kv-value">' + escapeHtml(brief.projectName || '') + '</span></div>' +
      '<div class="kv-row"><span class="kv-key">Company / Team</span><span class="kv-value">' + escapeHtml(brief.companyName || '') + '</span></div>' +
      '<div class="kv-row"><span class="kv-key">Date</span><span class="kv-value">' + escapeHtml(brief.date || '') + '</span></div>' +
      '<div class="kv-row"><span class="kv-key">Cloud Providers</span><span class="kv-value">' + escapeHtml((brief.cloudProviders || []).join(', ')) + '</span></div>' +
      '<div class="kv-row"><span class="kv-key">Project Type</span><span class="kv-value">' + escapeHtml(brief.projectType + (brief.projectType === 'Other' ? ' — ' + brief.projectTypeOther : '')) + '</span></div>' +
      '<div class="kv-row"><span class="kv-key">Scale</span><span class="kv-value">' + escapeHtml(brief.environmentScale || '') + '</span></div>' +
      '<div class="kv-row"><span class="kv-key">Compliance</span><span class="kv-value">' + escapeHtml((brief.compliance || []).join(', ') || '(none)') + '</span></div>' +
    '</div>' +
  '</div>';
}

// ─── Event wiring ────────────────────────────────────────────────────
function wireP4Events() {
  document.querySelectorAll('[data-p4action]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var action = btn.dataset.p4action;
      switch (action) {
        case 'back-to-phase2': showPhase(2); break;
        case 'back-to-phase3':
          showPhase(3);
          if (typeof renderPhase3 === 'function') renderPhase3();
          break;
        case 'print': window.print(); break;
        case 'export-json': p4ExportJSON(); break;
      }
    });
  });
}

// ─── JSON export ─────────────────────────────────────────────────────
function p4ExportJSON() {
  var doc = assembleDocData();
  // Trim heavy fields for export
  var exportable = {
    generatedAt: doc.generatedAt,
    brief: doc.brief,
    components: doc.selectedComponents.map(function (c) {
      return { id: c.id, name: c.name, cloud: c.cloud, category: c.category, layers: c.layers, risk: c.risk };
    }),
    tools: doc.selectedTools,
    detections: {
      will: doc.detectionsByStatus.will,
      have: doc.detectionsByStatus.have,
    },
    dashboards: doc.selectedDashboards.map(function (d) {
      return { id: d.id, name: d.name, category: d.category };
    }),
    logStrategy: doc.logStrategy,
    mitreCoverage: Object.keys(doc.mitreByTactic).map(function (tactic) {
      return {
        tactic: tactic,
        techniques: doc.mitreByTactic[tactic].map(function (t) {
          return { id: t.mitreId, name: t.name, componentIds: t.components };
        })
      };
    }),
    complianceCoverage: doc.complianceCoverage,
    riskDistribution: doc.riskDist,
    topRisks: doc.topRisks.map(function (c) {
      return { name: c.name, cloud: c.cloud, risk: c.risk };
    }),
  };

  var json = JSON.stringify(exportable, null, 2);
  var blob = new Blob([json], { type: 'application/json' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  var safeName = (doc.brief.projectName || 'project').replace(/[^a-zA-Z0-9-_]/g, '-').toLowerCase();
  a.href = url;
  a.download = safeName + '-architecture-' + doc.generatedAt.slice(0, 10) + '.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(function () { URL.revokeObjectURL(url); }, 100);
}

// Hook
window.renderPhase4 = renderPhase4;
