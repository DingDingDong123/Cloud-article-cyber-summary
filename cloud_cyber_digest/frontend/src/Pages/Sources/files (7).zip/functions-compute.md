# Functions and Compute Modules

Last researched: 2026-06-08. Sources are Palantir public docs; dates inline. Re-verify dated claims before production use.

## Contents
- Capabilities
- Language feature support (TS v1 vs TS v2 vs Python)
- Decision framework (full)
- AIP Logic block-splitting rule
- Best practices
- Canonical examples
- Pitfalls
- Recent changes and deprecations

## Capabilities

- Functions support TypeScript v1, TypeScript v2, and Python. TS v2 and Python went GA the week of 2025-07-28 (announcements/2025-07).
- Functions on Objects (FoO): Ontology-aware logic for Workshop variables, derived columns, chart aggregations, action backing, external enrichment (webhooks in TS v1), and Pipeline Builder UDFs (Python).
- AIP Logic: no-code LLM function builder. Blocks include Use LLM, Query objects, Apply actions, Execute function, conditionals, Update application variable.
- Compute Modules: containerized any-language workloads. Functions mode (interactive query) and pipeline mode (provenance-controlled I/O). Predictive autoscaling; replicas default 1 vCPU / 4 GB; container must run as non-root numeric `USER 5000`; sources mount credentials via `SOURCE_CREDENTIALS` env var (compute-modules/overview).
- Function interfaces and function-backed actions (batched execution) for high-throughput edits.
- AIP Evals: test/eval suites against any function (AIP Logic, AIP Chatbot-as-function, code-authored).

## Language feature support (functions/language-feature-support)

TypeScript v2 advantages over v1 (verbatim from the docs):
- "Serverless execution in a full Node.js runtime: TypeScript v2 functions run in a Node.js environment, supporting core modules like `fs`, `child_process`, and `crypto`."
- "First-class OSDK support: The OSDK can now be used seamlessly in TypeScript v2 functions."
- "Configurable resource requests: TypeScript v2 functions allow you to request up to 8 vCPUs and 5GB of memory."

Matrix highlights:
- Pipeline Builder UDF support: Python only.
- Webhook support: TypeScript v1 only.
- Ontology interfaces support: TypeScript v2 only.
- External API calls: TS v1, TS v2, and Python.
- Deployed execution: TS v2 and Python.
- "Functions on models": AIP Logic and TS v1 only.

## Decision framework (full)

| Need | Choose |
|---|---|
| LLM orchestration, prompt + tools, no-code, evaluable | AIP Logic |
| Sub-second typed Ontology read/write, low overhead | Function — TS v2 if you need Ontology interfaces; Python if you need a Pipeline Builder UDF or Pandas-native code |
| Webhook call from a function | TypeScript v1 function (only place webhooks are supported) |
| Function on a model (legacy approach) | TS v1 / AIP Logic (only places "functions on models" are supported) |
| Compute-intensive, long-running, stateful, non-Python/non-TS, model hosting, legacy code | Compute Module — Foundry functions are ill-suited for compute-intensive, long-running stateful processes |
| External pipeline as a sidecar/container with provenance | Compute Module in pipeline mode |

## AIP Logic block-splitting rule (logic/faq)

Start with a single large block to iterate quickly. Split into multiple blocks when: you have multiple steps and are getting inconsistent results; the block hits its context limit; or each run takes too long. Each block gets its own context window, so splitting means the LLM only sees what you pass in, you are less likely to run out of tokens, and several smaller tasks can execute faster than one long one. Practical trigger: more than ~5 LLM-tool calls in a single chain is a sign to split.

## Best practices

- Default new Functions repos to TypeScript v2.
- Prefer serverless over deployed functions: "you can have multiple versions of a single function available on demand, making upgrades safer."
- Bridge pro-code into no-code pipelines via Python UDFs in Pipeline Builder.
- Version functions explicitly; consumers (Actions, Workshop) bind to a specific version or `latest`. Do not pin production to `latest` without an Evals suite — versions can shift on merge.
- Unit-test functions with the built-in framework (stub objects, mock dates/UUIDs, mock users/groups, verify Ontology edits).
- Set Compute Module replica resources explicitly (default 1 vCPU / 4 GB); bound min/max replicas to control cost and meet SLOs.
- AIP Logic edits the Ontology ONLY when the Logic function is executed from an Action — even if the function contains an Apply action block. Testing in the Debugger will not apply edits.
- Reduce AIP Logic cost: select only needed properties on the Query Objects tool; each block has a minimum compute cost and tool calls compound it.

## Canonical example — Python function on objects

```python
from functions.api import function
from ontology_sdk.ontology.objects import Order

@function()
def order_summary(order_id: str) -> str:
    order = Order.get(order_id)
    items = order.line_items.search().take(50)
    total = sum(i.price * i.quantity for i in items)
    return f"{order.customer.name}: {len(items)} items, ${total:.2f}"
```

## Canonical example — Compute Module function (Python)

```python
# app.py
from compute_modules.functions import function, run
from compute_modules.sources_v2 import get_source

@function
def score(payload: dict) -> dict:
    source = get_source("MyApiSource")
    # call source.client / external API, return scoring
    return {"score": 0.87}

if __name__ == "__main__":
    run()
```

```dockerfile
FROM --platform=linux/amd64 python:3.12
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY src .
USER 5000
CMD ["python", "app.py"]
```

## Pitfalls

- Using a function for a pipeline-derivable column (e.g., `full_name = first + " " + last`). Compute it in the backing pipeline.
- Putting heavy/long-running work in a function instead of a Compute Module or pipeline.
- Compute Module functions are invisible in Foundry until the module is running and responsive — debug via replica status.
- Forgetting to enable exports/markings on external transforms when a function uses sources with Foundry inputs.
- Pinning production to `latest` function version without an Evals suite.

## Recent changes and deprecations

- 2025-07-28 — TypeScript v2 and Python functions GA on all enrollments.
- Function-backed actions with batched execution are the current pattern for high-throughput edits.
- Legacy language models in functions ("language-models-legacy") superseded by TS v2 / Python language model APIs.
- TS v1 webhooks remain TS v1 only.
