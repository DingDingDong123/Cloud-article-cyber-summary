/* === v10.js === */
// ═══════════════════════════════════════════════════════════════════════
// Cloud Security Advisor v4 — Canvas mode
// ═══════════════════════════════════════════════════════════════════════

// DATA, TOOL_ENRICHMENT, and ICON_MAP are injected above this script

const componentById = {};
DATA.components.forEach(c => { componentById[c.ComponentID] = c; });

// View mode: "executive" | "standard" | "deep"
let viewMode = 'standard';

// Customized risk scores per component (ComponentID -> override score)
const customRisk = {};

// Collapsed section ids
const collapsedSections = new Set();

// Report metadata (customer info, engagement details)
const metadata = {
  customer: 'Customer Name',
  engagementDate: new Date().toISOString().slice(0, 10),
  advisor: 'Your Name',
  reportTitle: 'Cloud Security Architecture Assessment',
};

// PDF print options
const pdfOptions = {
  perComponentPage: true,  // one component per page
  appendixMode: false,      // move tables to appendix
};

// User-edited executive summary (null = use auto-generated)
let customExecSummary = null;

// Layer definitions + colors for the report
const LAYERS = [
  { key: 'Identity',     className: 'identity',   desc: 'Authentication, authorization, identity providers' },
  { key: 'Network',      className: 'network',    desc: 'VPCs, firewalls, load balancers, DNS, CDN' },
  { key: 'OS / Compute', className: 'os-compute', desc: 'Virtual machines, containers, endpoints' },
  { key: 'Application',  className: 'application', desc: 'APIs, app platforms, messaging, serverless logic' },
  { key: 'Data',         className: 'data',       desc: 'Storage, databases, analytics warehouses' },
  { key: 'Detection',    className: 'detection',  desc: 'SIEM, EDR, monitoring, security tooling' },
];

// ─── CANVAS STATE ──────────────────────────────────────────────────────
// state.nodes: [{ id, componentId, label, x, y }]
// state.edges: [{ id, sourceId, targetId }]
const state = { nodes: [], edges: [] };
let nextNodeId = 1;
let nextEdgeId = 1;
let selectedNodeId = null;
let connectMode = false;
let connectSourceId = null;
let draggingNodeId = null;
let dragOffsetX = 0, dragOffsetY = 0;

// Palette state
let paletteFilter = 'ALL';
let paletteSearch = '';

// ─── DOM REFS ──────────────────────────────────────────────────────────
const $paletteList = document.getElementById('palette-list');
const $paletteSearch = document.getElementById('palette-search');
const $canvasArea = document.getElementById('canvas-area');
const $canvasSvg = document.getElementById('canvas-svg');
const $canvasEmpty = document.getElementById('canvas-empty');
const $report = document.getElementById('report-container');
const $quickPicks = document.getElementById('quick-picks');

// ─── UTILITIES ─────────────────────────────────────────────────────────
function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function iconHTML(comp, sizeClass) {
  sizeClass = sizeClass || "icon-20";
  if (!comp || !comp._icon_uri) return '';
  const srcClass = comp._icon_source ? ('icon-src-' + comp._icon_source) : '';
  return `<span class="icon ${sizeClass} ${srcClass}" style="background-image:url('${comp._icon_uri}')"></span>`;
}

function getNodeById(id) { return state.nodes.find(n => n.id === id); }

// ─── PALETTE ───────────────────────────────────────────────────────────
function renderPalette() {
  const q = paletteSearch.toLowerCase();
  const filtered = DATA.components.filter(c => {
    if (paletteFilter !== 'ALL' && c["Cloud Provider"] !== paletteFilter) return false;
    if (q && !c["Component Name"].toLowerCase().includes(q) &&
        !(c["Category"] || '').toLowerCase().includes(q)) return false;
    return true;
  });
  // Sort by provider then name
  filtered.sort((a, b) => {
    if (a["Cloud Provider"] !== b["Cloud Provider"]) return a["Cloud Provider"].localeCompare(b["Cloud Provider"]);
    return a["Component Name"].localeCompare(b["Component Name"]);
  });

  $paletteList.innerHTML = filtered.map(c => `
    <div class="palette-item" draggable="true" data-component-id="${c.ComponentID}">
      ${iconHTML(c, "icon-24")}
      <span class="name" title="${escapeHtml(c['Component Name'])}">${escapeHtml(c['Component Name'])}</span>
      <span class="provider-mini ${c['Cloud Provider']}">${c['Cloud Provider']}</span>
    </div>
  `).join('');
}

// ─── DRAG FROM PALETTE TO CANVAS ───────────────────────────────────────
$paletteList.addEventListener('dragstart', e => {
  const item = e.target.closest('.palette-item');
  if (!item) return;
  const cid = Number(item.dataset.componentId);
  e.dataTransfer.setData('text/component-id', String(cid));
  e.dataTransfer.effectAllowed = 'copy';
  item.classList.add('dragging');
});
$paletteList.addEventListener('dragend', e => {
  const item = e.target.closest('.palette-item');
  if (item) item.classList.remove('dragging');
});
$canvasArea.addEventListener('dragover', e => {
  if (e.dataTransfer.types.includes('text/component-id')) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  }
});
$canvasArea.addEventListener('drop', e => {
  const cid = Number(e.dataTransfer.getData('text/component-id'));
  if (!cid) return;
  e.preventDefault();
  const rect = $canvasArea.getBoundingClientRect();
  const x = e.clientX - rect.left - 90; // center-ish
  const y = e.clientY - rect.top - 30;
  addNode(cid, Math.max(8, x), Math.max(48, y));
});

function addNode(componentId, x, y, label) {
  const comp = componentById[componentId];
  if (!comp) return;
  const defaultLabel = label || comp["Component Name"];
  const id = 'n' + (nextNodeId++);
  // New nodes start unpinned (will flow with auto-layout)
  state.nodes.push({ id, componentId, label: defaultLabel, x, y, pinned: false });
  // Auto-layout on every add (per user preference)
  autoLayout();
  suggestEdges();
  renderReport();
  persist();
}

function deleteNode(id) {
  state.nodes = state.nodes.filter(n => n.id !== id);
  state.edges = state.edges.filter(e => e.sourceId !== id && e.targetId !== id);
  state.suggestedEdges = (state.suggestedEdges || []).filter(s => s.sourceId !== id && s.targetId !== id);
  if (selectedNodeId === id) selectedNodeId = null;
  if (connectSourceId === id) connectSourceId = null;
  // Re-run layout so remaining nodes reflow
  if (state.nodes.length > 0) {
    autoLayout();
    suggestEdges();
  } else {
    renderCanvas();
  }
  renderReport();
  persist();
}

function updateNodeLabel(id, label) {
  const n = getNodeById(id);
  if (n) { n.label = label; persist(); }
}

function updateNodePosition(id, x, y) {
  const n = getNodeById(id);
  if (n) { n.x = x; n.y = y; updateEdges(); persist(); }
}

function addEdge(sourceId, targetId) {
  if (sourceId === targetId) return;
  // Dedupe
  if (state.edges.some(e => (e.sourceId === sourceId && e.targetId === targetId) ||
                            (e.sourceId === targetId && e.targetId === sourceId))) return;
  state.edges.push({ id: 'e' + (nextEdgeId++), sourceId, targetId });
  renderCanvas();
  persist();
}

function deleteEdge(id) {
  state.edges = state.edges.filter(e => e.id !== id);
  renderCanvas();
  persist();
}

// ─── RENDER CANVAS ─────────────────────────────────────────────────────
function renderCanvas() {
  // Hide/show empty hint
  $canvasEmpty.style.display = state.nodes.length === 0 ? 'flex' : 'none';

  // Remove existing node + layer decoration DOM
  $canvasArea.querySelectorAll('.node, .layer-divider, .layer-column-label').forEach(n => n.remove());

  // Render layer columns (subtle dividers + top labels) only if there are nodes
  if (state.nodes.length > 0) {
    // Figure out which layers are present in canvas
    const presentLayers = [];
    LAYER_ORDER.forEach(l => {
      const hasNodes = state.nodes.some(n => {
        const c = componentById[n.componentId];
        return c && layerOfComponent(c) === l;
      });
      if (hasNodes) presentLayers.push(l);
    });

    const COL_WIDTH = 260;
    const COL_GAP = 40;
    const START_X = 40;

    presentLayers.forEach((layer, idx) => {
      const colX = START_X + idx * (COL_WIDTH + COL_GAP);
      // Column label at top
      const lbl = document.createElement('div');
      lbl.className = 'layer-column-label';
      lbl.textContent = layer;
      lbl.style.left = colX + 'px';
      lbl.style.width = COL_WIDTH + 'px';
      $canvasArea.appendChild(lbl);
      // Divider line on the RIGHT of each column except the last
      if (idx < presentLayers.length - 1) {
        const divider = document.createElement('div');
        divider.className = 'layer-divider';
        divider.style.left = (colX + COL_WIDTH + COL_GAP / 2) + 'px';
        $canvasArea.appendChild(divider);
      }
    });
  }

  // Render nodes
  state.nodes.forEach(n => {
    const comp = componentById[n.componentId];
    if (!comp) return;
    const baseRisk = Number(comp["Risk Score"]) || 0;
    const effectiveRisk = customRisk[n.id] !== undefined ? customRisk[n.id] : baseRisk;
    const riskClass = effectiveRisk >= 9 ? 'risk-crit' : effectiveRisk >= 7 ? 'risk-high' : effectiveRisk >= 5 ? 'risk-med' : 'risk-low';
    const isCustom = customRisk[n.id] !== undefined;
    const borderRiskClass = effectiveRisk >= 9 ? 'risk-crit' : effectiveRisk >= 7 ? 'risk-high' : '';
    const pinnedClass = n.pinned ? 'pinned' : '';
    const nodeEl = document.createElement('div');
    nodeEl.className = `node ${borderRiskClass} ${pinnedClass} ${selectedNodeId === n.id ? 'selected' : ''} ${connectSourceId === n.id ? 'connect-source' : ''}`;
    nodeEl.style.left = n.x + 'px';
    nodeEl.style.top = n.y + 'px';
    nodeEl.dataset.nodeId = n.id;
    nodeEl.innerHTML = `
      <div class="node-top">
        ${iconHTML(comp, "icon-24")}
        <span class="node-type">${escapeHtml(comp["Component Name"])}</span>
      </div>
      <input class="node-label" type="text" value="${escapeHtml(n.label)}" data-node-id="${n.id}" />
      <div class="node-meta">
        <span class="provider-chip ${comp['Cloud Provider']}">${comp['Cloud Provider']}</span>
        <span class="risk-badge ${riskClass} ${isCustom ? 'customized' : ''}" data-node-id="${n.id}" title="Click to edit risk score${isCustom ? ' (customized)' : ''}">Risk ${effectiveRisk}/10</span>
      </div>
      <div class="node-actions">
        <button class="node-action-btn connect" data-action="connect" data-node-id="${n.id}" title="Connect to another node">&#x2194;</button>
        <button class="node-action-btn delete" data-action="delete" data-node-id="${n.id}" title="Delete node">&times;</button>
      </div>
    `;
    $canvasArea.appendChild(nodeEl);
  });

  updateEdges();
}

function updateEdges() {
  // Clear SVG contents except defs
  while ($canvasSvg.firstChild) $canvasSvg.removeChild($canvasSvg.firstChild);

  const nodeRects = {};
  $canvasArea.querySelectorAll('.node').forEach(el => {
    const id = el.dataset.nodeId;
    const rect = el.getBoundingClientRect();
    const canvasRect = $canvasArea.getBoundingClientRect();
    nodeRects[id] = {
      x: rect.left - canvasRect.left,
      y: rect.top - canvasRect.top,
      w: rect.width,
      h: rect.height,
    };
  });

  // Size the SVG to the canvas area
  $canvasSvg.setAttribute('width', $canvasArea.clientWidth);
  $canvasSvg.setAttribute('height', $canvasArea.clientHeight);
  $canvasSvg.style.pointerEvents = 'none';

  state.edges.forEach(e => {
    const s = nodeRects[e.sourceId];
    const t = nodeRects[e.targetId];
    if (!s || !t) return;
    const x1 = s.x + s.w / 2, y1 = s.y + s.h / 2;
    const x2 = t.x + t.w / 2, y2 = t.y + t.h / 2;
    const midX = (x1 + x2) / 2, midY = (y1 + y2) / 2;
    // Use quadratic curve for nicer look
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    const d = `M ${x1} ${y1} Q ${midX} ${midY} ${x2} ${y2}`;
    path.setAttribute('d', d);
    path.setAttribute('class', 'edge');
    path.setAttribute('data-edge-id', e.id);
    path.style.pointerEvents = 'stroke';
    path.style.cursor = 'pointer';
    path.addEventListener('click', (ev) => {
      ev.stopPropagation();
      if (confirm('Delete this connection?')) deleteEdge(e.id);
    });
    $canvasSvg.appendChild(path);
  });

  // Render suggested edges (dotted, clickable to accept or dismiss)
  (state.suggestedEdges || []).forEach(sug => {
    const s = nodeRects[sug.sourceId];
    const t = nodeRects[sug.targetId];
    if (!s || !t) return;
    const x1 = s.x + s.w / 2, y1 = s.y + s.h / 2;
    const x2 = t.x + t.w / 2, y2 = t.y + t.h / 2;
    const midX = (x1 + x2) / 2, midY = (y1 + y2) / 2;

    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    const d = `M ${x1} ${y1} Q ${midX} ${midY} ${x2} ${y2}`;
    path.setAttribute('d', d);
    path.setAttribute('class', 'edge suggested');
    path.setAttribute('data-sug-id', sug.id);
    path.style.pointerEvents = 'stroke';
    path.style.cursor = 'pointer';
    path.addEventListener('click', ev => {
      ev.stopPropagation();
      acceptSuggestedEdge(sug.id);
    });
    $canvasSvg.appendChild(path);

    // Small X button to dismiss, at midpoint
    const btn = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    btn.setAttribute('class', 'suggested-dismiss');
    btn.setAttribute('transform', `translate(${midX - 10}, ${midY - 10})`);
    btn.style.cursor = 'pointer';
    btn.style.pointerEvents = 'all';
    btn.innerHTML = `
      <circle r="9" cx="10" cy="10" fill="var(--bg)" stroke="var(--text-muted)" stroke-width="1" />
      <text x="10" y="14" text-anchor="middle" fill="var(--text-muted)" font-size="13" font-family="Inter" style="user-select:none;">\u00d7</text>
    `;
    btn.addEventListener('click', ev => {
      ev.stopPropagation();
      dismissSuggestedEdge(sug.id);
    });
    $canvasSvg.appendChild(btn);
  });
}

// ─── NODE INTERACTIONS ─────────────────────────────────────────────────
$canvasArea.addEventListener('mousedown', e => {
  const node = e.target.closest('.node');
  if (!node) {
    selectedNodeId = null;
    connectSourceId = null;
    renderCanvas();
    return;
  }
  // If clicked on input, let default behavior happen
  if (e.target.classList.contains('node-label')) return;
  // If clicked on action button, skip drag
  if (e.target.closest('.node-action-btn')) return;

  const id = node.dataset.nodeId;

  // Connect mode: first click = source, second = target
  if (connectMode) {
    if (!connectSourceId) {
      connectSourceId = id;
      renderCanvas();
    } else if (connectSourceId !== id) {
      addEdge(connectSourceId, id);
      connectSourceId = null;
      connectMode = false;
      document.getElementById('btn-connect-mode').classList.remove('active');
      renderCanvas();
    }
    return;
  }

  selectedNodeId = id;
  renderCanvas();

  // Start drag
  draggingNodeId = id;
  const nodeData = getNodeById(id);
  const canvasRect = $canvasArea.getBoundingClientRect();
  dragOffsetX = e.clientX - canvasRect.left - nodeData.x;
  dragOffsetY = e.clientY - canvasRect.top - nodeData.y;
  e.preventDefault();
});

document.addEventListener('mousemove', e => {
  if (!draggingNodeId) return;
  const canvasRect = $canvasArea.getBoundingClientRect();
  const x = e.clientX - canvasRect.left - dragOffsetX;
  const y = e.clientY - canvasRect.top - dragOffsetY;
  // Constrain
  const maxX = Math.max(8, $canvasArea.clientWidth - 200);
  const maxY = Math.max(48, $canvasArea.clientHeight - 80);
  const cx = Math.min(maxX, Math.max(8, x));
  const cy = Math.min(maxY, Math.max(56, y));
  const nodeData = getNodeById(draggingNodeId);
  if (nodeData) {
    nodeData.x = cx;
    nodeData.y = cy;
    // Mark as manually positioned — auto-layout won't move it
    nodeData.pinned = true;
    // Update DOM directly (perf)
    const el = $canvasArea.querySelector(`.node[data-node-id="${draggingNodeId}"]`);
    if (el) {
      el.style.left = cx + 'px';
      el.style.top = cy + 'px';
      el.classList.add('pinned');
    }
    updateEdges();
  }
});

document.addEventListener('mouseup', () => {
  if (draggingNodeId) {
    draggingNodeId = null;
    persist();
    renderReport(); // refresh in case layout/positions affect anything
  }
});

// Label editing
$canvasArea.addEventListener('input', e => {
  if (e.target.classList.contains('node-label')) {
    updateNodeLabel(e.target.dataset.nodeId, e.target.value);
  }
});
$canvasArea.addEventListener('click', e => {
  const actionBtn = e.target.closest('.node-action-btn');
  if (actionBtn) {
    e.stopPropagation();
    const id = actionBtn.dataset.nodeId;
    const action = actionBtn.dataset.action;
    if (action === 'delete') {
      deleteNode(id);
    } else if (action === 'connect') {
      connectMode = true;
      connectSourceId = id;
      document.getElementById('btn-connect-mode').classList.add('active');
      renderCanvas();
    }
    return;
  }

  // Risk badge click -> inline edit
  const riskBadge = e.target.closest('.risk-badge');
  if (riskBadge) {
    e.stopPropagation();
    const nodeId = riskBadge.dataset.nodeId;
    const n = getNodeById(nodeId);
    if (!n) return;
    const comp = componentById[n.componentId];
    const currentRisk = customRisk[nodeId] !== undefined ? customRisk[nodeId] : (Number(comp["Risk Score"]) || 0);
    const input = document.createElement('input');
    input.type = 'number';
    input.className = 'risk-input';
    input.min = '0';
    input.max = '10';
    input.value = currentRisk;
    riskBadge.replaceWith(input);
    input.focus();
    input.select();
    const commit = () => {
      const val = parseInt(input.value, 10);
      if (!isNaN(val) && val >= 0 && val <= 10) {
        const baseRisk = Number(comp["Risk Score"]) || 0;
        if (val === baseRisk) {
          delete customRisk[nodeId]; // reverted to default
        } else {
          customRisk[nodeId] = val;
        }
        persist();
      }
      renderCanvas();
      renderReport();
    };
    input.addEventListener('blur', commit);
    input.addEventListener('keydown', (evt) => {
      if (evt.key === 'Enter') { commit(); }
      else if (evt.key === 'Escape') { renderCanvas(); }
    });
    return;
  }
});

// ─── TOOLBAR BUTTONS ──────────────────────────────────────────────────
document.getElementById('btn-connect-mode').addEventListener('click', () => {
  connectMode = !connectMode;
  if (!connectMode) connectSourceId = null;
  document.getElementById('btn-connect-mode').classList.toggle('active', connectMode);
  renderCanvas();
});

document.getElementById('btn-clear-canvas').addEventListener('click', () => {
  if (state.nodes.length === 0) return;
  if (!confirm('Clear the entire canvas? This cannot be undone.')) return;
  state.nodes = [];
  state.edges = [];
  selectedNodeId = null;
  connectSourceId = null;
  connectMode = false;
  document.getElementById('btn-connect-mode').classList.remove('active');
  renderCanvas();
  renderReport();
  persist();
});

document.getElementById('btn-auto-layout').addEventListener('click', () => {
  if (state.nodes.length === 0) return;
  // Clear pins so re-layout truly re-flows everything
  state.nodes.forEach(n => { n.pinned = false; });
  autoLayout();
  suggestEdges();
});

// ─── DEFENSE-LAYER-AWARE AUTO-LAYOUT ────────────────────────────────────
// Groups nodes into left-to-right columns by Defense Layer.
// Nodes marked `pinned: true` are preserved in their current position (user-moved).
// Multi-layer components go in the left-most applicable layer.
const LAYER_ORDER = ['Identity', 'Network', 'OS / Compute', 'Application', 'Data', 'Detection'];

function layerOfComponent(comp) {
  // Use the component's declared primary layer (first in its Defense Layers list)
  // This respects the semantic ordering in the data — e.g. VMs are "OS / Compute; Network"
  // meaning OS/Compute is primary, Network is secondary.
  const layers = String(comp['Defense Layers'] || '').split(';').map(s => s.trim()).filter(Boolean);
  if (layers.length === 0) return 'Application';
  const primary = layers[0];
  // Ensure it's a valid layer; fall back if not
  return LAYER_ORDER.includes(primary) ? primary : 'Application';
}

function autoLayout() {
  // Group unpinned nodes by Defense Layer
  const byLayer = {};
  LAYER_ORDER.forEach(l => { byLayer[l] = []; });
  const pinnedNodes = [];
  state.nodes.forEach(n => {
    if (n.pinned) { pinnedNodes.push(n); return; }
    const c = componentById[n.componentId];
    if (!c) return;
    byLayer[layerOfComponent(c)].push(n);
  });

  // Keep only layers that have at least one node
  const presentLayers = LAYER_ORDER.filter(l => byLayer[l].length > 0);

  // Column geometry
  const COL_WIDTH = 260;
  const COL_GAP = 40;
  const START_X = 40;
  const START_Y = 100;
  const NODE_H = 100;
  const NODE_GAP = 10;

  presentLayers.forEach((layer, idx) => {
    const colX = START_X + idx * (COL_WIDTH + COL_GAP);
    byLayer[layer].forEach((n, i) => {
      n.x = colX;
      n.y = START_Y + i * (NODE_H + NODE_GAP);
    });
  });

  renderCanvas();
  persist();
}

// ─── SUGGESTED EDGES ────────────────────────────────────────────────────
// Draw dotted grey edges between adjacent-layer nodes showing a likely flow.
// User clicks to accept (becomes solid) or dismiss (X button).
// Stored in state.suggestedEdges, separate from state.edges (accepted ones).
state.suggestedEdges = state.suggestedEdges || [];

function suggestEdges() {
  // Clear existing suggestions (don't touch user-accepted edges)
  state.suggestedEdges = [];

  // For each pair of adjacent populated layers, suggest edges from nodes in left layer
  // to nodes in right layer. Keep it minimal: 1-2 suggestions per left-layer node.
  const byLayer = {};
  LAYER_ORDER.forEach(l => { byLayer[l] = []; });
  state.nodes.forEach(n => {
    const c = componentById[n.componentId];
    if (c) byLayer[layerOfComponent(c)].push(n);
  });
  const presentLayers = LAYER_ORDER.filter(l => byLayer[l].length > 0);

  let sugId = 1;
  for (let i = 0; i < presentLayers.length - 1; i++) {
    const leftLayer = presentLayers[i];
    const rightLayer = presentLayers[i + 1];
    const leftNodes = byLayer[leftLayer];
    const rightNodes = byLayer[rightLayer];

    leftNodes.forEach(ln => {
      // Connect to the node in the right layer at the most similar vertical position
      if (rightNodes.length === 0) return;
      let best = rightNodes[0];
      let bestDist = Math.abs(ln.y - best.y);
      rightNodes.forEach(rn => {
        const d = Math.abs(ln.y - rn.y);
        if (d < bestDist) { bestDist = d; best = rn; }
      });

      // Only suggest if not already an accepted edge
      const already = state.edges.some(e =>
        (e.sourceId === ln.id && e.targetId === best.id) ||
        (e.sourceId === best.id && e.targetId === ln.id)
      );
      if (!already) {
        state.suggestedEdges.push({
          id: 'sug-' + (sugId++),
          sourceId: ln.id,
          targetId: best.id,
        });
      }
    });
  }
  renderCanvas();
  persist();
}

function acceptSuggestedEdge(sugId) {
  const sug = state.suggestedEdges.find(s => s.id === sugId);
  if (!sug) return;
  state.edges.push({
    id: 'e' + (nextEdgeId++),
    sourceId: sug.sourceId,
    targetId: sug.targetId,
  });
  state.suggestedEdges = state.suggestedEdges.filter(s => s.id !== sugId);
  renderCanvas();
  persist();
}

function dismissSuggestedEdge(sugId) {
  state.suggestedEdges = state.suggestedEdges.filter(s => s.id !== sugId);
  renderCanvas();
  persist();
}

// ─── PERSISTENCE ──────────────────────────────────────────────────────
const STORAGE_KEY = 'csa_canvas_v10';

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      nodes: state.nodes, edges: state.edges,
      suggestedEdges: state.suggestedEdges || [],
      nextNodeId, nextEdgeId,
      customRisk, viewMode,
      collapsedSections: Array.from(collapsedSections),
      metadata, pdfOptions, customExecSummary,
    }));
  } catch (e) {
    // localStorage unavailable — silently ignore
  }
}

function restore() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed.nodes)) state.nodes = parsed.nodes;
    if (Array.isArray(parsed.edges)) state.edges = parsed.edges;
    if (Array.isArray(parsed.suggestedEdges)) state.suggestedEdges = parsed.suggestedEdges;
    if (parsed.nextNodeId) nextNodeId = parsed.nextNodeId;
    if (parsed.nextEdgeId) nextEdgeId = parsed.nextEdgeId;
    if (parsed.customRisk) Object.assign(customRisk, parsed.customRisk);
    if (parsed.viewMode) viewMode = parsed.viewMode;
    if (Array.isArray(parsed.collapsedSections)) {
      parsed.collapsedSections.forEach(s => collapsedSections.add(s));
    }
    if (parsed.metadata) Object.assign(metadata, parsed.metadata);
    if (parsed.pdfOptions) Object.assign(pdfOptions, parsed.pdfOptions);
    if (parsed.customExecSummary !== undefined) customExecSummary = parsed.customExecSummary;
  } catch (e) {
    state.nodes = []; state.edges = [];
  }
}

// ─── PALETTE WIRING ──────────────────────────────────────────────────
$paletteSearch.addEventListener('input', e => {
  paletteSearch = e.target.value;
  renderPalette();
});
document.querySelectorAll('.palette-filter').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.palette-filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    paletteFilter = btn.dataset.filter;
    renderPalette();
  });
});

// ─── QUICK PICKS ──────────────────────────────────────────────────────
const QUICK_PICKS = [
  ["AWS Startup", [["AWS", "EC2"], ["AWS", "S3"], ["AWS", "IAM"], ["AWS", "RDS"], ["AWS", "VPC"], ["AWS", "CloudTrail"], ["AWS", "KMS"]]],
  ["Azure Enterprise", [["Azure", "Virtual Machines"], ["Azure", "Azure SQL"], ["Azure", "Azure Active Directory"], ["Azure", "Azure Key Vault"], ["Azure", "Blob Storage"], ["Azure", "Microsoft Sentinel"], ["Azure", "Virtual Network (VNet)"]]],
  ["GCP Data Platform", [["GCP", "GKE"], ["GCP", "BigQuery"], ["GCP", "Cloud Storage"], ["GCP", "Cloud IAM"], ["GCP", "Cloud KMS"], ["GCP", "VPC"]]],
  ["Multi-cloud", [["AWS", "EC2"], ["AWS", "S3"], ["Azure", "Virtual Machines"], ["Azure", "Blob Storage"], ["GCP", "Compute Engine"], ["GCP", "Cloud Storage"]]],
];
function findCompByName(prov, name) {
  const c = DATA.components.find(c => c["Cloud Provider"] === prov && c["Component Name"] === name);
  return c ? c.ComponentID : null;
}

$quickPicks.innerHTML = '<span class="quick-picks-label">Quick start:</span>' +
  QUICK_PICKS.map(([label]) => `<button class="quick-pick" data-label="${escapeHtml(label)}">${escapeHtml(label)} &rarr;</button>`).join('');
$quickPicks.addEventListener('click', e => {
  if (!e.target.classList.contains('quick-pick')) return;
  const label = e.target.dataset.label;
  const qp = QUICK_PICKS.find(q => q[0] === label);
  if (!qp) return;
  // Add each component as a node
  qp[1].forEach((pair, i) => {
    const cid = findCompByName(pair[0], pair[1]);
    if (cid) addNode(cid, 40 + (i % 4) * 240, 80 + Math.floor(i / 4) * 100);
  });
  autoLayout();
});

// ─── PRINT / CLEAR ───────────────────────────────────────────────────
document.getElementById('btn-print').addEventListener('click', () => window.print());
document.getElementById('btn-clear').addEventListener('click', () => {
  if (confirm('Clear canvas?')) {
    state.nodes = []; state.edges = [];
    selectedNodeId = null; connectSourceId = null; connectMode = false;
    renderCanvas(); renderReport(); persist();
  }
});

// ═══════════════════════════════════════════════════════════════════════
// REPORT RENDERING (derived from unique components on canvas)
// ═══════════════════════════════════════════════════════════════════════

// Chart helpers (unchanged from v3)
function donut(segments) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  if (total === 0) return '<div style="color:var(--text-muted);font-size:12px;padding:20px;text-align:center;">No data</div>';
  const size = 180, cx = size / 2, cy = size / 2, r = 70, innerR = 44;
  let startAngle = -Math.PI / 2;
  const paths = [];
  segments.forEach(seg => {
    if (seg.value === 0) return;
    const angle = (seg.value / total) * Math.PI * 2;
    const endAngle = startAngle + angle;
    const x1 = cx + Math.cos(startAngle) * r;
    const y1 = cy + Math.sin(startAngle) * r;
    const x2 = cx + Math.cos(endAngle) * r;
    const y2 = cy + Math.sin(endAngle) * r;
    const x3 = cx + Math.cos(endAngle) * innerR;
    const y3 = cy + Math.sin(endAngle) * innerR;
    const x4 = cx + Math.cos(startAngle) * innerR;
    const y4 = cy + Math.sin(startAngle) * innerR;
    const largeArc = angle > Math.PI ? 1 : 0;
    paths.push(`<path d="M ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} L ${x3} ${y3} A ${innerR} ${innerR} 0 ${largeArc} 0 ${x4} ${y4} Z" fill="${seg.color}" stroke="var(--bg-elevated)" stroke-width="1.5"/>`);
    startAngle = endAngle;
  });
  const legend = segments.filter(s => s.value > 0).map(s =>
    `<div class="legend-item"><div class="legend-swatch" style="background:${s.color}"></div>${escapeHtml(s.label)} <span style="color:var(--text-muted);font-family:var(--mono);margin-left:4px;">${s.value}</span></div>`
  ).join("");
  return `<div style="display:flex;gap:24px;align-items:center;flex-wrap:wrap;">
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      ${paths.join("")}
      <text x="${cx}" y="${cy - 2}" text-anchor="middle" dominant-baseline="central" style="font-family:var(--display);font-size:26px;font-weight:600;fill:var(--text-primary);">${total}</text>
      <text x="${cx}" y="${cy + 18}" text-anchor="middle" dominant-baseline="central" style="font-family:var(--mono);font-size:9px;fill:var(--text-muted);letter-spacing:0.1em;">TOTAL</text>
    </svg>
    <div class="chart-legend" style="flex-direction:column;gap:6px;margin-top:0;">${legend}</div>
  </div>`;
}

function hBarChart(items) {
  if (items.length === 0) return '<div style="color:var(--text-muted);font-size:12px;padding:20px;text-align:center;">No data</div>';
  const max = Math.max(...items.map(i => i.value));
  return `<div style="display:flex;flex-direction:column;gap:8px;">` +
    items.map(i => {
      const pct = (i.value / max * 100).toFixed(1);
      return `<div>
        <div style="display:flex;justify-content:space-between;margin-bottom:3px;font-size:11px;">
          <span>${escapeHtml(i.label)}</span>
          <span style="color:var(--text-muted);font-family:var(--mono);">${i.value}</span>
        </div>
        <div style="height:6px;background:var(--bg-raised);border-radius:1px;overflow:hidden;">
          <div style="height:100%;width:${pct}%;background:var(--accent);"></div>
        </div>
      </div>`;
    }).join("") + `</div>`;
}

function stackedBar(data) {
  if (data.length === 0) return '<div style="color:var(--text-muted);font-size:12px;padding:20px;text-align:center;">No data</div>';
  const max = Math.max(...data.map(d => d.segments.reduce((s, x) => s + x.value, 0)));
  return `<div style="display:flex;flex-direction:column;gap:10px;">` +
    data.map(d => {
      const total = d.segments.reduce((s, x) => s + x.value, 0);
      return `<div>
        <div style="display:flex;justify-content:space-between;margin-bottom:4px;font-size:11px;">
          <span>${escapeHtml(d.label)}</span>
          <span style="color:var(--text-muted);font-family:var(--mono);">${total}</span>
        </div>
        <div style="height:10px;background:var(--bg-raised);border-radius:1px;display:flex;overflow:hidden;">
          ${d.segments.map(s => s.value > 0 ? `<div style="height:100%;width:${(s.value / max * 100).toFixed(2)}%;background:${s.color};" title="${escapeHtml(s.key)}: ${s.value}"></div>` : '').join("")}
        </div>
      </div>`;
    }).join("") + `</div>`;
}

function pie(segments) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  if (total === 0) return '<div style="color:var(--text-muted);font-size:12px;padding:20px;text-align:center;">No data</div>';
  const size = 160, cx = size / 2, cy = size / 2, r = 70;
  let startAngle = -Math.PI / 2;
  const paths = [];
  segments.forEach(seg => {
    if (seg.value === 0) return;
    const angle = (seg.value / total) * Math.PI * 2;
    const endAngle = startAngle + angle;
    const x1 = cx + Math.cos(startAngle) * r;
    const y1 = cy + Math.sin(startAngle) * r;
    const x2 = cx + Math.cos(endAngle) * r;
    const y2 = cy + Math.sin(endAngle) * r;
    const largeArc = angle > Math.PI ? 1 : 0;
    paths.push(`<path d="M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z" fill="${seg.color}" stroke="var(--bg-elevated)" stroke-width="1.5"/>`);
    startAngle = endAngle;
  });
  const legend = segments.filter(s => s.value > 0).map(s =>
    `<div class="legend-item"><div class="legend-swatch" style="background:${s.color}"></div>${escapeHtml(s.label)} <span style="color:var(--text-muted);font-family:var(--mono);margin-left:4px;">${s.value}</span></div>`
  ).join("");
  return `<div style="display:flex;gap:24px;align-items:center;flex-wrap:wrap;">
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${paths.join("")}</svg>
    <div class="chart-legend" style="flex-direction:column;gap:6px;margin-top:0;">${legend}</div>
  </div>`;
}

function heatmap(items) {
  if (items.length === 0) return '<div style="color:var(--text-muted);font-size:12px;padding:20px;text-align:center;">No data</div>';
  const max = Math.max(...items.map(i => i.count));
  return `<div class="heatmap-grid">` +
    items.map(i => {
      const intensity = i.count / max;
      const bg = `rgba(244, 162, 97, ${0.08 + intensity * 0.35})`;
      const border = `rgba(244, 162, 97, ${0.2 + intensity * 0.4})`;
      return `<div class="heatmap-cell" style="background:${bg};border:1px solid ${border};">
        <span class="name">${escapeHtml(i.name)}</span>
        <span class="count">${i.count}</span>
      </div>`;
    }).join("") + `</div>`;
}

function killchainHTML(scenarioId) {
  const steps = DATA.scenario_techniques.filter(st => st.ScenarioID === scenarioId)
    .sort((a, b) => (a["Step Order"] || 0) - (b["Step Order"] || 0));
  if (steps.length === 0) return "";
  return `<div class="killchain">` +
    steps.map((st, i) => {
      const tech = DATA.mitre_attack.find(t => t.TechniqueID === st.TechniqueID);
      return `<div class="killchain-step">
        <div class="num">STEP ${i + 1}</div>
        <div style="font-weight:500;color:var(--text-primary);">${escapeHtml(tech ? tech["Technique Name"] : "Unknown")}</div>
        <div class="tid">${escapeHtml(st["MITRE ID"])}</div>
      </div>`;
    }).join("") + `</div>`;
}

function detailBlock(title, content) {
  if (!content || content === "\u2014") return "";
  return `<div class="detail-block"><h5>${escapeHtml(title)}</h5><div class="content">${escapeHtml(content)}</div></div>`;
}

function detailBlockWithConfidence(title, content, confidence) {
  if (!content || content === "\u2014") return "";
  const badge = confidence
    ? `<span class="confidence-badge confidence-${confidence.toLowerCase()}" title="My confidence in this content. High = stable, well-documented IAM patterns. Medium = correct in principle but verify specifics. Low = newer/specialized service, higher chance of staleness.">${escapeHtml(confidence)}</span>`
    : '';
  return `<div class="detail-block"><h5>${escapeHtml(title)} ${badge}</h5><div class="content">${escapeHtml(content)}</div></div>`;
}

function formatDate(iso) {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  } catch (e) {
    return iso;
  }
}

function generateExecSummary(comps, effectiveRiskByComp, filtered, breaches, actors) {
  if (customExecSummary !== null && customExecSummary !== undefined) {
    return customExecSummary;
  }
  if (comps.length === 0) return '';

  // Risk tier breakdown
  const critical = comps.filter(c => (effectiveRiskByComp[c.ComponentID] || 0) >= 9);
  const high = comps.filter(c => {
    const r = effectiveRiskByComp[c.ComponentID] || 0;
    return r >= 7 && r < 9;
  });
  const avgRisk = (comps.reduce((s, c) => s + (effectiveRiskByComp[c.ComponentID] || 0), 0) / comps.length).toFixed(1);
  const criticalDetections = filtered.detections.filter(d => d.Severity === 'Critical').length;
  const highDetections = filtered.detections.filter(d => d.Severity === 'High').length;
  const uniqueTools = new Set(filtered.defense_tools.map(t => t["Tool Name"])).size;

  // Top 3 components by effective risk for headline
  const topRisk = [...comps].sort((a, b) =>
    (effectiveRiskByComp[b.ComponentID] || 0) - (effectiveRiskByComp[a.ComponentID] || 0)
  ).slice(0, 3);

  // Clouds in scope
  const cloudsPresent = [...new Set(comps.map(c => c["Cloud Provider"]))].sort();

  const lines = [];
  lines.push(`Scope: ${comps.length} cloud components analyzed across ${cloudsPresent.join(', ')}. Overall weighted risk of ${avgRisk}/10.`);
  lines.push('');

  if (critical.length > 0) {
    lines.push(`Critical-risk components identified: ${critical.map(c => c["Component Name"]).join(', ')}. These require priority attention as their compromise would have tenant-wide or account-wide blast radius.`);
    lines.push('');
  }

  lines.push(`Headline recommendations:`);
  topRisk.forEach((c, i) => {
    const risk = effectiveRiskByComp[c.ComponentID] || 0;
    const oneLiner = c["Executive One-Liner"] || `Review ${c["Component Name"]} security posture.`;
    lines.push(`${i + 1}. ${c["Component Name"]} (Risk ${risk}/10): ${oneLiner}`);
  });
  lines.push('');

  lines.push(`Detection coverage: ${criticalDetections} critical-severity and ${highDetections} high-severity detection rules should be deployed to the customer's SIEM. ${uniqueTools} distinct defense tools are recommended across the environment (mix of cloud-native, third-party, and OSS).`);

  if (breaches.length > 0) {
    lines.push('');
    lines.push(`Relevant real-world incidents for context: ${breaches.slice(0, 3).map(b => `${b.Victim} (${b.Year})`).join(', ')}. These breaches involved components present in this architecture and should inform prioritization.`);
  }

  if (actors.length > 0) {
    const actorNames = actors.slice(0, 5).map(a => a.Name).join(', ');
    lines.push('');
    lines.push(`Threat actors known to target this stack: ${actorNames}${actors.length > 5 ? `, and ${actors.length - 5} others` : ''}.`);
  }

  lines.push('');
  lines.push(`Next steps: Review the per-component advisory section for specific misconfigurations to check, questions to ask the customer, and recommended tooling. Detection queries in the appendix are ready to deploy to the SIEM platform of choice.`);

  return lines.join('\n');
}

function renderCoverPage(comps) {
  return `<div class="pdf-cover">
    <div class="pdf-cover-top">
      <div class="pdf-cover-eyebrow">Cloud Security Advisory</div>
      <h1>${escapeHtml(metadata.reportTitle)}</h1>
      <div class="pdf-cover-customer">${escapeHtml(metadata.customer)}</div>
      <div class="pdf-cover-subtitle">Per-architecture security analysis across ${comps.length} cloud components. Risk assessment, detection engineering, threat actor context, and prioritized recommendations.</div>
      <div class="pdf-cover-meta">
        <div>
          <div class="label">Prepared by</div>
          <div class="value">${escapeHtml(metadata.advisor)}</div>
        </div>
        <div>
          <div class="label">Date</div>
          <div class="value">${escapeHtml(formatDate(metadata.engagementDate))}</div>
        </div>
        <div>
          <div class="label">Components in Scope</div>
          <div class="value">${comps.length} unique component types</div>
        </div>
        <div>
          <div class="label">Canvas Instances</div>
          <div class="value">${state.nodes.length} nodes designed</div>
        </div>
      </div>
    </div>
    <div class="pdf-cover-bottom">
      <div class="pdf-cover-disclaimer">
        <strong>Advisory Disclaimer</strong>
        This document provides security recommendations based on generally accepted cloud security practices, public vendor documentation, and the MITRE ATT&amp;CK framework. Content is advisory only and does not constitute a formal security audit, penetration test, or compliance attestation. Recommendations should be validated against primary sources (CIS Benchmarks, vendor documentation, regulatory requirements specific to your industry) before implementation. The preparer makes no warranty as to completeness or fitness for any particular purpose. Pricing and configuration details are approximate and current as of the report date; verify with the respective vendors for current terms.
      </div>
    </div>
  </div>`;
}

function renderToC(sectionList) {
  return `<div class="pdf-toc">
    <h2>Table of Contents</h2>
    <ul class="pdf-toc-list">
      ${sectionList.map(s => `
        <li class="pdf-toc-item">
          <span class="toc-tier">${escapeHtml(s.tier)}</span>
          <span class="toc-title">${escapeHtml(s.title)}</span>
          <span class="toc-meta">${escapeHtml(s.meta || '')}</span>
        </li>
      `).join('')}
    </ul>
  </div>`;
}

function renderReport() {
  // Sync view mode to body
  document.body.setAttribute('data-view-mode', viewMode);

  // Report works on UNIQUE component types on canvas
  const uniqueIds = [...new Set(state.nodes.map(n => n.componentId))];

  if (uniqueIds.length === 0) {
    $report.innerHTML = `<div class="empty-state">
      <h2>Canvas is empty</h2>
      <p>Drag components from the palette onto the canvas to start designing an architecture and generating a personalized report.</p>
    </div>`;
    return;
  }

  const comps = uniqueIds.map(id => componentById[id]).filter(Boolean);

  // Effective risk per component = max of any node instance's override or base
  const effectiveRiskByComp = {};
  comps.forEach(c => { effectiveRiskByComp[c.ComponentID] = Number(c["Risk Score"]) || 0; });
  state.nodes.forEach(n => {
    if (customRisk[n.id] !== undefined) {
      // Use max of overrides for this component type
      effectiveRiskByComp[n.componentId] = Math.max(effectiveRiskByComp[n.componentId] || 0, customRisk[n.id]);
    }
  });

  // Per-component node labels map
  const labelsByComp = {};
  state.nodes.forEach(n => {
    if (!labelsByComp[n.componentId]) labelsByComp[n.componentId] = [];
    labelsByComp[n.componentId].push(n.label);
  });

  const filtered = {
    defense_tools: DATA.defense_tools.filter(r => uniqueIds.includes(r.ComponentID)),
    log_events: DATA.log_events.filter(r => uniqueIds.includes(r.ComponentID)),
    detections: DATA.detections.filter(r => uniqueIds.includes(r.ComponentID)),
    component_mitre: DATA.component_mitre.filter(r => uniqueIds.includes(r.ComponentID)),
    component_stride: DATA.component_stride.filter(r => uniqueIds.includes(r.ComponentID)),
    attack_scenarios: DATA.attack_scenarios.filter(r => uniqueIds.includes(r.ComponentID)),
  };
  const scenarioIds = new Set(filtered.attack_scenarios.map(s => s.ScenarioID));
  const actor_scenarios = DATA.actor_scenarios.filter(as => scenarioIds.has(as.ScenarioID));
  const actorIds = new Set(actor_scenarios.map(as => as.ActorID));
  const actors = DATA.threat_actors.filter(a => actorIds.has(a.ActorID));
  const breach_components = DATA.breach_components.filter(bc => uniqueIds.includes(bc.ComponentID));
  const breachIds = new Set(breach_components.map(bc => bc.BreachID));
  const breaches = DATA.public_breaches.filter(b => breachIds.has(b.BreachID));
  const detectionIds = new Set(filtered.detections.map(d => d.DetectionID));
  const det_playbook = DATA.detection_playbook.filter(dp => detectionIds.has(dp.DetectionID));
  const playbookIds = new Set(det_playbook.map(dp => dp.PlaybookID));
  const playbooks = DATA.remediation_playbooks.filter(pb => playbookIds.has(pb.PlaybookID));
  const techIds = new Set(filtered.component_mitre.map(cm => cm.TechniqueID));
  const techniques = DATA.mitre_attack.filter(t => techIds.has(t.TechniqueID));

  // Use effective risk for avg
  const avgRisk = (comps.reduce((s, c) => s + (effectiveRiskByComp[c.ComponentID] || 0), 0) / comps.length).toFixed(1);
  const criticalDetections = filtered.detections.filter(d => d.Severity === "Critical").length;
  const highDetections = filtered.detections.filter(d => d.Severity === "High").length;

  // Identify tools on the canvas that have enrichment data
  const toolNamesOnCanvas = new Set();
  filtered.defense_tools.forEach(t => { if (t["Tool Name"]) toolNamesOnCanvas.add(t["Tool Name"].toLowerCase()); });
  const relevantTools = (typeof TOOL_ENRICHMENT !== 'undefined' ? TOOL_ENRICHMENT : []).filter(tool => {
    const tn = tool.Tool.toLowerCase();
    // Match by substring either direction
    for (const name of toolNamesOnCanvas) {
      if (tn.includes(name) || name.includes(tn.split(' ')[0])) return true;
    }
    return false;
  });

  // Track sections for ToC
  const sectionList = [];

  let html = "";

  // PDF cover page (hidden on screen, shown in print)
  html += renderCoverPage(comps);

  // View mode selector (on-screen only — hidden in print)
  html += `<div class="view-mode-bar">
    <span class="label">Report Depth</span>
    <button class="view-mode-btn ${viewMode === 'executive' ? 'active' : ''}" data-mode="executive">Executive</button>
    <button class="view-mode-btn ${viewMode === 'standard' ? 'active' : ''}" data-mode="standard">Standard</button>
    <button class="view-mode-btn ${viewMode === 'deep' ? 'active' : ''}" data-mode="deep">Deep Dive</button>
    <span class="spacer"></span>
    <span class="helper">Click any section header to collapse/expand. Risk scores editable on canvas.</span>
  </div>`;

  // Executive summary (always shown on screen + in print)
  const execSummaryText = generateExecSummary(comps, effectiveRiskByComp, filtered, breaches, actors);
  html += `<div class="exec-summary">
    <h2>Executive Summary</h2>
    <div class="exec-summary-body" contenteditable="true" id="exec-summary-body">${escapeHtml(execSummaryText)}</div>
    <div class="regen-bar">
      <span class="hint">Tap to edit. Changes persist. Click "Regenerate" to restore auto-generated content.</span>
      <button class="regen" id="btn-regen-summary">Regenerate</button>
    </div>
  </div>`;

  html += `<div class="kpi-strip">
    <div class="kpi"><div class="label">Components</div><div class="value">${comps.length}</div><div class="sub">${state.nodes.length} instances on canvas</div></div>
    <div class="kpi"><div class="label">Avg Risk</div><div class="value">${avgRisk}</div><div class="sub">0-10, editable per-node</div></div>
    <div class="kpi crit"><div class="label">Critical Detections</div><div class="value">${criticalDetections}</div><div class="sub">to deploy</div></div>
    <div class="kpi high"><div class="label">High Severity</div><div class="value">${highDetections}</div><div class="sub">detections</div></div>
    <div class="kpi"><div class="label">Defense Tools</div><div class="value">${new Set(filtered.defense_tools.map(t => t["Tool Name"])).size}</div><div class="sub">recommended</div></div>
    <div class="kpi"><div class="label">Playbooks</div><div class="value">${playbooks.length}</div><div class="sub">available</div></div>
    <div class="kpi"><div class="label">MITRE Techniques</div><div class="value">${techniques.length}</div><div class="sub">applicable</div></div>
    <div class="kpi"><div class="label">Threat Actors</div><div class="value">${actors.length}</div><div class="sub">relevant</div></div>
  </div>`;

  html += `<div class="report-grid">`;

  // Helper: render section header with collapse toggle
  const sectionHeader = (id, title, meta, countText) => {
    const isCollapsed = collapsedSections.has(id);
    return `<div class="section-header" data-section-id="${id}">
      <h3><span class="collapse-indicator">${isCollapsed ? '&#x25B6;' : '&#x25BC;'}</span>${title} ${meta ? `<span>${meta}</span>` : ''}</h3>
      ${countText ? `<div class="count">${countText}</div>` : ''}
    </div>`;
  };
  const wrapSection = (id, tier, title, meta, countText, body) => {
    const isCollapsed = collapsedSections.has(id);
    sectionList.push({ id, tier, title, meta, countText });
    return `<div class="section ${isCollapsed ? 'collapsed' : ''}" data-section-id="${id}" data-tier="${tier}">
      ${sectionHeader(id, title, meta, countText)}
      <div class="section-body">${body}</div>
    </div>`;
  };

  // ═══ Defense-in-depth layers (STANDARD tier) ═══
  const layerGroups = {};
  LAYERS.forEach(l => { layerGroups[l.key] = []; });
  comps.forEach(c => {
    const layers = String(c["Defense Layers"] || '').split(';').map(s => s.trim()).filter(Boolean);
    layers.forEach(l => {
      if (layerGroups[l]) layerGroups[l].push(c);
    });
  });
  const layersBody = LAYERS.filter(l => layerGroups[l.key].length > 0).map(l => {
    const compsInLayer = layerGroups[l.key];
    const avgLayerRisk = (compsInLayer.reduce((s, c) => s + (effectiveRiskByComp[c.ComponentID] || 0), 0) / compsInLayer.length).toFixed(1);
    return `<div class="layer-group">
      <div class="layer-group-header">
        <span class="layer-tag ${l.className}">${escapeHtml(l.key)}</span>
        <span class="layer-name">${escapeHtml(l.key)}</span>
        <span class="layer-count">${compsInLayer.length} components &middot; avg risk ${avgLayerRisk}</span>
      </div>
      <div class="components-in-layer">
        ${compsInLayer.map(c => `<span class="comp-chip">${iconHTML(c, "icon-16")}${escapeHtml(c["Component Name"])}</span>`).join('')}
      </div>
      <div class="layer-summary">${escapeHtml(l.desc)}</div>
    </div>`;
  }).join('');
  html += wrapSection('layers', 'standard', 'Defense-in-Depth Layers', '/ components grouped by security layer', `${LAYERS.filter(l => layerGroups[l.key].length > 0).length} active layers`, layersBody);

  // ═══ Charts (STANDARD) ═══
  const sevCounts = { Critical: 0, High: 0, Medium: 0, Low: 0 };
  filtered.detections.forEach(d => { if (sevCounts[d.Severity] !== undefined) sevCounts[d.Severity]++; });
  const severitySegs = [
    { label: "Critical", value: sevCounts.Critical, color: "#EF4444" },
    { label: "High", value: sevCounts.High, color: "#F59E0B" },
    { label: "Medium", value: sevCounts.Medium, color: "#60A5FA" },
    { label: "Low", value: sevCounts.Low, color: "#9CA3AF" },
  ];
  const riskByCat = {};
  comps.forEach(c => {
    const cat = c["Category"] || "Other";
    if (!riskByCat[cat]) riskByCat[cat] = { total: 0, count: 0 };
    riskByCat[cat].total += (effectiveRiskByComp[c.ComponentID] || 0);
    riskByCat[cat].count += 1;
  });
  const riskByCatItems = Object.entries(riskByCat)
    .map(([cat, v]) => ({ label: cat, value: Number((v.total / v.count).toFixed(1)) }))
    .sort((a, b) => b.value - a.value);
  const providerCounts = { AWS: 0, Azure: 0, GCP: 0 };
  comps.forEach(c => { providerCounts[c["Cloud Provider"]] = (providerCounts[c["Cloud Provider"]] || 0) + 1; });
  const providerSegs = [
    { label: "AWS", value: providerCounts.AWS, color: "#FF9900" },
    { label: "Azure", value: providerCounts.Azure, color: "#00A4EF" },
    { label: "GCP", value: providerCounts.GCP, color: "#4285F4" },
  ];
  const tacticCounts = {};
  techniques.forEach(t => {
    const tactic = t["Tactic"] || "Unknown";
    tacticCounts[tactic] = (tacticCounts[tactic] || 0) + 1;
  });
  const tacticItems = Object.entries(tacticCounts).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
  const toolsByCompType = {};
  filtered.defense_tools.forEach(t => {
    const comp = t["Component Name"];
    if (!toolsByCompType[comp]) toolsByCompType[comp] = { Native: 0, "Third-Party": 0, OSS: 0 };
    const type = t["Tool Type"] || "Third-Party";
    toolsByCompType[comp][type] = (toolsByCompType[comp][type] || 0) + 1;
  });
  const stackedData = Object.entries(toolsByCompType).map(([label, v]) => ({
    label, segments: [
      { key: "Native", value: v.Native, color: "#10B981" },
      { key: "Third-Party", value: v["Third-Party"], color: "#F4A261" },
      { key: "OSS", value: v.OSS, color: "#60A5FA" },
    ]
  })).sort((a, b) => b.segments.reduce((s, x) => s + x.value, 0) - a.segments.reduce((s, x) => s + x.value, 0)).slice(0, 10);

  const chartsBody = `<div class="charts-grid">
    <div class="chart-box span-6"><h4>Detection Severity</h4><div class="chart-subtitle">By severity level</div>${donut(severitySegs)}</div>
    <div class="chart-box span-6"><h4>Cloud Provider Split</h4><div class="chart-subtitle">Component distribution</div>${pie(providerSegs)}</div>
    <div class="chart-box span-6"><h4>Avg Risk by Category</h4><div class="chart-subtitle">Highest risk categories</div>${hBarChart(riskByCatItems)}</div>
    <div class="chart-box span-6"><h4>MITRE Tactic Coverage</h4><div class="chart-subtitle">Exposed ATT&amp;CK tactics</div>${heatmap(tacticItems)}</div>
    <div class="chart-box span-12"><h4>Defense Tools by Component</h4><div class="chart-subtitle">Native / Third-Party / OSS (top 10)</div>${stackedBar(stackedData)}
      <div class="chart-legend">
        <div class="legend-item"><div class="legend-swatch" style="background:#10B981"></div>Native</div>
        <div class="legend-item"><div class="legend-swatch" style="background:#F4A261"></div>Third-Party</div>
        <div class="legend-item"><div class="legend-swatch" style="background:#60A5FA"></div>OSS</div>
      </div>
    </div>
  </div>`;
  html += wrapSection('charts', 'standard', 'Visual Summary', '/ at-a-glance charts', '6 views', chartsBody);

  // Per-component advisory (STANDARD + EXECUTIVE has abbreviated)
  let advisoryBody = '';
  comps.forEach(c => {
    const labels = labelsByComp[c.ComponentID] || [];
    const instanceNote = labels.length > 1
      ? `<div class="instance-list"><strong>On canvas:</strong> ${labels.length} instances &mdash; ${labels.map(l => escapeHtml(l)).join(', ')}</div>`
      : (labels.length === 1 && labels[0] !== c["Component Name"] ? `<div class="instance-list"><strong>Labeled as:</strong> ${escapeHtml(labels[0])}</div>` : '');
    const effRisk = effectiveRiskByComp[c.ComponentID] || 0;
    const baseRisk = Number(c["Risk Score"]) || 0;
    const riskAnnotation = effRisk !== baseRisk ? ` <span style="color:var(--accent);">(customized from ${baseRisk})</span>` : '';
    const layers = String(c["Defense Layers"] || '').split(';').map(s => s.trim()).filter(Boolean);
    const layerTags = layers.map(l => {
      const layerDef = LAYERS.find(ll => ll.key === l);
      return layerDef ? `<span class="layer-tag ${layerDef.className}">${escapeHtml(l)}</span>` : '';
    }).join('');
    advisoryBody += `<div class="component-card">
      <div class="component-title-row">
        ${iconHTML(c, "icon-32")}
        <h4>${escapeHtml(c["Component Name"])}</h4>
      </div>
      <div class="meta">
        <span class="provider-badge ${c['Cloud Provider']}">${c['Cloud Provider']}</span>
        <span>${escapeHtml(c["Category"])}</span> &middot;
        <span>Risk ${effRisk}/10${riskAnnotation}</span>
      </div>
      ${layers.length ? `<div style="margin-bottom:12px;">${layerTags}</div>` : ''}
      ${instanceNote}
      ${c["Executive One-Liner"] ? `<div class="exec-line">${escapeHtml(c["Executive One-Liner"])}</div>` : ''}
      <div class="detail-grid">
        ${detailBlock("Top 3 misconfigurations you'll find", c["Top 3 Misconfigurations Customers Have"])}
        ${detailBlock("Ask these 5 questions", c["First 5 Questions to Ask Customer"])}
        ${detailBlock("Check these 5 things in their console", c["First 5 Things to Check in Console"])}
        ${detailBlock("When they push back", c["Customer Pushback & Response"])}
        ${detailBlock("Monthly cost to secure", c["Monthly Cost Estimate to Secure"])}
        ${detailBlock("Real breach example", c["Real Breach Example"])}
        ${detailBlock("Compensating controls", c["Compensating Controls If Primary Unavailable"])}
        ${detailBlock("Recommended best practices", c["Recommended Best Practices"])}
        ${detailBlockWithConfidence("Least privilege implementation", c["Least Privilege Implementation"], c["Least Privilege Confidence"])}
      </div>
    </div>`;
  });
  html += wrapSection('advisory', 'standard', 'Per-component Advisory', '/ what to tell the customer', `${comps.length} components`, advisoryBody);

  // ═══ Tool enrichment (STANDARD) - only if relevant tools on canvas ═══
  if (relevantTools.length > 0) {
    const toolsBody = relevantTools.map(tool => `<div class="tool-enrichment-card">
      <div class="tool-header">
        <h4>${escapeHtml(tool.Tool)}</h4>
        <span class="tool-vendor">${escapeHtml(tool.Vendor)} &middot; ${escapeHtml(tool.Cloud)}</span>
      </div>
      <div class="tool-category">${escapeHtml(tool.Category)}</div>
      <div class="tool-enrichment-grid">
        <div class="field full-width"><div class="label">Plans / Tiers</div><div class="content">${escapeHtml(tool.Plans)}</div></div>
        <div class="field full-width"><div class="label">Priority Order to Enable</div><div class="content">${escapeHtml(tool["Priority Order"])}</div></div>
        <div class="field"><div class="label">Key Policies to Activate</div><div class="content">${escapeHtml(tool["Key Policies"])}</div></div>
        <div class="field"><div class="label">Configuration Specifics</div><div class="content">${escapeHtml(tool["Config Specifics"])}</div></div>
        <div class="field"><div class="label">Cost Signals</div><div class="content">${escapeHtml(tool["Cost Signals"])}</div></div>
        <div class="field"><div class="label">When to Pick This vs Alternatives</div><div class="content">${escapeHtml(tool["When To Pick"])}</div></div>
        <div class="field"><div class="label">Integration Order</div><div class="content">${escapeHtml(tool["Integration Order"])}</div></div>
        <div class="field"><div class="label">Anti-patterns (Don't Do)</div><div class="content">${escapeHtml(tool["Anti-patterns"])}</div></div>
      </div>
    </div>`).join('');
    html += wrapSection('tool-enrichment', 'standard', 'Defense Tool Deep-Dive', '/ which plans, policies, configs to enable', `${relevantTools.length} tools`, toolsBody);
  }

  // Defense tools table (DEEP)
  const defenseToolsBody = `<table class="data-table">
    <thead><tr><th>Component</th><th>Tool</th><th>Type</th><th>Category</th><th>Vendor</th></tr></thead><tbody>
    ${filtered.defense_tools.slice(0, 150).map(t => {
      const comp = componentById[t.ComponentID];
      return `<tr>
        <td><span class="inline-component">${iconHTML(comp, "icon-16")}${escapeHtml(t["Cloud Provider"])} / <strong>${escapeHtml(t["Component Name"])}</strong></span></td>
        <td>${escapeHtml(t["Tool Name"] || "\u2014")}</td>
        <td><span class="tag">${escapeHtml(t["Tool Type"] || "\u2014")}</span></td>
        <td>${escapeHtml(t["Category"] || "\u2014")}</td>
        <td>${escapeHtml(t["Vendor"] || "\u2014")}</td>
      </tr>`;
    }).join("")}
    </tbody></table>
    ${filtered.defense_tools.length > 150 ? `<p style="font-size:11px;color:var(--text-muted);margin-top:12px;font-family:var(--mono);">Showing 150 of ${filtered.defense_tools.length}</p>` : ''}`;
  html += wrapSection('defense-tools', 'deep', 'Defense Tools Table', '/ full mapping by component', `${filtered.defense_tools.length} mappings`, defenseToolsBody);

  const detBySev = { Critical: [], High: [], Medium: [], Low: [] };
  filtered.detections.forEach(d => { (detBySev[d.Severity] || detBySev.Low).push(d); });
  const detectionsBody = `<table class="data-table">
    <thead><tr><th>Severity</th><th>Component</th><th>Detection</th><th>Platform</th><th>MITRE</th><th>Query / Rule</th></tr></thead><tbody>
    ${["Critical", "High", "Medium", "Low"].flatMap(sev => detBySev[sev] || []).slice(0, 120).map(d => {
      const comp = componentById[d.ComponentID];
      return `<tr>
        <td><span class="severity ${(d.Severity || "").toLowerCase()}">${escapeHtml(d.Severity || "\u2014")}</span></td>
        <td><span class="inline-component">${iconHTML(comp, "icon-16")}<strong>${escapeHtml(d["Component Name"])}</strong></span></td>
        <td>${escapeHtml(d["Detection Name"] || "\u2014")}</td>
        <td>${escapeHtml(d.Platform || "\u2014")}</td>
        <td><span class="tag">${escapeHtml(d["MITRE ID"] || "\u2014")}</span></td>
        <td class="mono">${escapeHtml((d["Query / Rule"] || "").slice(0, 300))}</td>
      </tr>`;
    }).join("")}
    </tbody></table>
    ${filtered.detections.length > 120 ? `<p style="font-size:11px;color:var(--text-muted);margin-top:12px;font-family:var(--mono);">Showing 120 of ${filtered.detections.length}</p>` : ''}`;
  html += wrapSection('detections', 'deep', 'Detections to Deploy', '/ SIEM queries', `${filtered.detections.length} detections`, detectionsBody);

  const eventsBody = `<table class="data-table">
    <thead><tr><th>Component</th><th>Event / Detection</th></tr></thead><tbody>
    ${filtered.log_events.slice(0, 100).map(e => {
      const comp = componentById[e.ComponentID];
      return `<tr>
        <td><span class="inline-component">${iconHTML(comp, "icon-16")}<strong>${escapeHtml(e["Component Name"])}</strong></span></td>
        <td>${escapeHtml(e["Event / Detection"] || "\u2014")}</td>
      </tr>`;
    }).join("")}
    </tbody></table>
    ${filtered.log_events.length > 100 ? `<p style="font-size:11px;color:var(--text-muted);margin-top:12px;font-family:var(--mono);">Showing 100 of ${filtered.log_events.length}</p>` : ''}`;
  html += wrapSection('events', 'deep', 'Events to Alert On', '/ wire into SIEM', `${filtered.log_events.length} events`, eventsBody);

  const tacticList = Array.from(new Set(techniques.map(t => t["Tactic"]))).sort();
  const mitreBody = `<div style="margin-bottom:16px;">${tacticList.map(t => `<span class="tag">${escapeHtml(t)}</span>`).join("")}</div>
    <table class="data-table"><thead><tr><th>MITRE ID</th><th>Technique</th><th>Tactic</th><th>Sub-technique</th></tr></thead><tbody>
    ${techniques.slice(0, 60).map(t => `<tr>
      <td><span class="tag">${escapeHtml(t["MITRE ID"])}</span></td>
      <td><strong>${escapeHtml(t["Technique Name"])}</strong></td>
      <td>${escapeHtml(t["Tactic"] || "\u2014")}</td>
      <td>${escapeHtml(t["Sub-technique"] || "\u2014")}</td>
    </tr>`).join("")}
    </tbody></table>
    ${techniques.length > 60 ? `<p style="font-size:11px;color:var(--text-muted);margin-top:12px;font-family:var(--mono);">Showing 60 of ${techniques.length}</p>` : ''}`;
  html += wrapSection('mitre', 'deep', 'MITRE ATT&CK Coverage', '/ applicable techniques', `${techniques.length} techniques, ${tacticList.length} tactics`, mitreBody);

  if (filtered.attack_scenarios.length > 0) {
    let scenariosBody = '';
    filtered.attack_scenarios.forEach(s => {
      const comp = componentById[s.ComponentID];
      scenariosBody += `<div class="component-card" style="border-left-color: var(--crit);">
        <div class="component-title-row">
          ${iconHTML(comp, "icon-24")}
          <h4>${escapeHtml(s["Scenario Name"])}</h4>
        </div>
        <div class="meta">${escapeHtml(s["Cloud Provider"])} / ${escapeHtml(s["Component Name"])}</div>
        <div style="font-size:13px;line-height:1.6;margin-bottom:16px;">${escapeHtml(s["Narrative"])}</div>
        ${killchainHTML(s.ScenarioID)}
        <div class="detail-block full-width">
          <h5>Detection tip</h5>
          <div class="content">${escapeHtml(s["Detection Tip"] || "\u2014")}</div>
        </div>
      </div>`;
    });
    html += wrapSection('scenarios', 'deep', 'Attack Scenarios', '/ kill-chain narratives', `${filtered.attack_scenarios.length} scenarios`, scenariosBody);
  }

  if (playbooks.length > 0) {
    let playbooksBody = '';
    playbooks.forEach(pb => {
      playbooksBody += `<div class="component-card">
        <h4>${escapeHtml(pb["Playbook Name"])}</h4>
        <div class="meta">
          <span class="severity ${(pb["Severity Tier"] || "").toLowerCase()}">${escapeHtml(pb["Severity Tier"])}</span>
          &middot; SLA: ${escapeHtml(pb["SLA"] || "\u2014")}
        </div>
        <div class="detail-grid">
          ${detailBlock("Containment", pb["Containment Steps"])}
          ${detailBlock("Eradication", pb["Eradication Steps"])}
          ${detailBlock("Recovery", pb["Recovery Steps"])}
          ${detailBlock("Lessons learned", pb["Lessons Learned"])}
          ${detailBlock("Rollback", pb["Rollback / Exception Handling"])}
        </div>
      </div>`;
    });
    html += wrapSection('playbooks', 'deep', 'IR Playbooks', '/ response guides', `${playbooks.length} playbooks`, playbooksBody);
  }

  if (actors.length > 0) {
    let actorsBody = '';
    actors.forEach(a => {
      const as_list = actor_scenarios.filter(as => as.ActorID === a.ActorID);
      actorsBody += `<div class="actor-card">
        <div class="actor-header">
          <div class="actor-name">${escapeHtml(a["Name"])}</div>
          <div class="actor-motivation">${escapeHtml(a["Motivation"] || "")}</div>
        </div>
        <div class="actor-body">
          <strong>Aliases:</strong> ${escapeHtml(a["Aliases"] || "\u2014")}<br>
          <strong>Origin:</strong> ${escapeHtml(a["Origin"] || "\u2014")}<br>
          <strong>Target sectors:</strong> ${escapeHtml(a["Target Sectors"] || "\u2014")}<br>
          <strong>Notable campaigns:</strong> ${escapeHtml(a["Notable Campaigns"] || "\u2014")}<br>
          <strong>Signature TTPs:</strong> ${escapeHtml(a["Signature TTPs"] || "\u2014")}<br>
          ${as_list.length > 0 ? `<div style="margin-top:8px;"><strong>Scenarios:</strong> ${as_list.map(as => `<span class="tag">${escapeHtml(as["Scenario Name"])}</span>`).join("")}</div>` : ""}
        </div>
      </div>`;
    });
    html += wrapSection('actors', 'standard', 'Threat Actors', '/ relevant adversaries', `${actors.length} actors`, actorsBody);
  }

  if (breaches.length > 0) {
    let breachesBody = '';
    breaches.forEach(b => {
      breachesBody += `<div class="breach-card">
        <div class="breach-header">
          <div class="breach-title">${escapeHtml(b["Victim"])}</div>
          <div class="breach-year">${escapeHtml(String(b["Year"]))} &middot; ${escapeHtml(b["Industry"] || "")}</div>
        </div>
        <div class="breach-impact">IMPACT: ${escapeHtml(b["Records/Data Lost"] || "")} | ${escapeHtml(b["Financial Impact"] || "")}</div>
        <div class="breach-summary">${escapeHtml(b["Attack Summary"] || "")}</div>
        <div class="breach-cause"><strong>Root cause:</strong> ${escapeHtml(b["Root Cause"] || "")}</div>
        <div class="breach-cause" style="margin-top:8px;"><strong>Lessons:</strong> ${escapeHtml(b["Lessons for Customers"] || "")}</div>
      </div>`;
    });
    html += wrapSection('breaches', 'standard', 'Real-world Breaches', '/ concrete examples', `${breaches.length} incidents`, breachesBody);
  }

  html += `</div>`;

  // Add appendix divider (shown only when appendixMode is on, in print)
  html = html.replace('<div class="report-grid">',
    `<div class="report-grid">
    <div class="appendix-divider">
      <h2>Appendix</h2>
      <p>Raw data tables for reference: detections, events, MITRE techniques, defense tools mapping.</p>
    </div>`);

  // Inject ToC into the html right after the exec summary
  const toc = renderToC(sectionList);
  html = html.replace('<div class="report-grid">',
    `${toc}<div class="report-grid">`);

  $report.innerHTML = html;

  // Set print options on body for CSS targeting
  document.body.setAttribute('data-print-per-component', pdfOptions.perComponentPage ? 'true' : 'false');
  document.body.setAttribute('data-appendix', pdfOptions.appendixMode ? 'true' : 'false');
  document.body.setAttribute('data-customer', metadata.customer);

  // Wire up section collapse toggles
  $report.querySelectorAll('.section-header').forEach(h => {
    h.addEventListener('click', () => {
      const secId = h.dataset.sectionId;
      if (!secId) return;
      if (collapsedSections.has(secId)) {
        collapsedSections.delete(secId);
      } else {
        collapsedSections.add(secId);
      }
      persist();
      renderReport();
    });
  });

  // Wire up view mode buttons
  $report.querySelectorAll('.view-mode-btn').forEach(b => {
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      viewMode = b.dataset.mode;
      persist();
      renderReport();
    });
  });

  // Wire up exec summary: save edits, regenerate button
  const execBody = document.getElementById('exec-summary-body');
  if (execBody) {
    execBody.addEventListener('blur', () => {
      const currentText = execBody.innerText;
      // Check if it differs from auto-generated
      const autoText = (function() {
        const saved = customExecSummary;
        customExecSummary = null;
        const auto = generateExecSummary(comps, effectiveRiskByComp, filtered, breaches, actors);
        customExecSummary = saved;
        return auto;
      })();
      if (currentText !== autoText) {
        customExecSummary = currentText;
      } else {
        customExecSummary = null;
      }
      persist();
    });
  }
  const regenBtn = document.getElementById('btn-regen-summary');
  if (regenBtn) {
    regenBtn.addEventListener('click', () => {
      customExecSummary = null;
      persist();
      renderReport();
    });
  }
}

// ═══ INIT ═══
restore();

// Populate metadata fields from state
document.querySelectorAll('[data-meta-field]').forEach(input => {
  const field = input.dataset.metaField;
  if (metadata[field] !== undefined) input.value = metadata[field];
  input.addEventListener('input', () => {
    metadata[field] = input.value;
    document.body.setAttribute('data-customer', metadata.customer);
    persist();
  });
});

// Populate PDF option checkboxes from state
document.querySelectorAll('[data-pdf-option]').forEach(cb => {
  const opt = cb.dataset.pdfOption;
  cb.checked = !!pdfOptions[opt];
  cb.addEventListener('change', () => {
    pdfOptions[opt] = cb.checked;
    document.body.setAttribute('data-print-per-component', pdfOptions.perComponentPage ? 'true' : 'false');
    document.body.setAttribute('data-appendix', pdfOptions.appendixMode ? 'true' : 'false');
    persist();
  });
});

renderPalette();
renderCanvas();
renderReport();

// Handle window resize — re-render edges
window.addEventListener('resize', () => { updateEdges(); });


/* === v11_admin.js === */
// ═══════════════════════════════════════════════════════════════════════
// ADMIN MODE — CRUD on all 22 sheets with XLSX export
// ═══════════════════════════════════════════════════════════════════════

const ADMIN_STORAGE_KEY = 'csa_admin_edits_v11';

// Sheet metadata — which field is the primary key, which fields are "long text"
const SHEET_META = {
  components: { idField: 'ComponentID', label: 'Components' },
  aliases: { idField: null, label: 'Aliases' },
  defense_tools: { idField: null, label: 'Defense Tools' },
  log_events: { idField: null, label: 'Log Events' },
  mitre_attack: { idField: 'TechniqueID', label: 'MITRE ATT&CK' },
  component_mitre: { idField: null, label: 'Component → MITRE' },
  stride_threats: { idField: null, label: 'STRIDE Threats' },
  component_stride: { idField: null, label: 'Component → STRIDE' },
  detections: { idField: 'DetectionID', label: 'Detections' },
  remediation_playbooks: { idField: 'PlaybookID', label: 'IR Playbooks' },
  detection_playbook: { idField: null, label: 'Detection → Playbook' },
  attack_scenarios: { idField: 'ScenarioID', label: 'Attack Scenarios' },
  scenario_techniques: { idField: null, label: 'Scenario → Technique' },
  threat_actors: { idField: 'ActorID', label: 'Threat Actors' },
  actor_scenarios: { idField: null, label: 'Actor → Scenario' },
  public_breaches: { idField: 'BreachID', label: 'Public Breaches' },
  breach_components: { idField: null, label: 'Breach → Component' },
  compliance_retention: { idField: null, label: 'Compliance Retention' },
  tool_enrichment: { idField: 'Tool', label: 'Tool Enrichment (19 deep)' },
  compliance_mappings: { idField: null, label: 'Compliance Mappings' },
};

// Working copy of DATA — all edits happen here; apply back to DATA + persist on save
let adminWorking = null;  // will be initialized when admin opens
let adminCurrentSheet = 'components';
let adminFilter = '';
let adminOriginal = null;  // for reset-to-original per sheet

function initAdmin() {
  // Deep clone DATA into working copy
  adminWorking = JSON.parse(JSON.stringify(DATA));
  adminOriginal = JSON.parse(JSON.stringify(DATA));

  // Restore prior admin edits from localStorage
  try {
    const saved = localStorage.getItem(ADMIN_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && typeof parsed === 'object') {
        // Merge saved edits into working copy
        Object.keys(parsed).forEach(sheet => {
          if (Array.isArray(parsed[sheet])) {
            adminWorking[sheet] = parsed[sheet];
          }
        });
      }
    }
  } catch (e) { /* ignore */ }
}

function persistAdmin() {
  try {
    // Only persist sheets that changed
    const changed = {};
    Object.keys(adminWorking).forEach(sheet => {
      if (JSON.stringify(adminWorking[sheet]) !== JSON.stringify(adminOriginal[sheet])) {
        changed[sheet] = adminWorking[sheet];
      }
    });
    localStorage.setItem(ADMIN_STORAGE_KEY, JSON.stringify(changed));
  } catch (e) {
    showToast('Could not persist changes (localStorage full?)', true);
  }
}

function applyEditsToLiveData() {
  // Copy working data back to DATA (so report + canvas reflect edits)
  Object.keys(adminWorking).forEach(sheet => {
    DATA[sheet] = adminWorking[sheet];
  });
  // Rebuild componentById index
  Object.keys(componentById).forEach(k => delete componentById[k]);
  DATA.components.forEach(c => { componentById[c.ComponentID] = c; });
  renderCanvas();
  renderReport();
}

function openAdmin() {
  if (!adminWorking) initAdmin();
  let panel = document.getElementById('admin-panel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'admin-panel';
    panel.className = 'admin-panel';
    panel.innerHTML = adminPanelHTML();
    document.body.appendChild(panel);
    wireAdminEvents();
  }
  setTimeout(() => panel.classList.add('open'), 10);
  renderAdminTable();
}

function closeAdmin() {
  const panel = document.getElementById('admin-panel');
  if (panel) panel.classList.remove('open');
}

function adminPanelHTML() {
  const sheetOptions = Object.keys(SHEET_META).map(k =>
    `<option value="${k}">${SHEET_META[k].label} (${adminWorking[k] ? adminWorking[k].length : 0})</option>`
  ).join('');
  return `
    <div class="admin-header">
      <h2>Dataset Admin</h2>
      <span class="hint">Edit any sheet \u2022 All changes saved to localStorage \u2022 Export XLSX when done</span>
      <button id="admin-export-xlsx" class="primary">Export XLSX</button>
      <button id="admin-close">Close</button>
    </div>
    <div class="admin-toolbar">
      <label style="font-size:10px; color:var(--text-muted); font-family:var(--mono); letter-spacing:0.1em;">SHEET</label>
      <select id="admin-sheet-select">${sheetOptions}</select>
      <input type="text" id="admin-filter" placeholder="Filter rows..." style="flex:1; min-width:200px;" />
      <button id="admin-add-row" class="primary">+ Add row</button>
      <button id="admin-reset-sheet" title="Reset this sheet to original values">Reset sheet</button>
      <div class="sheet-stats" id="admin-sheet-stats"></div>
    </div>
    <div class="admin-body">
      <table class="admin-table" id="admin-table"></table>
    </div>
  `;
}

function wireAdminEvents() {
  document.getElementById('admin-close').addEventListener('click', closeAdmin);
  document.getElementById('admin-export-xlsx').addEventListener('click', exportXLSX);
  document.getElementById('admin-sheet-select').addEventListener('change', e => {
    adminCurrentSheet = e.target.value;
    adminFilter = '';
    document.getElementById('admin-filter').value = '';
    renderAdminTable();
  });
  document.getElementById('admin-filter').addEventListener('input', e => {
    adminFilter = e.target.value.toLowerCase();
    renderAdminTable();
  });
  document.getElementById('admin-add-row').addEventListener('click', () => openEditModal(null));
  document.getElementById('admin-reset-sheet').addEventListener('click', () => {
    if (confirm(`Reset the "${adminCurrentSheet}" sheet to its original values? All your edits on this sheet will be lost.`)) {
      adminWorking[adminCurrentSheet] = JSON.parse(JSON.stringify(adminOriginal[adminCurrentSheet]));
      persistAdmin();
      applyEditsToLiveData();
      renderAdminTable();
      showToast(`Reset "${adminCurrentSheet}" to original.`);
    }
  });
}

function renderAdminTable() {
  const rows = adminWorking[adminCurrentSheet] || [];
  const origRows = adminOriginal[adminCurrentSheet] || [];
  const table = document.getElementById('admin-table');
  if (!rows.length) {
    table.innerHTML = `<thead><tr><th>Empty sheet</th></tr></thead><tbody><tr><td>No rows. Click "+ Add row" to create the first.</td></tr></tbody>`;
    document.getElementById('admin-sheet-stats').textContent = `0 rows`;
    return;
  }
  const columns = Object.keys(rows[0]).filter(k => !k.startsWith('_'));
  // Filter
  const filtered = adminFilter
    ? rows.filter(r => Object.values(r).some(v => String(v).toLowerCase().includes(adminFilter)))
    : rows;

  // Show first 500 rows to avoid DOM performance issues
  const toShow = filtered.slice(0, 500);
  const truncated = filtered.length > 500;

  const origJSON = new Set(origRows.map(r => JSON.stringify(r)));

  const thead = `<thead><tr>${columns.map(c => `<th>${escapeHtml(c)}</th>`).join('')}<th style="text-align:right;">Actions</th></tr></thead>`;
  const tbody = `<tbody>${toShow.map((r, idx) => {
    const isModified = !origJSON.has(JSON.stringify(r));
    const realIdx = rows.indexOf(r);
    return `<tr data-row-idx="${realIdx}" class="${isModified ? 'modified' : ''}">
      ${columns.map(c => {
        const v = r[c];
        const disp = v === null || v === undefined ? '' : String(v);
        return `<td title="${escapeHtml(disp)}">${escapeHtml(disp.slice(0, 80))}${disp.length > 80 ? '...' : ''}</td>`;
      }).join('')}
      <td class="actions-cell">
        <button class="row-action" data-action="edit" data-idx="${realIdx}">Edit</button>
        <button class="row-action delete" data-action="delete" data-idx="${realIdx}">Delete</button>
      </td>
    </tr>`;
  }).join('')}</tbody>`;

  table.innerHTML = thead + tbody;
  const modifiedCount = rows.filter(r => !origJSON.has(JSON.stringify(r))).length;
  const addedCount = Math.max(0, rows.length - origRows.length);
  document.getElementById('admin-sheet-stats').textContent =
    `${toShow.length}${truncated ? ` of ${filtered.length}` : ''}/${rows.length} rows` +
    (modifiedCount > 0 ? ` \u2022 ${modifiedCount} modified` : '') +
    (addedCount > 0 ? ` \u2022 ${addedCount} added` : '');

  // Wire row actions
  table.querySelectorAll('.row-action').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const action = btn.dataset.action;
      const idx = parseInt(btn.dataset.idx, 10);
      if (action === 'edit') openEditModal(idx);
      else if (action === 'delete') deleteRow(idx);
    });
  });
  table.querySelectorAll('tbody tr').forEach(tr => {
    tr.addEventListener('dblclick', () => {
      const idx = parseInt(tr.dataset.rowIdx, 10);
      if (!isNaN(idx)) openEditModal(idx);
    });
  });
}

function openEditModal(rowIdx) {
  const isNew = rowIdx === null;
  const rows = adminWorking[adminCurrentSheet];
  let row;
  if (isNew) {
    // Build a new empty row based on first existing row's schema
    if (rows.length) {
      row = {};
      Object.keys(rows[0]).forEach(k => { row[k] = ''; });
    } else {
      row = { id: '', name: '', value: '' };  // minimal fallback
    }
    // Auto-assign ID for sheets with idField
    const idField = SHEET_META[adminCurrentSheet].idField;
    if (idField) {
      const maxId = rows.reduce((m, r) => {
        const v = parseInt(r[idField], 10);
        return isNaN(v) ? m : Math.max(m, v);
      }, 0);
      const firstRow = rows.length > 0 ? rows[0] : null;
      const firstIdVal = firstRow ? firstRow[idField] : null;
      row[idField] = typeof firstIdVal === 'number' ? maxId + 1 : String(maxId + 1);
    }
  } else {
    row = rows[rowIdx];
  }

  const fields = Object.keys(row).filter(k => !k.startsWith('_'));
  const fieldsHTML = fields.map(k => {
    const v = row[k];
    const disp = v === null || v === undefined ? '' : String(v);
    const isLong = disp.length > 60 || /notes|description|query|rule|step|summary|narrative|pushback|example|recommend|misconfig|question|practice|impact|lesson|trait/i.test(k);
    const type = typeof v === 'number' ? 'number' : 'text';
    const longClass = isLong ? 'long-text' : '';
    return `<div class="field-row ${longClass}">
      <label>${escapeHtml(k)}</label>
      ${isLong
        ? `<textarea data-field="${escapeHtml(k)}">${escapeHtml(disp)}</textarea>`
        : `<input type="${type}" data-field="${escapeHtml(k)}" value="${escapeHtml(disp)}" />`}
    </div>`;
  }).join('');

  let overlay = document.getElementById('admin-modal-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'admin-modal-overlay';
    overlay.className = 'admin-modal-overlay';
    document.body.appendChild(overlay);
  }
  overlay.innerHTML = `
    <div class="admin-modal">
      <div class="admin-modal-header">
        <h3>${isNew ? 'New row' : 'Edit row'} \u2014 ${escapeHtml(SHEET_META[adminCurrentSheet].label)}</h3>
      </div>
      <div class="admin-modal-body">${fieldsHTML}</div>
      <div class="admin-modal-footer">
        <button id="admin-cancel">Cancel</button>
        <button id="admin-save" class="primary">${isNew ? 'Create' : 'Save'}</button>
      </div>
    </div>
  `;
  overlay.classList.add('open');

  document.getElementById('admin-cancel').addEventListener('click', () => overlay.classList.remove('open'));
  document.getElementById('admin-save').addEventListener('click', () => {
    const newRow = {};
    overlay.querySelectorAll('[data-field]').forEach(el => {
      let val = el.value;
      if (el.type === 'number') val = val === '' ? '' : Number(val);
      // Preserve int type for ID fields
      const key = el.dataset.field;
      if (typeof row[key] === 'number' && !isNaN(Number(val)) && val !== '') {
        val = Number(val);
      }
      newRow[key] = val;
    });
    if (isNew) {
      rows.push(newRow);
    } else {
      rows[rowIdx] = newRow;
    }
    persistAdmin();
    applyEditsToLiveData();
    overlay.classList.remove('open');
    renderAdminTable();
    showToast(isNew ? 'Row created' : 'Row saved');
  });
}

function deleteRow(rowIdx) {
  const rows = adminWorking[adminCurrentSheet];
  const row = rows[rowIdx];
  const preview = JSON.stringify(row).slice(0, 100);
  if (!confirm(`Delete this row?\n\n${preview}...\n\nThis cannot be undone except by "Reset sheet".`)) return;
  rows.splice(rowIdx, 1);
  persistAdmin();
  applyEditsToLiveData();
  renderAdminTable();
  showToast('Row deleted');
}

function showToast(msg, isError) {
  let t = document.getElementById('admin-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'admin-toast';
    t.className = 'admin-toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.className = 'admin-toast' + (isError ? ' error' : '');
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

function exportXLSX() {
  if (typeof XLSX === 'undefined') {
    showToast('XLSX library not loaded', true);
    return;
  }
  const wb = XLSX.utils.book_new();
  Object.keys(adminWorking).forEach(sheet => {
    const rows = adminWorking[sheet];
    if (!Array.isArray(rows) || !rows.length) return;
    // Strip _icon_uri and other internal fields
    const cleaned = rows.map(r => {
      const out = {};
      Object.keys(r).forEach(k => {
        if (!k.startsWith('_')) out[k] = r[k];
      });
      return out;
    });
    const ws = XLSX.utils.json_to_sheet(cleaned);
    // Sheet names are limited to 31 chars
    const sheetName = sheet.slice(0, 31);
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
  });
  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `Cloud-Security-Advisor-Dataset-${dateStr}.xlsx`);
  showToast('XLSX exported. Upload it next session to persist changes permanently.');
}

// Expose openAdmin globally (wired from header button)
window.openAdmin = openAdmin;


/* === v12_dashboard.js === */
// ═══════════════════════════════════════════════════════════════════════
// DASHBOARD — Cross-filtered exploration view
// Works on DATA directly (not filtered by canvas like the report)
// ═══════════════════════════════════════════════════════════════════════

// Active filters — when a slicer pill or chart element is clicked, it adds/removes from these
const dashFilters = {
  cloud: new Set(),         // 'AWS' | 'Azure' | 'GCP'
  category: new Set(),      // 'IAM' | 'Compute' | ...
  layer: new Set(),         // 'Identity' | 'Network' | ...
  risk: new Set(),          // 'Critical' | 'High' | 'Medium' | 'Low'
  severity: new Set(),      // 'Critical' | 'High' | 'Medium' | 'Low' (for detections)
};

function riskTier(r) {
  const n = Number(r) || 0;
  if (n >= 9) return 'Critical';
  if (n >= 7) return 'High';
  if (n >= 5) return 'Medium';
  return 'Low';
}

function matchComponentFilter(c) {
  if (dashFilters.cloud.size && !dashFilters.cloud.has(c['Cloud Provider'])) return false;
  if (dashFilters.category.size && !dashFilters.category.has(c['Category'])) return false;
  if (dashFilters.risk.size && !dashFilters.risk.has(riskTier(c['Risk Score']))) return false;
  if (dashFilters.layer.size) {
    const layers = String(c['Defense Layers'] || '').split(';').map(s => s.trim()).filter(Boolean);
    if (!layers.some(l => dashFilters.layer.has(l))) return false;
  }
  return true;
}

function renderDashboard() {
  const filteredComps = DATA.components.filter(matchComponentFilter);
  const filteredIds = new Set(filteredComps.map(c => c.ComponentID));

  let filteredDetections = DATA.detections.filter(d => filteredIds.has(d.ComponentID));
  if (dashFilters.severity.size) {
    filteredDetections = filteredDetections.filter(d => dashFilters.severity.has(d.Severity));
  }
  const filteredTools = DATA.defense_tools.filter(t => filteredIds.has(t.ComponentID));
  const filteredMitre = DATA.component_mitre.filter(m => filteredIds.has(m.ComponentID));
  const filteredBreaches = new Set(
    DATA.breach_components.filter(bc => filteredIds.has(bc.ComponentID)).map(bc => bc.BreachID)
  );
  const filteredScenarios = DATA.attack_scenarios.filter(s => filteredIds.has(s.ComponentID));
  const scenIds = new Set(filteredScenarios.map(s => s.ScenarioID));
  const actorSc = DATA.actor_scenarios.filter(as => scenIds.has(as.ScenarioID));
  const filteredActorIds = new Set(actorSc.map(as => as.ActorID));

  // ─── KPI strip ─────────────────────────────────────────────────
  const avgRisk = filteredComps.length
    ? (filteredComps.reduce((s, c) => s + (Number(c['Risk Score']) || 0), 0) / filteredComps.length).toFixed(1)
    : '—';
  const critDetCount = filteredDetections.filter(d => d.Severity === 'Critical').length;
  const highDetCount = filteredDetections.filter(d => d.Severity === 'High').length;
  const uniqueTools = new Set(filteredTools.map(t => t['Tool Name']).filter(Boolean)).size;
  const techCount = new Set(filteredMitre.map(m => m.TechniqueID)).size;
  const actorCount = filteredActorIds.size;

  const kpiHTML = `<div class="dashboard-kpis">
    <div class="dashboard-kpi"><div class="label">Components</div><div class="value">${filteredComps.length}</div><div class="sub">of ${DATA.components.length} total</div></div>
    <div class="dashboard-kpi"><div class="label">Avg Risk</div><div class="value">${avgRisk}</div><div class="sub">0-10 scale</div></div>
    <div class="dashboard-kpi crit"><div class="label">Critical Detections</div><div class="value">${critDetCount}</div><div class="sub">of ${filteredDetections.length} total</div></div>
    <div class="dashboard-kpi high"><div class="label">High Detections</div><div class="value">${highDetCount}</div><div class="sub">in scope</div></div>
    <div class="dashboard-kpi accent"><div class="label">Defense Tools</div><div class="value">${uniqueTools}</div><div class="sub">unique</div></div>
    <div class="dashboard-kpi accent"><div class="label">MITRE Techniques</div><div class="value">${techCount}</div><div class="sub">${actorCount} actors</div></div>
  </div>`;

  // ─── Slicer bar ────────────────────────────────────────────────
  const cloudCounts = countBy(DATA.components, c => c['Cloud Provider']);
  const categoryCounts = countBy(DATA.components, c => c['Category']);
  const layerCounts = {};
  DATA.components.forEach(c => {
    const layers = String(c['Defense Layers'] || '').split(';').map(s => s.trim()).filter(Boolean);
    layers.forEach(l => { layerCounts[l] = (layerCounts[l] || 0) + 1; });
  });
  const riskTierCounts = countBy(DATA.components, c => riskTier(c['Risk Score']));
  const severityCounts = countBy(DATA.detections, d => d.Severity);

  const sliceHTML = `<div class="slicer-bar">
    <div class="slicer">
      <div class="slicer-label">Cloud</div>
      <div class="slicer-pills">
        ${['AWS','Azure','GCP'].map(v => `
          <span class="slicer-pill ${dashFilters.cloud.has(v) ? 'active' : ''}" data-slicer="cloud" data-val="${v}">${v}<span class="pill-count">${cloudCounts[v] || 0}</span></span>
        `).join('')}
      </div>
    </div>
    <div class="slicer">
      <div class="slicer-label">Category</div>
      <div class="slicer-pills">
        ${Object.keys(categoryCounts).sort().map(v => `
          <span class="slicer-pill ${dashFilters.category.has(v) ? 'active' : ''}" data-slicer="category" data-val="${escapeHtml(v)}">${escapeHtml(v)}<span class="pill-count">${categoryCounts[v]}</span></span>
        `).join('')}
      </div>
    </div>
    <div class="slicer">
      <div class="slicer-label">Defense Layer</div>
      <div class="slicer-pills">
        ${Object.keys(layerCounts).sort().map(v => `
          <span class="slicer-pill ${dashFilters.layer.has(v) ? 'active' : ''}" data-slicer="layer" data-val="${escapeHtml(v)}">${escapeHtml(v)}<span class="pill-count">${layerCounts[v]}</span></span>
        `).join('')}
      </div>
    </div>
    <div class="slicer">
      <div class="slicer-label">Risk Tier</div>
      <div class="slicer-pills">
        ${['Critical','High','Medium','Low'].map(v => `
          <span class="slicer-pill ${dashFilters.risk.has(v) ? 'active' : ''}" data-slicer="risk" data-val="${v}">${v}<span class="pill-count">${riskTierCounts[v] || 0}</span></span>
        `).join('')}
      </div>
    </div>
    <div class="slicer">
      <div class="slicer-label">Detection Severity</div>
      <div class="slicer-pills">
        ${['Critical','High','Medium','Low'].map(v => `
          <span class="slicer-pill ${dashFilters.severity.has(v) ? 'active' : ''}" data-slicer="severity" data-val="${v}">${v}<span class="pill-count">${severityCounts[v] || 0}</span></span>
        `).join('')}
      </div>
    </div>
  </div>`;

  const activeFilterCount = Object.values(dashFilters).reduce((sum, s) => sum + s.size, 0);
  const clearRow = `<div class="slicer-clear-row">
    <div class="filter-summary">${activeFilterCount === 0 ? 'No filters applied — showing full dataset.' : `<strong>${activeFilterCount}</strong> filter${activeFilterCount===1?'':'s'} active. Showing <strong>${filteredComps.length}</strong> of ${DATA.components.length} components, <strong>${filteredDetections.length}</strong> of ${DATA.detections.length} detections.`}</div>
    ${activeFilterCount > 0 ? '<button id="dash-clear-all">Clear all filters</button>' : ''}
  </div>`;

  // ─── Tile 1: Components by Cloud (bar chart) ──────────────────
  const byCloud = countBy(filteredComps, c => c['Cloud Provider']);
  const maxCloud = Math.max(1, ...Object.values(byCloud));
  const cloudChart = `<ul class="top-list">
    ${['AWS','Azure','GCP'].map(cl => {
      const count = byCloud[cl] || 0;
      const pct = (count / maxCloud * 100).toFixed(0);
      const color = cl === 'AWS' ? '#FF9900' : cl === 'Azure' ? '#00A4EF' : '#4285F4';
      return `<li data-filter-click data-slicer="cloud" data-val="${cl}">
        <div class="bar" style="width:${pct}%; background:${color}22;"></div>
        <span class="rank" style="color:${color};">\u25CF</span>
        <span class="label">${cl}</span>
        <span class="value">${count}</span>
      </li>`;
    }).join('')}
  </ul>`;

  // ─── Tile 2: Components by Category (top 8) ────────────────────
  const byCat = countBy(filteredComps, c => c['Category']);
  const catItems = Object.entries(byCat).sort(([,a], [,b]) => b - a).slice(0, 10);
  const maxCat = Math.max(1, ...catItems.map(([,v]) => v));
  const categoryChart = `<ul class="top-list">
    ${catItems.map(([cat, count], i) => {
      const pct = (count / maxCat * 100).toFixed(0);
      return `<li data-filter-click data-slicer="category" data-val="${escapeHtml(cat)}">
        <div class="bar" style="width:${pct}%;"></div>
        <span class="rank">${i+1}</span>
        <span class="label">${escapeHtml(cat)}</span>
        <span class="value">${count}</span>
      </li>`;
    }).join('')}
  </ul>`;

  // ─── Tile 3: Detection severity donut ─────────────────────────
  const sevCounts = countBy(filteredDetections, d => d.Severity);
  const sevSegs = [
    { label: 'Critical', value: sevCounts.Critical || 0, color: '#EF4444' },
    { label: 'High', value: sevCounts.High || 0, color: '#F59E0B' },
    { label: 'Medium', value: sevCounts.Medium || 0, color: '#60A5FA' },
    { label: 'Low', value: sevCounts.Low || 0, color: '#9CA3AF' },
  ];
  const totalSev = sevSegs.reduce((s, x) => s + x.value, 0);
  let donutHTML = '';
  if (totalSev > 0) {
    const R = 55, C = 2 * Math.PI * R;
    let offset = 0;
    const arcs = sevSegs.map(s => {
      if (s.value === 0) return '';
      const len = (s.value / totalSev) * C;
      const arc = `<circle r="${R}" cx="80" cy="80" fill="none" stroke="${s.color}" stroke-width="20"
        stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-offset}"
        data-filter-click data-slicer="severity" data-val="${s.label}" />`;
      offset += len;
      return arc;
    }).join('');
    donutHTML = `<div style="display:flex; gap:20px; align-items:center; justify-content:center;">
      <svg viewBox="0 0 160 160" width="160" height="160" style="transform:rotate(-90deg);">${arcs}</svg>
      <div>
        ${sevSegs.filter(s => s.value > 0).map(s => `
          <div style="display:flex; align-items:center; gap:8px; font-size:12px; margin-bottom:4px; cursor:pointer;" data-filter-click data-slicer="severity" data-val="${s.label}">
            <span style="display:inline-block;width:10px;height:10px;background:${s.color};border-radius:2px;"></span>
            <span style="color:var(--text-primary);">${s.label}</span>
            <span style="font-family:var(--mono);color:var(--text-muted);">${s.value}</span>
          </div>
        `).join('')}
      </div>
    </div>`;
  } else {
    donutHTML = '<div style="text-align:center; color:var(--text-muted); font-size:12px;">No detections in current scope</div>';
  }

  // ─── Tile 4: MITRE tactic heatmap ──────────────────────────────
  const tacticCounts = {};
  filteredMitre.forEach(m => {
    const tech = DATA.mitre_attack.find(t => t.TechniqueID === m.TechniqueID);
    if (tech && tech.Tactic) {
      tacticCounts[tech.Tactic] = (tacticCounts[tech.Tactic] || 0) + 1;
    }
  });
  const tacticEntries = Object.entries(tacticCounts).sort(([,a], [,b]) => b - a);
  const maxTactic = Math.max(1, ...tacticEntries.map(([,v]) => v));
  const heatmapHTML = tacticEntries.length
    ? `<div class="mitre-heatmap">
        ${tacticEntries.map(([tactic, count]) => {
          const intensity = Math.min(4, Math.floor((count / maxTactic) * 5));
          return `<div class="heatmap-cell" data-intensity="${intensity}">
            <div class="cell-tactic">${escapeHtml(tactic)}</div>
            <div class="cell-count">${count} technique${count===1?'':'s'}</div>
          </div>`;
        }).join('')}
      </div>`
    : '<div style="text-align:center; color:var(--text-muted); font-size:12px;">No MITRE techniques in current scope</div>';

  // ─── Tile 5: Top defense tools by component count ──────────────
  const toolCounts = {};
  filteredTools.forEach(t => {
    const name = t['Tool Name'];
    if (!name) return;
    if (!toolCounts[name]) toolCounts[name] = { count: 0, comps: new Set() };
    toolCounts[name].comps.add(t.ComponentID);
  });
  const toolItems = Object.entries(toolCounts)
    .map(([name, info]) => [name, info.comps.size])
    .sort(([,a], [,b]) => b - a)
    .slice(0, 12);
  const maxTool = Math.max(1, ...toolItems.map(([,v]) => v));
  const toolChart = toolItems.length
    ? `<ul class="top-list">
        ${toolItems.map(([tool, count], i) => {
          const pct = (count / maxTool * 100).toFixed(0);
          return `<li>
            <div class="bar" style="width:${pct}%;"></div>
            <span class="rank">${i+1}</span>
            <span class="label">${escapeHtml(tool)}</span>
            <span class="value">${count}</span>
          </li>`;
        }).join('')}
      </ul>`
    : '<div style="text-align:center; color:var(--text-muted); font-size:12px;">No tools in current scope</div>';

  // ─── Tile 6: Risk distribution ──────────────────────────────────
  const riskByTier = countBy(filteredComps, c => riskTier(c['Risk Score']));
  const maxRiskTier = Math.max(1, ...Object.values(riskByTier));
  const riskChart = `<ul class="top-list">
    ${['Critical','High','Medium','Low'].map(tier => {
      const count = riskByTier[tier] || 0;
      const pct = (count / maxRiskTier * 100).toFixed(0);
      const color = tier==='Critical'?'#EF4444':tier==='High'?'#F59E0B':tier==='Medium'?'#60A5FA':'#9CA3AF';
      return `<li data-filter-click data-slicer="risk" data-val="${tier}">
        <div class="bar" style="width:${pct}%; background:${color}22;"></div>
        <span class="rank" style="color:${color};">\u25CF</span>
        <span class="label">${tier}</span>
        <span class="value">${count}</span>
      </li>`;
    }).join('')}
  </ul>`;

  // ─── Tile 7: Threat actors in scope ────────────────────────────
  const actorsWithScenarios = {};
  actorSc.forEach(as => {
    if (!actorsWithScenarios[as.ActorID]) actorsWithScenarios[as.ActorID] = 0;
    actorsWithScenarios[as.ActorID]++;
  });
  const actorItems = Object.entries(actorsWithScenarios)
    .map(([aid, count]) => {
      const actor = DATA.threat_actors.find(a => a.ActorID === Number(aid) || a.ActorID === aid);
      return [actor, count];
    })
    .filter(([a]) => a)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 10);

  const actorHTML = actorItems.length
    ? `<div class="actor-list-compact">
        ${actorItems.map(([actor, count]) => `
          <div class="actor-row">
            <div>
              <div class="actor-name">${escapeHtml(actor.Name)}</div>
              <div style="font-size:10px; color:var(--text-muted); margin-top:2px;">${escapeHtml(actor['Origin'] || '')} \u2022 ${escapeHtml(actor.Motivation || '')}</div>
            </div>
            <div class="actor-scenarios">${count} scenario${count===1?'':'s'}</div>
          </div>
        `).join('')}
      </div>`
    : '<div style="text-align:center; color:var(--text-muted); font-size:12px;">No threat actors match current scope</div>';

  // ─── Tile 8: Coverage matrix (detection/tool/mitre per component) ────
  // Simple coverage table: for each cloud provider, % of components with coverage
  const clouds = ['AWS', 'Azure', 'GCP'];
  const coverageRows = clouds.map(cl => {
    const comps = filteredComps.filter(c => c['Cloud Provider'] === cl);
    if (comps.length === 0) return { cloud: cl, count: 0, dets: 0, tools: 0, mitre: 0 };
    const withDets = comps.filter(c => filteredDetections.some(d => d.ComponentID === c.ComponentID)).length;
    const withTools = comps.filter(c => filteredTools.some(t => t.ComponentID === c.ComponentID)).length;
    const withMitre = comps.filter(c => filteredMitre.some(m => m.ComponentID === c.ComponentID)).length;
    return { cloud: cl, count: comps.length, dets: withDets, tools: withTools, mitre: withMitre };
  }).filter(r => r.count > 0);

  const coverageHTML = coverageRows.length
    ? `<div class="coverage-matrix">
        <table>
          <thead><tr><th>Cloud</th><th>Components</th><th>Has Detections</th><th>Has Tools</th><th>Has MITRE</th></tr></thead>
          <tbody>
            ${coverageRows.map(r => `<tr>
              <td>${r.cloud}</td>
              <td>${r.count}</td>
              <td class="${r.dets === r.count ? 'has' : (r.dets > 0 ? '' : 'miss')}">${r.dets} / ${r.count} (${r.count ? (r.dets/r.count*100).toFixed(0) : 0}%)</td>
              <td class="${r.tools === r.count ? 'has' : (r.tools > 0 ? '' : 'miss')}">${r.tools} / ${r.count} (${r.count ? (r.tools/r.count*100).toFixed(0) : 0}%)</td>
              <td class="${r.mitre === r.count ? 'has' : (r.mitre > 0 ? '' : 'miss')}">${r.mitre} / ${r.count} (${r.count ? (r.mitre/r.count*100).toFixed(0) : 0}%)</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>`
    : '<div style="text-align:center; color:var(--text-muted); font-size:12px;">No components in current scope</div>';

  // ─── Assemble ──────────────────────────────────────────────────
  const tiles = `<div class="dashboard-tiles">
    <div class="tile span-4">
      <h4>Cloud Provider</h4>
      <div class="tile-sub">Click to filter</div>
      <div class="tile-body">${cloudChart}</div>
    </div>
    <div class="tile span-4">
      <h4>Categories</h4>
      <div class="tile-sub">Top 10 \u2022 Click to filter</div>
      <div class="tile-body">${categoryChart}</div>
    </div>
    <div class="tile span-4">
      <h4>Risk Distribution</h4>
      <div class="tile-sub">Click a tier to filter</div>
      <div class="tile-body">${riskChart}</div>
    </div>
    <div class="tile span-4">
      <h4>Detection Severity</h4>
      <div class="tile-sub">${filteredDetections.length} detections in scope</div>
      <div class="tile-body">${donutHTML}</div>
    </div>
    <div class="tile span-8">
      <h4>MITRE ATT&CK Tactic Coverage</h4>
      <div class="tile-sub">Heatmap intensity = number of techniques in scope</div>
      <div class="tile-body">${heatmapHTML}</div>
    </div>
    <div class="tile span-6">
      <h4>Top Defense Tools</h4>
      <div class="tile-sub">Ranked by component coverage</div>
      <div class="tile-body">${toolChart}</div>
    </div>
    <div class="tile span-6">
      <h4>Threat Actors in Scope</h4>
      <div class="tile-sub">Linked via attack scenarios</div>
      <div class="tile-body">${actorHTML}</div>
    </div>
    <div class="tile span-12">
      <h4>Coverage Matrix</h4>
      <div class="tile-sub">Detection / tool / MITRE coverage per cloud</div>
      <div class="tile-body">${coverageHTML}</div>
    </div>
  </div>`;

  const dashEl = document.getElementById('dashboard-view');
  dashEl.innerHTML = sliceHTML + clearRow + kpiHTML + tiles;

  // Wire slicer pills
  dashEl.querySelectorAll('[data-slicer]').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      const slicer = el.dataset.slicer;
      const val = el.dataset.val;
      if (dashFilters[slicer].has(val)) {
        dashFilters[slicer].delete(val);
      } else {
        dashFilters[slicer].add(val);
      }
      renderDashboard();
    });
  });

  // Wire clear all
  const clearBtn = document.getElementById('dash-clear-all');
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      Object.values(dashFilters).forEach(s => s.clear());
      renderDashboard();
    });
  }
}

function countBy(arr, fn) {
  const out = {};
  arr.forEach(x => {
    const k = fn(x);
    if (k === undefined || k === null || k === '') return;
    out[k] = (out[k] || 0) + 1;
  });
  return out;
}

// Expose globally for init hook
window.renderDashboard = renderDashboard;


/* === v17_mockcharts.js === */
// ═══════════════════════════════════════════════════════════════════════
// SECOPS VISUALIZATION PREVIEWS — mock data + 6 chart renderers
// ═══════════════════════════════════════════════════════════════════════

// Mock data pools — anonymized using IETF-reserved example.com domain
const MOCK_POOLS = {
  users: [
    'jsmith@example.com', 'mchen@example.com', 'alopez@example.com',
    'bsingh@example.com', 'rkim@example.com', 'tnguyen@example.com',
    'kpatel@example.com', 'dwilson@example.com', 'sgarcia@example.com',
    'nokafor@example.com', 'lcohen@example.com', 'farora@example.com',
  ],
  countries: [
    { name: 'USA', code: 'US' }, { name: 'Brazil', code: 'BR' },
    { name: 'Russia', code: 'RU' }, { name: 'China', code: 'CN' },
    { name: 'Germany', code: 'DE' }, { name: 'India', code: 'IN' },
    { name: 'UK', code: 'GB' }, { name: 'Nigeria', code: 'NG' },
    { name: 'Vietnam', code: 'VN' }, { name: 'Iran', code: 'IR' },
    { name: 'Mexico', code: 'MX' }, { name: 'Israel', code: 'IL' },
  ],
  ips: [
    '203.0.113.42', '198.51.100.15', '192.0.2.108', '203.0.113.91',
    '198.51.100.73', '192.0.2.45', '203.0.113.7', '198.51.100.200',
  ],
  hosts: [
    'WIN-PROD-DC01', 'LIN-WEB-04', 'WIN-FIN-01', 'LIN-API-09',
    'WIN-DEV-12', 'LIN-DB-02', 'WIN-HR-05', 'LIN-K8S-NODE-7',
  ],
  buckets: [
    'acme-prod-data', 'acme-backups', 'acme-logs-archive', 'acme-customer-pii',
    'acme-finance-reports', 'acme-ml-training-set', 'acme-public-assets',
  ],
  ruleNames: [
    'Anomalous Sign-In - Impossible Travel', 'Brute Force - SSH', 'Phish - URL Click',
    'Persistence - Run Key Modified', 'Lateral Movement - Pass The Hash',
    'Data Exfil - Unusual Egress', 'Privilege Escalation - Role Added',
  ],
  tlds: ['.tk', '.top', '.xyz', '.pw', '.cf', '.ml'],
  fileNames: [
    'powershell.exe', 'certutil.exe', 'mshta.exe', 'rundll32.exe',
    'wmic.exe', 'regsvr32.exe', 'bitsadmin.exe',
  ],
  apps: [
    'AcmeCRM', 'PartnerPortal', 'MarketingAutomation', 'AnalyticsBeta',
    'LegacyApp', 'NewIntegration', 'BackupManager',
  ],
  threatTypes: ['malicious-ip', 'phishing-domain', 'malware-hash', 'c2-url'],
  feedSources: [
    'Mandiant', 'Recorded Future', 'AbuseIPDB', 'OTX AlienVault',
    'Internal IR', 'MISP', 'CrowdStrike Falcon X',
  ],
  productNames: [
    'Microsoft Defender XDR', 'Microsoft Sentinel', 'AWS GuardDuty',
    'CrowdStrike Falcon', 'Defender for Cloud', 'Custom analytics rule',
  ],
};

// Pick N random items from a pool (without replacement when possible)
function pickN(pool, n) {
  const copy = [...pool];
  const out = [];
  while (out.length < n && copy.length > 0) {
    const idx = Math.floor(Math.random() * copy.length);
    out.push(copy.splice(idx, 1)[0]);
  }
  return out;
}

function jitter(base, pct = 0.3) {
  const delta = base * pct;
  return Math.max(1, Math.round(base + (Math.random() * 2 - 1) * delta));
}

// ─── PER-VIZ MOCK DATA GENERATORS ────────────────────────────────────
// Keyed by VizID. Each returns { type, data } where data shape depends on type.
const MOCK_GENERATORS = {
  // Dashboard 1: User Threats
  1: () => ({ // Top 5 risky users
    type: 'bar',
    data: pickN(MOCK_POOLS.users, 5).map((u, i) => ({ label: u, value: jitter(50 - i * 8) })),
    xLabel: 'Risky sign-in count',
  }),
  2: () => ({ // Sign-in locations world map
    type: 'map',
    data: pickN(MOCK_POOLS.countries, 8).map((c, i) => ({ ...c, value: jitter(120 - i * 14) })),
  }),
  3: () => ({ // Failed sign-ins by reason (pie)
    type: 'pie',
    data: [
      { label: 'Invalid password', value: jitter(420) },
      { label: 'Account locked', value: jitter(180) },
      { label: 'MFA failed', value: jitter(95) },
      { label: 'Conditional Access blocked', value: jitter(60) },
      { label: 'User does not exist', value: jitter(35) },
    ],
  }),
  4: () => ({ // Impossible travel (table)
    type: 'table',
    columns: ['User', 'Hour (UTC)', 'Countries', 'Sign-ins'],
    data: [
      [pickN(MOCK_POOLS.users,1)[0], '14:00', 'USA, Russia', jitter(8)],
      [pickN(MOCK_POOLS.users,1)[0], '09:00', 'UK, Vietnam', jitter(5)],
      [pickN(MOCK_POOLS.users,1)[0], '02:00', 'Germany, Brazil', jitter(3)],
    ],
  }),
  5: () => ({ // MFA bypass scorecard
    type: 'scorecard',
    data: { value: jitter(3, 0.8), label: 'MFA bypass / disable events (24h)', tone: 'crit' },
  }),

  // Dashboard 2: Privileged Access
  6: () => ({ // PIM activations table
    type: 'table',
    columns: ['Time', 'User', 'Role', 'Result'],
    data: [
      ['14:32', pickN(MOCK_POOLS.users,1)[0], 'Global Administrator', 'Success'],
      ['11:08', pickN(MOCK_POOLS.users,1)[0], 'Security Administrator', 'Success'],
      ['09:47', pickN(MOCK_POOLS.users,1)[0], 'Privileged Role Admin', 'Success'],
    ],
  }),
  7: () => ({ // Global admin assignments timeline
    type: 'line',
    xLabel: 'Day', yLabel: 'Assignments',
    data: Array.from({length: 14}, (_, i) => ({
      x: `D-${14-i}`,
      y: i === 7 ? jitter(8, 0.5) : (i === 12 ? jitter(5) : jitter(1, 0.5)),
    })),
  }),
  8: () => ({ // Service principal credential additions (top 10)
    type: 'bar',
    data: pickN(MOCK_POOLS.apps, 6).map((a, i) => ({
      label: a, value: jitter(15 - i * 2),
    })),
    xLabel: 'Credential additions',
  }),
  9: () => ({ // Break-glass scorecard
    type: 'scorecard',
    data: { value: jitter(0, 1.5), label: 'Break-glass account sign-ins (24h)', tone: 'good' },
  }),
  10: () => ({ // AWS CreateAccessKey table
    type: 'table',
    columns: ['Time', 'User ARN', 'Source IP', 'User Agent'],
    data: [
      ['T-2h', 'arn:aws:iam::1234:user/admin1', pickN(MOCK_POOLS.ips,1)[0], 'aws-cli/2.13'],
      ['T-8h', 'arn:aws:iam::1234:root', pickN(MOCK_POOLS.ips,1)[0], 'console.aws.amazon.com'],
    ],
  }),

  // Dashboard 3: Network Threats
  11: () => ({ // TI matched IPs
    type: 'table',
    columns: ['Time', 'Src IP', 'Dest IP', 'Port', 'Threat', 'Confidence'],
    data: [
      ['T-15m', '10.0.4.12', pickN(MOCK_POOLS.ips,1)[0], 443, 'C2 server', 92],
      ['T-1h', '10.0.7.45', pickN(MOCK_POOLS.ips,1)[0], 8080, 'Crypto miner', 85],
      ['T-3h', '10.0.4.12', pickN(MOCK_POOLS.ips,1)[0], 53, 'DNS exfil', 78],
    ],
  }),
  12: () => ({ // East-west traffic
    type: 'bar',
    data: [
      { label: 'web-tier → db-tier', value: jitter(420) },
      { label: 'app-tier → db-tier', value: jitter(180) },
      { label: 'admin-vpc → prod', value: jitter(95) },
      { label: 'dev-vpc → prod', value: jitter(45) },
      { label: 'external-vpn → db', value: jitter(12) },
    ],
    xLabel: 'Connections (24h)',
  }),
  13: () => ({ // Newly opened SG rules
    type: 'table',
    columns: ['Time', 'User', 'Region', 'CIDR', 'Port'],
    data: [
      ['T-30m', pickN(MOCK_POOLS.users,1)[0], 'us-east-1', '0.0.0.0/0', 22],
      ['T-2h', pickN(MOCK_POOLS.users,1)[0], 'eu-west-1', '0.0.0.0/0', 3389],
      ['T-5h', pickN(MOCK_POOLS.users,1)[0], 'us-west-2', '0.0.0.0/0', 1433],
    ],
  }),
  14: () => ({ // DNS queries to suspicious TLDs
    type: 'bar',
    data: pickN(MOCK_POOLS.tlds, 5).map((tld, i) => ({
      label: `kx9j2${tld}`, value: jitter(80 - i * 12),
    })),
    xLabel: 'DNS queries (24h)',
  }),
  15: () => ({ // Internet-facing service exposure map
    type: 'map',
    data: pickN(MOCK_POOLS.countries, 7).map((c, i) => ({ ...c, value: jitter(200 - i * 22) })),
  }),

  // Dashboard 4: Endpoint
  16: () => ({ // EDR alerts by severity
    type: 'pie',
    data: [
      { label: 'High', value: jitter(12) },
      { label: 'Medium', value: jitter(78) },
      { label: 'Low', value: jitter(245) },
      { label: 'Informational', value: jitter(420) },
    ],
  }),
  17: () => ({ // Top 10 hosts by alert volume
    type: 'bar',
    data: pickN(MOCK_POOLS.hosts, 7).map((h, i) => ({
      label: h, value: jitter(40 - i * 4),
    })),
    xLabel: 'Alert count',
  }),
  18: () => ({ // Suspicious process creations (LOLBins)
    type: 'table',
    columns: ['Time', 'Host', 'User', 'Process', 'Cmdline'],
    data: [
      ['T-12m', pickN(MOCK_POOLS.hosts,1)[0], pickN(MOCK_POOLS.users,1)[0], 'powershell.exe', '-enc JABz...'],
      ['T-1h', pickN(MOCK_POOLS.hosts,1)[0], pickN(MOCK_POOLS.users,1)[0], 'certutil.exe', '-decode payload.txt out.exe'],
      ['T-4h', pickN(MOCK_POOLS.hosts,1)[0], pickN(MOCK_POOLS.users,1)[0], 'regsvr32.exe', '/s /n /u /i:http://...'],
    ],
  }),
  19: () => ({ // Persistence registry / scheduled task
    type: 'table',
    columns: ['Time', 'Host', 'Registry Key', 'Value Name', 'Process'],
    data: [
      ['T-25m', pickN(MOCK_POOLS.hosts,1)[0], '...\\Run', 'BackupSvc', 'cmd.exe'],
      ['T-1h', pickN(MOCK_POOLS.hosts,1)[0], '...\\RunOnce', 'Updater', 'powershell.exe'],
      ['T-3h', pickN(MOCK_POOLS.hosts,1)[0], '...\\Image File Execution', 'utilman.exe', 'cmd.exe'],
    ],
  }),
  20: () => ({ // SSH/RDP brute force timeline
    type: 'line',
    xLabel: '15-min bins', yLabel: 'Failed attempts',
    data: Array.from({length: 16}, (_, i) => ({
      x: `${i*15}m`,
      y: i >= 8 && i <= 12 ? jitter(80 + (i-8)*40) : jitter(15, 0.6),
    })),
  }),

  // Dashboard 5: Data Exfiltration
  21: () => ({ // Top 10 buckets by egress
    type: 'bar',
    data: pickN(MOCK_POOLS.buckets, 5).map((b, i) => ({
      label: b, value: jitter(800 - i * 120),
    })),
    xLabel: 'GB egressed (24h)',
  }),
  22: () => ({ // Anomalous outbound bandwidth by source (line)
    type: 'line',
    xLabel: 'Hour', yLabel: 'GB egress',
    data: Array.from({length: 24}, (_, i) => ({
      x: `${i}h`,
      y: i === 14 ? jitter(45, 0.4) : jitter(8, 0.5),
    })),
  }),
  23: () => ({ // Public exposure events
    type: 'table',
    columns: ['Time', 'Event', 'User', 'Bucket', 'Source IP'],
    data: [
      ['T-1h', 'PutBucketPolicy', pickN(MOCK_POOLS.users,1)[0], 'acme-customer-pii', pickN(MOCK_POOLS.ips,1)[0]],
      ['T-6h', 'DeletePublicAccessBlock', pickN(MOCK_POOLS.users,1)[0], 'acme-finance-reports', pickN(MOCK_POOLS.ips,1)[0]],
    ],
  }),
  24: () => ({ // Sensitive data access by unusual principal
    type: 'table',
    columns: ['Time', 'User', 'Source IP', 'Secret accessed'],
    data: [
      ['T-22m', 'arn:aws:iam::1234:role/lambda-payments', pickN(MOCK_POOLS.ips,1)[0], 'prod/db/master-password'],
      ['T-2h', 'arn:aws:iam::1234:user/contractor-3', pickN(MOCK_POOLS.ips,1)[0], 'prod/api-keys/stripe'],
    ],
  }),
  25: () => ({ // Cross-account snapshot copies
    type: 'table',
    columns: ['Time', 'User', 'Source Region', 'Dest Region', 'Snapshot ID'],
    data: [
      ['T-15m', pickN(MOCK_POOLS.users,1)[0], 'us-east-1', 'eu-central-1', 'snap-0a7b9c4d'],
      ['T-2h', pickN(MOCK_POOLS.users,1)[0], 'us-east-1', 'us-west-2', 'snap-0e1f3d8a'],
    ],
  }),

  // Dashboard 6: Cloud Misconfiguration
  26: () => ({ // Critical findings scorecard
    type: 'scorecard',
    data: { value: jitter(34), label: 'Critical findings (active)', tone: 'crit' },
  }),
  27: () => ({ // Findings by category pie
    type: 'pie',
    data: [
      { label: 'IAM', value: jitter(85) },
      { label: 'Networking', value: jitter(62) },
      { label: 'Data', value: jitter(48) },
      { label: 'Logging', value: jitter(31) },
      { label: 'Encryption', value: jitter(24) },
    ],
  }),
  28: () => ({ // Posture score trend
    type: 'line',
    xLabel: 'Day', yLabel: 'Secure Score %',
    data: Array.from({length: 30}, (_, i) => ({
      x: `D-${30-i}`,
      y: 58 + i * 0.6 + (Math.random() * 3 - 1.5),
    })),
  }),
  29: () => ({ // Public-exposed resources
    type: 'table',
    columns: ['Resource', 'Severity', 'Description'],
    data: [
      ['acme-customer-pii (S3)', 'High', 'Bucket allows public read'],
      ['vm-prod-12 (Azure)', 'High', 'Public IP, no NSG rules'],
      ['db-analytics (Cloud SQL)', 'Medium', 'Authorized network 0.0.0.0/0'],
    ],
  }),
  30: () => ({ // Logging tampering scorecard
    type: 'scorecard',
    data: { value: jitter(2, 1.5), label: 'Logging tampering events (24h)', tone: 'crit' },
  }),

  // Dashboard 7: Email & Phishing
  31: () => ({ // Phishing emails delivered
    type: 'line',
    xLabel: 'Hour', yLabel: 'Phish delivered',
    data: Array.from({length: 24}, (_, i) => ({
      x: `${i}h`,
      y: (i >= 8 && i <= 17) ? jitter(20, 0.4) : jitter(4, 0.6),
    })),
  }),
  32: () => ({ // Top 10 phishing senders
    type: 'bar',
    data: [
      { label: 'support@acmë-bank.com', value: jitter(48) },
      { label: 'hr@acmê-corp.example', value: jitter(35) },
      { label: 'no-reply@docusign-acme.com', value: jitter(28) },
      { label: 'admin@office365-login.com', value: jitter(22) },
      { label: 'sales@payment-portal.example', value: jitter(15) },
    ],
    xLabel: 'Phishing attempts',
  }),
  33: () => ({ // Suspicious OAuth consent grants
    type: 'table',
    columns: ['Time', 'User', 'App', 'Result'],
    data: [
      ['T-3h', pickN(MOCK_POOLS.users,1)[0], 'PDF Reader Pro', 'Granted'],
      ['T-1d', pickN(MOCK_POOLS.users,1)[0], 'Calendar Sync Plus', 'Granted'],
      ['T-2d', pickN(MOCK_POOLS.users,1)[0], 'TaskPilot Bot', 'Granted'],
    ],
  }),
  34: () => ({ // Click-through rate scorecard
    type: 'scorecard',
    data: { value: `${jitter(4, 0.8)}%`, label: 'Phishing click-through rate (7d)', tone: 'warn' },
  }),
  35: () => ({ // Impersonation attempts
    type: 'table',
    columns: ['Time', 'Sender', 'Display Name', 'Subject'],
    data: [
      ['T-5h', 'cfo@acmê-corp.example', 'Sarah Mitchell, CFO', 'Urgent: Wire transfer needed'],
      ['T-1d', 'ceo@acmê-corp.example', 'James Park, CEO', 'Quick question'],
      ['T-2d', 'it-help@acmê-corp.example', 'IT Helpdesk', 'Password reset required'],
    ],
  }),

  // Dashboard 8: Threat Intel Matches
  36: () => ({ // TI hits by indicator type
    type: 'pie',
    data: [
      { label: 'IP Address', value: jitter(420) },
      { label: 'Domain Name', value: jitter(180) },
      { label: 'File Hash', value: jitter(85) },
      { label: 'URL', value: jitter(62) },
    ],
  }),
  37: () => ({ // Top hit IoCs
    type: 'bar',
    data: [
      { label: pickN(MOCK_POOLS.ips,1)[0], value: jitter(89) },
      { label: 'malicious-update.example', value: jitter(67) },
      { label: pickN(MOCK_POOLS.ips,1)[0], value: jitter(48) },
      { label: 'phish-login.example', value: jitter(35) },
      { label: 'a8f3...c92b (sha256)', value: jitter(22) },
    ],
    xLabel: 'Match count (7d)',
  }),
  38: () => ({ // Hits over time
    type: 'line',
    xLabel: 'Day', yLabel: 'TI hits',
    data: Array.from({length: 30}, (_, i) => ({
      x: `D-${30-i}`,
      y: i === 18 ? jitter(180, 0.3) : jitter(45, 0.4),
    })),
  }),
  39: () => ({ // TI hit sources / feeds
    type: 'bar',
    data: pickN(MOCK_POOLS.feedSources, 5).map((s, i) => ({
      label: s, value: jitter(220 - i * 32),
    })),
    xLabel: 'Hits contributed (30d)',
  }),

  // Dashboard 9: Compliance Posture
  40: () => ({ // Compliance score by framework
    type: 'bar',
    data: [
      { label: 'CIS Cloud (Azure)', value: 87 },
      { label: 'PCI DSS 3.2.1', value: 78 },
      { label: 'ISO 27001', value: 73 },
      { label: 'SOC 2 Type II', value: 81 },
      { label: 'NIST CSF', value: 69 },
      { label: 'HIPAA HITRUST', value: 64 },
    ],
    xLabel: 'Pass rate %',
  }),
  41: () => ({ // Failed controls by severity
    type: 'pie',
    data: [
      { label: 'High', value: jitter(28) },
      { label: 'Medium', value: jitter(74) },
      { label: 'Low', value: jitter(140) },
    ],
  }),
  42: () => ({ // Audit-relevant events table
    type: 'table',
    columns: ['Time', 'Caller', 'Operation', 'Result'],
    data: [
      ['T-2h', pickN(MOCK_POOLS.users,1)[0], 'roleAssignments/write', 'Success'],
      ['T-5h', pickN(MOCK_POOLS.users,1)[0], 'KeyVault/secrets/setSecret', 'Success'],
      ['T-12h', pickN(MOCK_POOLS.users,1)[0], 'storageAccounts/regenerateKey', 'Success'],
    ],
  }),
  43: () => ({ // Compliance trend 90d
    type: 'line',
    xLabel: 'Day', yLabel: 'PCI-DSS pass rate %',
    data: Array.from({length: 30}, (_, i) => ({
      x: `D-${30-i}`,
      y: 70 + i * 0.3 + (Math.random() * 4 - 2),
    })),
  }),

  // Dashboard 10: IR Operations
  44: () => ({ // Alert volume by severity
    type: 'line',
    xLabel: 'Day', yLabel: 'Alerts',
    data: Array.from({length: 14}, (_, i) => ({
      x: `D-${14-i}`,
      y: jitter(85 + Math.sin(i / 2) * 30, 0.2),
    })),
  }),
  45: () => ({ // MTTR by severity
    type: 'bar',
    data: [
      { label: 'Critical', value: jitter(42) },
      { label: 'High', value: jitter(125) },
      { label: 'Medium', value: jitter(380) },
      { label: 'Low', value: jitter(960) },
    ],
    xLabel: 'MTTR (minutes)',
  }),
  46: () => ({ // Open incidents backlog
    type: 'scorecard',
    data: { value: jitter(47), label: 'Open incidents (active)', tone: 'warn' },
  }),
  47: () => ({ // Top 10 noisiest detection rules
    type: 'bar',
    data: pickN(MOCK_POOLS.ruleNames, 5).map((r, i) => ({
      label: r, value: jitter(180 - i * 25),
    })),
    xLabel: 'Alerts (7d)',
  }),
  48: () => ({ // Alert source distribution
    type: 'pie',
    data: pickN(MOCK_POOLS.productNames, 5).map((p, i) => ({
      label: p, value: jitter(220 - i * 30),
    })),
  }),

  // Dashboard 11: Container Security
  49: () => ({ // Privileged pod creations
    type: 'table',
    columns: ['Time', 'User', 'Namespace', 'Pod Name'],
    data: [
      ['T-12m', pickN(MOCK_POOLS.users,1)[0], 'kube-system', 'debug-shell-7c8d9f'],
      ['T-2h', pickN(MOCK_POOLS.users,1)[0], 'production', 'data-loader-abc123'],
      ['T-5h', pickN(MOCK_POOLS.users,1)[0], 'default', 'sidecar-test-xyz789'],
    ],
  }),
  50: () => ({ // RBAC cluster-admin grants
    type: 'line',
    xLabel: 'Day', yLabel: 'cluster-admin grants',
    data: Array.from({length: 30}, (_, i) => ({
      x: `D-${30-i}`,
      y: i === 14 ? jitter(3) : (i === 22 ? jitter(2) : jitter(0, 2)),
    })),
  }),
  51: () => ({ // Untrusted registry pulls
    type: 'bar',
    data: [
      { label: 'docker.io/unknown-author', value: jitter(48) },
      { label: 'quay.io/community-build', value: jitter(32) },
      { label: 'ghcr.io/personal-fork', value: jitter(18) },
      { label: 'public.ecr.aws/random', value: jitter(12) },
      { label: 'gcr.io/non-prod', value: jitter(7) },
    ],
    xLabel: 'Pull count (7d)',
  }),
  52: () => ({ // Pod exec sessions
    type: 'table',
    columns: ['Time', 'User', 'Namespace', 'Pod Name'],
    data: [
      ['T-30m', pickN(MOCK_POOLS.users,1)[0], 'production', 'api-server-6f8c4'],
      ['T-3h', pickN(MOCK_POOLS.users,1)[0], 'kube-system', 'kube-controller-manager-1'],
      ['T-1d', pickN(MOCK_POOLS.users,1)[0], 'data-platform', 'spark-driver-job-42'],
    ],
  }),
  53: () => ({ // Container CVE coverage
    type: 'scorecard',
    data: { value: jitter(23), label: 'Containers with critical CVEs (active)', tone: 'crit' },
  }),

  // Dashboard 12: Insider Threat
  54: () => ({ // After-hours privileged access
    type: 'table',
    columns: ['Time', 'User', 'Country', 'App', 'Hour'],
    data: [
      ['T-2h (02:13)', pickN(MOCK_POOLS.users,1)[0], 'USA', 'Azure Portal', 2],
      ['T-1d (23:45)', pickN(MOCK_POOLS.users,1)[0], 'Germany', 'Privileged Access Manager', 23],
      ['T-3d (04:18)', pickN(MOCK_POOLS.users,1)[0], 'USA', 'AWS Console', 4],
    ],
  }),
  55: () => ({ // Top users by sensitive data access
    type: 'bar',
    data: pickN(MOCK_POOLS.users, 6).map((u, i) => ({
      label: u, value: jitter(420 - i * 55),
    })),
    xLabel: 'Sensitive accesses (7d)',
  }),
  56: () => ({ // Mass data download events
    type: 'table',
    columns: ['Time', 'User', 'Objects', 'Distinct Buckets'],
    data: [
      ['T-1h', pickN(MOCK_POOLS.users,1)[0], jitter(4200), jitter(8)],
      ['T-3h', pickN(MOCK_POOLS.users,1)[0], jitter(2800), jitter(3)],
      ['T-1d', pickN(MOCK_POOLS.users,1)[0], jitter(1400), jitter(2)],
    ],
  }),
  57: () => ({ // External transfer indicators
    type: 'table',
    columns: ['Time', 'User', 'Operation', 'Detail'],
    data: [
      ['T-2h', pickN(MOCK_POOLS.users,1)[0], 'Set-InboxRule', 'ForwardingSmtpAddress: alice@personal-mail.example'],
      ['T-1d', pickN(MOCK_POOLS.users,1)[0], 'SharingSet', 'External: yes; Recipients: 23'],
      ['T-3d', pickN(MOCK_POOLS.users,1)[0], 'Set-Mailbox', 'AutoForwardingDeliverTo: m.chen@personal-mail.example'],
    ],
  }),
  58: () => ({ // Privileged access by terminating users
    type: 'scorecard',
    data: { value: jitter(7), label: 'Privileged access by users in 30d notice', tone: 'warn' },
  }),

  // Dashboard 13: AI/ML Workload Security
  59: () => ({ // Inference rate spikes
    type: 'line',
    xLabel: 'Hour', yLabel: 'Requests',
    data: Array.from({length: 48}, (_, i) => ({
      x: `${Math.floor(i/2)}h`,
      y: (i >= 30 && i <= 38) ? jitter(2200 + (i-30)*200, 0.2) : jitter(450, 0.4),
    })),
  }),
  60: () => ({ // Top users by inference volume
    type: 'bar',
    data: pickN(MOCK_POOLS.users, 5).map((u, i) => ({
      label: u, value: jitter(8500 - i * 1200),
    })),
    xLabel: 'Inference requests (24h)',
  }),
  61: () => ({ // Model deployment events
    type: 'table',
    columns: ['Time', 'User', 'Event', 'Model', 'Image'],
    data: [
      ['T-4h', pickN(MOCK_POOLS.users,1)[0], 'CreateEndpoint', 'fraud-detect-v3', '...:fraud-v3-prod'],
      ['T-1d', pickN(MOCK_POOLS.users,1)[0], 'CreateModel', 'recommend-v2', '...:rec-v2-staging'],
      ['T-3d', pickN(MOCK_POOLS.users,1)[0], 'UpdateEndpoint', 'churn-pred-v1', '...:churn-v1-prod'],
    ],
  }),
  62: () => ({ // Training data access patterns
    type: 'table',
    columns: ['Time', 'User', 'Event', 'Bucket'],
    data: [
      ['T-2h', pickN(MOCK_POOLS.users,1)[0], 'GetObject', 'ml-training-customer-pii'],
      ['T-5h', pickN(MOCK_POOLS.users,1)[0], 'ListObjectsV2', 'ml-training-financial-records'],
      ['T-1d', pickN(MOCK_POOLS.users,1)[0], 'GetObject', 'train-data-clinical-notes'],
    ],
  }),
  63: () => ({ // Anomalous prompt patterns
    type: 'scorecard',
    data: { value: jitter(89), label: 'Prompt injection attempts (24h)', tone: 'warn' },
  }),

};

// ─── CHART RENDERERS ──────────────────────────────────────────────────

const PALETTE = ['#F4A261', '#60A5FA', '#10B981', '#FBBF24', '#F87171', '#A78BFA', '#34D399'];

function renderMockChart(viz) {
  const gen = MOCK_GENERATORS[viz.VizID];
  if (!gen) return '';
  const mock = gen();

  switch (mock.type) {
    case 'bar': return renderMockBar(mock);
    case 'pie': return renderMockPie(mock);
    case 'line': return renderMockLine(mock);
    case 'table': return renderMockTable(mock);
    case 'scorecard': return renderMockScorecard(mock);
    case 'map': return renderMockMap(mock);
    default: return '';
  }
}

function renderMockBar(mock) {
  const max = Math.max(...mock.data.map(d => d.value));
  return `<div class="mock-chart">
    ${mock.data.map(d => `
      <div class="mock-bar-row">
        <span class="mock-bar-label" title="${escapeHtml(d.label)}">${escapeHtml(d.label)}</span>
        <div class="mock-bar-track">
          <div class="mock-bar-fill" style="width: ${(d.value/max*100).toFixed(0)}%;"></div>
        </div>
        <span class="mock-bar-value">${d.value.toLocaleString()}</span>
      </div>
    `).join('')}
    ${mock.xLabel ? `<div class="mock-axis-label">${escapeHtml(mock.xLabel)}</div>` : ''}
  </div>`;
}

function renderMockPie(mock) {
  const total = mock.data.reduce((s, d) => s + d.value, 0);
  let cumulativeAngle = -Math.PI / 2;
  const R = 70, CX = 80, CY = 80;

  const slices = mock.data.map((d, i) => {
    const angle = (d.value / total) * Math.PI * 2;
    const x1 = CX + R * Math.cos(cumulativeAngle);
    const y1 = CY + R * Math.sin(cumulativeAngle);
    const x2 = CX + R * Math.cos(cumulativeAngle + angle);
    const y2 = CY + R * Math.sin(cumulativeAngle + angle);
    const largeArc = angle > Math.PI ? 1 : 0;
    const path = `M${CX},${CY} L${x1.toFixed(2)},${y1.toFixed(2)} A${R},${R} 0 ${largeArc},1 ${x2.toFixed(2)},${y2.toFixed(2)} Z`;
    cumulativeAngle += angle;
    return `<path d="${path}" fill="${PALETTE[i % PALETTE.length]}" stroke="var(--bg)" stroke-width="1.5" />`;
  }).join('');

  const legend = mock.data.map((d, i) => `
    <div class="mock-legend-item">
      <span class="mock-legend-swatch" style="background:${PALETTE[i % PALETTE.length]}"></span>
      <span class="mock-legend-label">${escapeHtml(d.label)}</span>
      <span class="mock-legend-value">${d.value.toLocaleString()} (${(d.value/total*100).toFixed(0)}%)</span>
    </div>
  `).join('');

  return `<div class="mock-chart mock-pie">
    <svg viewBox="0 0 160 160" width="140" height="140">${slices}</svg>
    <div class="mock-legend">${legend}</div>
  </div>`;
}

function renderMockLine(mock) {
  const W = 480, H = 130, P = 24;
  const max = Math.max(...mock.data.map(d => d.y));
  const min = Math.min(...mock.data.map(d => d.y));
  const range = Math.max(1, max - min);
  const stepX = (W - P * 2) / Math.max(1, mock.data.length - 1);
  const points = mock.data.map((d, i) => ({
    x: P + i * stepX,
    y: H - P - ((d.y - min) / range) * (H - P * 2),
  }));
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');

  // X axis labels: show every Nth to avoid clutter
  const labelEvery = Math.max(1, Math.floor(mock.data.length / 6));
  const xLabels = mock.data.map((d, i) => i % labelEvery === 0
    ? `<text x="${points[i].x}" y="${H - 8}" font-size="9" fill="var(--text-muted)" text-anchor="middle">${escapeHtml(String(d.x))}</text>`
    : ''
  ).join('');

  return `<div class="mock-chart mock-line">
    <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="width:100%; height:140px;">
      <line x1="${P}" y1="${H-P}" x2="${W-P}" y2="${H-P}" stroke="var(--border)" stroke-width="1" />
      <line x1="${P}" y1="${P}" x2="${P}" y2="${H-P}" stroke="var(--border)" stroke-width="1" />
      <path d="${path}" fill="none" stroke="${PALETTE[0]}" stroke-width="2" />
      ${points.map(p => `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="3" fill="${PALETTE[0]}" />`).join('')}
      ${xLabels}
      <text x="${P+4}" y="${P+8}" font-size="9" fill="var(--text-muted)">${max.toFixed(0)}</text>
      <text x="${P+4}" y="${H-P-2}" font-size="9" fill="var(--text-muted)">${min.toFixed(0)}</text>
    </svg>
    ${mock.yLabel ? `<div class="mock-axis-label">${escapeHtml(mock.yLabel)}${mock.xLabel ? ' \u2022 ' + escapeHtml(mock.xLabel) : ''}</div>` : ''}
  </div>`;
}

function renderMockTable(mock) {
  return `<div class="mock-chart mock-table">
    <table>
      <thead><tr>${mock.columns.map(c => `<th>${escapeHtml(c)}</th>`).join('')}</tr></thead>
      <tbody>
        ${mock.data.map(row => `<tr>${row.map(cell => `<td>${escapeHtml(String(cell))}</td>`).join('')}</tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

function renderMockScorecard(mock) {
  const toneColor = mock.data.tone === 'crit' ? '#EF4444'
    : mock.data.tone === 'warn' ? '#F59E0B'
    : mock.data.tone === 'good' ? '#10B981'
    : 'var(--accent)';
  return `<div class="mock-chart mock-scorecard">
    <div class="mock-scorecard-value" style="color:${toneColor};">${mock.data.value}</div>
    <div class="mock-scorecard-label">${escapeHtml(mock.data.label)}</div>
  </div>`;
}

function renderMockMap(mock) {
  // Simple country grid view (not real map geometry — just a visual stand-in)
  const max = Math.max(...mock.data.map(d => d.value));
  return `<div class="mock-chart mock-map">
    <div class="mock-map-grid">
      ${mock.data.map(d => {
        const intensity = Math.min(0.95, 0.15 + (d.value / max) * 0.85);
        return `<div class="mock-map-cell" style="background: rgba(244,162,97,${intensity.toFixed(2)});">
          <span class="mock-map-code">${escapeHtml(d.code)}</span>
          <span class="mock-map-name">${escapeHtml(d.name)}</span>
          <span class="mock-map-value">${d.value.toLocaleString()}</span>
        </div>`;
      }).join('')}
    </div>
    <div class="mock-axis-label">Geographic distribution (sample)</div>
  </div>`;
}

// Globally available for the SecOps view
window.renderMockChart = renderMockChart;


/* === v16_secops.js === */
// ═══════════════════════════════════════════════════════════════════════
// SECOPS DASHBOARDS — browse + copy-to-clipboard
// ═══════════════════════════════════════════════════════════════════════

let secopsCurrentDashId = null;

function renderSecOps() {
  const root = document.getElementById('secops-view');
  if (!root) return;

  const dashboards = DATA.secops_dashboards || [];
  const visualizations = DATA.secops_visualizations || [];

  if (secopsCurrentDashId === null) {
    root.innerHTML = renderSecOpsList(dashboards, visualizations);
    wireSecOpsListEvents();
  } else {
    const dash = dashboards.find(d => d.DashboardID === secopsCurrentDashId);
    const vizs = visualizations.filter(v => v.DashboardID === secopsCurrentDashId);
    root.innerHTML = renderSecOpsDetail(dash, vizs);
    wireSecOpsDetailEvents();
  }
}

function renderSecOpsList(dashboards, visualizations) {
  const cards = dashboards.map(d => {
    const vizCount = visualizations.filter(v => v.DashboardID === d.DashboardID).length;
    return `
      <div class="dashboard-card" data-dash-id="${d.DashboardID}">
        <div class="dash-cat">${escapeHtml(d.Category || '')}</div>
        <div class="dash-name">${escapeHtml(d['Dashboard Name'] || '')}</div>
        <div class="dash-why">${escapeHtml(d['Why It Matters'] || '')}</div>
        <div class="dash-meta">
          <span>${vizCount} visualization${vizCount === 1 ? '' : 's'}</span>
          <span>Refresh: ${escapeHtml(d['Recommended Refresh'] || '\u2014')}</span>
        </div>
      </div>
    `;
  }).join('');

  return `
    <div class="secops-header">
      <h2>SecOps Dashboards</h2>
      <p class="lead">10 must-have SOC dashboards with KQL (Sentinel) and YARA-L (Chronicle) queries. Click any dashboard to see its visualizations and copy queries directly to your SIEM.</p>
    </div>
    <div class="dashboards-grid">${cards}</div>
    <div class="lead" style="font-size:11px; color:var(--text-muted); margin-top:16px; padding-top:16px; border-top:1px solid var(--border);">
      <strong>Honest note:</strong> Queries are starting points. KQL syntax is well-stabilized (most queries production-ready); YARA-L 2.0 syntax is newer and many queries should be verified in your Chronicle/Google SecOps instance before customer-facing use. Confidence tags on each query indicate where to invest verification effort.
    </div>
  `;
}

function renderSecOpsDetail(dash, vizs) {
  const vizHTML = vizs.map(v => renderVizTile(v)).join('');
  return `
    <div class="secops-detail">
      <div class="secops-detail-header">
        <div>
          <h3>${escapeHtml(dash['Dashboard Name'])}</h3>
          <div class="meta">${escapeHtml(dash.Category)} \u2022 Refresh ${escapeHtml(dash['Recommended Refresh'])} \u2022 ${vizs.length} visualizations</div>
          <div class="why">${escapeHtml(dash['Why It Matters'])}</div>
          ${dash['MITRE Tactics'] ? `<div class="meta" style="margin-top:6px;">MITRE: ${escapeHtml(dash['MITRE Tactics'])}</div>` : ''}
        </div>
        <button class="close" id="secops-back">\u2190 Back to dashboards</button>
      </div>
      ${vizHTML}
    </div>
  `;
}

function renderVizTile(v) {
  const components = String(v.ComponentIDs || '').split(';').map(s => s.trim()).filter(Boolean);
  const compPills = components.slice(0, 6).map(cid => {
    const comp = componentById[Number(cid)];
    return comp ? `<span class="viz-component-pill">${escapeHtml(comp['Component Name'])}</span>` : '';
  }).join('');

  const kqlConf = v['KQL Confidence'] || 'Medium';
  const yaraConf = v['YARA-L Confidence'] || 'Low';

  // Unique IDs to scope tab interactions per tile
  const tileId = `viz-${v.VizID}`;

  return `
    <div class="viz-tile" id="${tileId}">
      <div class="viz-tile-header">
        <div class="viz-tile-title">${escapeHtml(v.Title)}</div>
        <div class="viz-tile-type">${escapeHtml(v['Visualization Type'])}</div>
      </div>
      <div class="viz-tile-why">${escapeHtml(v['Why This Viz'] || '')}</div>
      ${compPills ? `<div class="viz-component-pills">${compPills}</div>` : ''}
      <div class="mock-preview-wrap" data-preview-for="${tileId}">
        <div class="mock-preview-header">
          <span class="mock-label">Sample data preview \u2014 not real customer data</span>
          <button class="mock-randomize-btn" data-randomize="${tileId}">\u21BB Generate sample</button>
        </div>
        <div class="mock-preview-body" id="${tileId}-preview">
          ${typeof renderMockChart === 'function' ? renderMockChart(v) : ''}
        </div>
      </div>
      <div class="query-tabs" style="margin-top:14px;">
        <button class="query-tab active" data-tab="kql" data-tile="${tileId}">
          KQL <span class="conf-pill conf-${kqlConf.toLowerCase()}">${kqlConf}</span>
        </button>
        <button class="query-tab" data-tab="yaral" data-tile="${tileId}">
          YARA-L <span class="conf-pill conf-${yaraConf.toLowerCase()}">${yaraConf}</span>
        </button>
      </div>
      <div class="query-content active" data-content="kql">
        <div class="query-tables-row" style="margin-top:10px;"><strong>Tables:</strong>${escapeHtml(v['KQL Tables'] || '')}</div>
        <div class="query-block">
          <button class="copy-btn" data-copy="${tileId}-kql">Copy</button>
          <pre id="${tileId}-kql-text">${escapeHtml(v['KQL Query'] || '')}</pre>
        </div>
      </div>
      <div class="query-content" data-content="yaral">
        <div class="query-tables-row" style="margin-top:10px;"><strong>Tables:</strong>${escapeHtml(v['YARA-L Tables'] || '')}</div>
        <div class="query-block">
          <button class="copy-btn" data-copy="${tileId}-yaral">Copy</button>
          <pre id="${tileId}-yaral-text">${escapeHtml(v['YARA-L Query'] || '')}</pre>
        </div>
      </div>
    </div>
  `;
}

function wireSecOpsListEvents() {
  document.querySelectorAll('#secops-view .dashboard-card').forEach(card => {
    card.addEventListener('click', () => {
      secopsCurrentDashId = Number(card.dataset.dashId);
      renderSecOps();
    });
  });
}

function wireSecOpsDetailEvents() {
  const backBtn = document.getElementById('secops-back');
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      secopsCurrentDashId = null;
      renderSecOps();
    });
  }
  // Tab switching per tile
  document.querySelectorAll('#secops-view .query-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const tileId = tab.dataset.tile;
      const which = tab.dataset.tab;
      const tile = document.getElementById(tileId);
      if (!tile) return;
      tile.querySelectorAll('.query-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      tile.querySelectorAll('.query-content').forEach(c => c.classList.remove('active'));
      const content = tile.querySelector(`.query-content[data-content="${which}"]`);
      if (content) content.classList.add('active');
    });
  });
  // Copy buttons
  document.querySelectorAll('#secops-view .copy-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.dataset.copy;
      const codeEl = document.getElementById(targetId + '-text');
      if (!codeEl) return;
      const text = codeEl.textContent || '';
      // Use clipboard API; fallback for older browsers
      const onSuccess = () => {
        const orig = btn.textContent;
        btn.textContent = 'Copied!';
        btn.classList.add('copied');
        setTimeout(() => {
          btn.textContent = orig;
          btn.classList.remove('copied');
        }, 1500);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(onSuccess).catch(() => {
          // Fallback to manual select
          fallbackCopy(text);
          onSuccess();
        });
      } else {
        fallbackCopy(text);
        onSuccess();
      }
    });
  });

  // Randomize buttons (re-render mock data for the specific viz tile)
  document.querySelectorAll('#secops-view .mock-randomize-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tileId = btn.dataset.randomize;
      const tile = document.getElementById(tileId);
      const previewBody = document.getElementById(tileId + '-preview');
      if (!tile || !previewBody) return;
      // Find the viz from VizID embedded in tileId (format: "viz-N")
      const vizId = Number(tileId.replace('viz-', ''));
      const viz = (DATA.secops_visualizations || []).find(v => v.VizID === vizId);
      if (!viz) return;
      previewBody.innerHTML = (typeof renderMockChart === 'function') ? renderMockChart(viz) : '';
      // Brief flash on the button
      btn.style.color = 'var(--accent)';
      setTimeout(() => { btn.style.color = ''; }, 400);
    });
  });
}

function fallbackCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); } catch (e) { /* ignore */ }
  document.body.removeChild(ta);
}

window.renderSecOps = renderSecOps;



/* === inline-was-in-html: button wiring === */
document.getElementById('btn-admin').addEventListener('click', function () {
  openAdmin();
});

var canvasBtn = document.getElementById('view-canvas-btn');
var dashBtn = document.getElementById('view-dashboard-btn');
var secopsBtn = document.getElementById('view-secops-btn');
function switchView(view) {
  document.body.setAttribute('data-view', view);
  canvasBtn.classList.toggle('active', view === 'canvas');
  dashBtn.classList.toggle('active', view === 'dashboard');
  secopsBtn.classList.toggle('active', view === 'secops');
  if (view === 'dashboard') {
    renderDashboard();
  } else if (view === 'secops') {
    renderSecOps();
  }
}
canvasBtn.addEventListener('click', function () { switchView('canvas'); });
dashBtn.addEventListener('click', function () { switchView('dashboard'); });
secopsBtn.addEventListener('click', function () { switchView('secops'); });
