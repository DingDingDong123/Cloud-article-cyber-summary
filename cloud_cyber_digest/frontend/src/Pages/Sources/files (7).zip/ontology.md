# Ontology

Last researched: 2026-06-08. Sources are Palantir public docs and the official palantir/osdk-ts GitHub repo; dates inline. Re-verify dated claims before production use.

## Contents
- What the Ontology is
- Object / link / action / property capabilities
- Decision framework (full)
- Seven design principles
- Action and link discipline
- The eight anti-patterns
- OSDK best practices
- Recent changes and deprecations

## What the Ontology is

(ontology/overview) The Ontology = data (objects, properties, links) + kinetics (action types, functions) + interfaces for polymorphism. It is the semantic and operational layer applications build on.

## Object / link / action / property capabilities

- Object types: backed by datasets, restricted views, virtual tables, managed Iceberg, or streams. Multi-datasource object types (MDOs) supported. Object Storage V2 (OSv2) is current; OSv1 (Phonograph) is in planned deprecation.
- Link types: many-to-one and many-to-many. Many-to-many generates a join object set and link index, which carries real ontology volume, higher indexing cost, and heavier search-around operations.
- Properties: typed — including media references, GeoPoint, time-series references, structs, and value types. Shared properties give cross-object-type consistency. Derived properties compute values. Mandatory control properties enforce row-level security via restricted-view marking columns.
- Action types: define edits; support rules, parameters, submission criteria, function-backed actions (batched execution), side effects (notifications, webhooks), and trigger-schedule-build.
- Interfaces: shape definitions enabling polymorphic operations across object types and interface link types.

## Decision framework (full)

Adapted from ontology/ontology-best-practices-and-anti-patterns:

| Need | Use |
|---|---|
| A real-world entity with persistent properties | Object type — one per entity, not one per source system |
| A semantic relationship between two entities | Link type — prefer foreign-key/one-to-many; reserve many-to-many for genuine need |
| A human-or-agent decision that changes state | Action type (function-backed if logic is non-trivial) |
| A value derived purely from source columns | Pipeline (batch or streaming). Before writing a function, ask: can this be pre-computed in the backing pipeline? If it depends only on source columns and needs no live traversal, compute upstream. |
| A reaction to an Ontology change | Automation. Before building a polling pipeline that runs every N minutes to detect changes, ask: can an automation react to this event directly? |
| A shape shared across multiple object types | Interface, not a wide sparse God Object |
| Real-time computation across objects | Function on Objects |

## Seven design principles

(verbatim intent from the ontology design page)
1. Model reality, not systems.
2. Curate intentionally — every property should have clear business or technical value.
3. Collaborate across teams.
4. Keep object types focused — one distinct entity each.
5. Choose the right tool — action types for decisions, pipelines for transformations.
6. Use interfaces for abstraction.
7. Document your decisions in Ontology Manager.

## Action and link discipline

- Build action types around business operations, not single-column updates. Bundle related fields into one action ("Onboard New Employee", "Transfer Employee") rather than dozens of "Update X" actions.
- Avoid versioned object types ("Contract v1, v2, v3"). Use one object per real entity plus a linked history object type or time-series properties.
- Name links by the relationship, not "related to".
- Use mandatory control properties + restricted view for row-level / property-level security on sensitive datasources.

## The eight anti-patterns

(ontology/ontology-best-practices-and-anti-patterns)
- System Silos — separate object types per source system. Fix: merge in pipelines.
- Kitchen Sink — exposing ETL metadata as properties. Fix: curate; keep technical metadata in the backing dataset.
- Department Silos — sales/support/billing each modeling Customer. Fix: shared types with department-specific properties/links.
- God Object — one bloated type with many null properties. Fix: distinct types + interfaces.
- Golden Hammer — overusing one tool for everything. Fix: the decision matrix above.
- Action Sprawl — too many single-property actions. Fix: bundle into business operations.
- Time Machine — modeling history as distinct objects. Fix: single object + linked history + edits history.
- Misnomer — vague generic names. Fix: name by real-world meaning.

## OSDK best practices

(ontology-sdk/overview; questions-answers/ontology-sdk; palantir/osdk-ts README)
- Generate application-specific SDKs in Developer Console. Pick Client-facing application for browser apps, Backend service for servers; do not combine both if you intend to use Foundry website hosting.
- Register only the object/action/function types you need — this scopes the token and shrinks the bundle. The token is scoped to registered entities plus the user's own permissions (secure by design).
- Auth: `createConfidentialOauthClient` for servers; PKCE for browsers.
- Python OSDK requires Python >=3.9 and <3.13.
- TypeScript OSDK supported Node versions are 18 (>=18.19.0), 20, 22, and 24; Node 25 is not supported; Node 22 is recommended.
- Use the Platform SDK (`foundry-platform-typescript`) when you do not need typed Ontology bindings.

## Recent changes and deprecations

- Object Storage V1 (Phonograph) — planned deprecation; migrate to OSv2.
- Object Monitors — sunset; functionality moves into Automate/Monitoring views.
- Configurable markings for media reference properties — GA Jan 2026.
- Project-based permissions for the Ontology are the current recommended model; legacy ontology roles remain documented for migration.

## Note (unverified)

The community-reported claim that integer primary keys are an anti-pattern is not formally codified in the Palantir docs. Verify primary-key type guidance against current Ontology Manager docs and your own architecture skill.
